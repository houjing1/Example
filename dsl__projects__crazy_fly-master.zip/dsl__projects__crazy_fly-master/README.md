A Link to our Documentations: https://github.com/utiasDSL/dsl__projects__crazy_fly/wiki
