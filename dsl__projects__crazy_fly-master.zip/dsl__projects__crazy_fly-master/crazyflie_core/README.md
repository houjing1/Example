# crazyflie_core
Code for flying the crazy flies

Nothing of value yet

### Instructions

```
git clone https://github.com/bitcraze/crazyflie-lib-python.git
git clone https://github.com/bitcraze/crazyflie-clients-python.git
git clone https://github.com/bitcraze/lps-tools.git

sudo apt-get install python-pip python-dev build-essential 
sudo pip install -e crazyflie-lib-python

sudo groupadd plugdev
sudo usermod -a -G plugdev <username>
sudo cp 99-crazyradio.rules /etc/udev/rules.d
sudo cp 99-crazyflie.rules /etc/udev/rules.d

sudo apt-get install python3 python3-pip python3-pyqt5
sudo pip3 install -e crazyflie-clients-python
sudo pip3 install -e lps-tools
```

### dfu-util

```
git clone git://git.code.sf.net/p/dfu-util/dfu-util
cd dfu-util
sudo ./autogen.sh
sudo ./configure
sudo make
sudo make install
cd ..
```

### lps-firmware

```
git clone --recursive https://github.com/bitcraze/lps-node-firmware.git
mkdir -p ~/opt/
cd ~/opt
wget https://launchpad.net/gcc-arm-embedded/5.0/5-2016-q3-update/+download/gcc-arm-none-eabi-5_4-2016q3-20160926-linux.tar.bz2
tar xvf gcc-arm-none-eabi-5_4-2016q3-20160926-linux.tar.bz2
mv gcc-arm-none-eabi-5_4-2016q3 gcc-arm-none-eabi
rm gcc-arm-none-eabi-5_4-2016q3-20160926-linux.tar.bz2
echo "export PATH=\$PATH:\$HOME/opt/gcc-arm-none-eabi/bin" >> ~/.bashrc
sudo apt-get install libncurses5:i386 # if on 64-bits. You may wanna restart your terminal to ensure the path is included.
arm-none-eabi-gcc --version # to check if it's configured correctly
cd lps-node-firmware
make 
make dfu  # to flash into a node
cd ..
```

### crazyfly-firmware

```
git clone --recursive https://github.com/bitcraze/crazyflie-firmware.git
sudo mv config.mk crazyflie-firmware
cd crazyflie-firmware
make clean
make
make cload # to flash into a crazyflie (press the restart button and hole it until two blue lights start flashing before running the command)
```

### pipocom

```
sudo apt-get install picocom
```

### xbox joystick

```
sudo apt-get install xboxdrv
sudo xboxdrv
sudo rmmod xpad
```

### To run the client GUI
```
cfclient
```

### To run the configuration tool GUI (in the lpstools folder)
```
python3 -m lpstools
```
