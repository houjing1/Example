#!/usr/bin/env python

# Created by: Tracy Du and Philip Huang 	Last update: June 19, 2017
# Contact: philip.huang@outlook.com

# The Keyboard Controller Node is adapted from the controller from dsl__central for AR.Drone and ROS
# This controller extends the base Drone_Window class,
# adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib; roslib.load_manifest('crazyflie_core')
import rospy
# import thread
import numpy as np
# from std_srvs.srv import Empty as Emptysrv
# from crazyflie_driver.srv import UpdateParams

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
# from ui_basic_cmd import BasicDroneController
# from reference_signal import SimpleTrajectory
from ui_window import DroneWindow
# Finally the GUI libraries
from PySide import QtCore, QtGui
from crazyflie_central.srv import RequestSafeConduct as SafeConduct
from crazyflie_estimator.msg import SwarmStates
from crazyflie_central.msg import SwarmCmds
from crazyflie_central.msg import VehicleStatus, EventEnum
from crazyflie_central.srv import AddController
from crazyflie_central.srv import CustomControl
from crazyflie_control.msg import ControllerStatusEnum
from crazyflie_control.msg import ControllerHubStatus
from crazyflie_logger.srv import AddLogger
from crazyflie_logger.srv import LoggerRequest


# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	'''
	Takeoff All: Y
	Land All: H
	Emergency All: Space
	Follow Trajectory: N
	Follow Predefined waypoints: P
	Takeoff for Drone1,2,3,4: Q,W,E,R
	Land for Drone1,2,3,4: 1,2,3,4
	Follow Reference for Drone1,2,3,4: A,S,D,F
	Follow Waypoint for Drone1,2,3,4: Z,X,C,V
	'''
	Takeoff          = QtCore.Qt.Key.Key_Y
	Land             = QtCore.Qt.Key.Key_H
	Emergency        = QtCore.Qt.Key.Key_Space
	FollowReference  = QtCore.Qt.Key.Key_N
	FollowWaypoint   = QtCore.Qt.Key.Key_P
	Land1            = QtCore.Qt.Key.Key_1
	Land2            = QtCore.Qt.Key.Key_2
	Land3            = QtCore.Qt.Key.Key_3
	Land4            = QtCore.Qt.Key.Key_4
	Takeoff1 		 = QtCore.Qt.Key.Key_Q
	Takeoff2 		 = QtCore.Qt.Key.Key_W
	Takeoff3 		 = QtCore.Qt.Key.Key_E
	Takeoff4 		 = QtCore.Qt.Key.Key_R
	FollowReference1 = QtCore.Qt.Key.Key_A
	FollowReference2 = QtCore.Qt.Key.Key_S
	FollowReference3 = QtCore.Qt.Key.Key_D
	FollowReference4 = QtCore.Qt.Key.Key_F
	FollowWaypoint1  = QtCore.Qt.Key.Key_Z
	FollowWaypoint2  = QtCore.Qt.Key.Key_X
	FollowWaypoint3  = QtCore.Qt.Key.Key_C
	FollowWaypoint4  = QtCore.Qt.Key.Key_V


# Our controller definition, note that we extend the DroneWindow class
class KeyboardController(DroneWindow):
	def __init__(self):
		'''
		initialize the controller and reference_signal module for each drone
		'''
		# TODO:make reference_signal a separate node
		super(KeyboardController,self).__init__()
		self.num_drones = rospy.get_param('~num_drones',1)

		# for new arch
		self.safe_conduct_client = rospy.ServiceProxy('safe_conduct', SafeConduct)
		self.add_controller = rospy.ServiceProxy("add_controller", AddController)
		self.req_custom_control = rospy.ServiceProxy("custom_control", CustomControl)
		self.req_logger_add = rospy.ServiceProxy("logger/add", AddLogger)
		self.req_logger_action = rospy.ServiceProxy("logger/action", LoggerRequest)

		self.init_drones()
		self.sub_pos_vicon = rospy.Subscriber("full_state", SwarmStates, self.updateVicon)
		self.sub_cmds = rospy.Subscriber("SwarmCmds", SwarmCmds, self.updateCmd)
		self.sub_vehicle_status = rospy.Subscriber("vehicle_status", VehicleStatus, self.updateVehiceStatus)
		self.sub_controller_hub_status = rospy.Subscriber("controller_hub_status", ControllerHubStatus, self.updateControllerHubStatus)

	def keyPressEvent(self, event):
		'''
		We add a keyboard handler to the DroneVideoDisplay to react to keypresses
		:param event: the key being pressed
		:return:
		'''
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		# if self.controllers is not None and not event.isAutoRepeat():
		# 	# Handle the important cases first!
		# 	if key == KeyMapping.Emergency:
		# 		self.emergencyAll()
		# 	elif key == KeyMapping.Takeoff:
		# 		self.takeoff(drones = set(["All"]))
 		# 	elif key == KeyMapping.Land:
		# 		self.land(drones = set(["All"]))
			# elif key == KeyMapping.FollowReference:
			# 	self.followRef(drones = set(["All"]))
			# elif key == KeyMapping.FollowWaypoint:
			# 	self.followWayP(drones = set(["All"]))
			# elif key == KeyMapping.Land1:
			# 	self.land(drones = set(["/Drone1"]))
			# elif key == KeyMapping.Land2:
			# 	self.land(drones = set(["/Drone2"]))
			# elif key == KeyMapping.Land3:
			# 	self.land(drones = set(["/Drone3"]))
			# elif key == KeyMapping.Land4:
			# 	self.land(drones = set(["/Drone4"]))
			# elif key == KeyMapping.Takeoff1:
			# 	self.takeoff(drones = set(["/Drone1"]))
			# elif key == KeyMapping.Takeoff2:
			# 	self.takeoff(drones = set(["/Drone2"]))
			# elif key == KeyMapping.Takeoff3:
			# 	self.takeoff(drones = set(["/Drone3"]))
			# elif key == KeyMapping.Takeoff4:
			# 	self.takeoff(drones = set(["/Drone4"]))
			# elif key ==KeyMapping.FollowReference1:
			# 	self.followRef(drones = set(["/Drone1"]))
			# elif key ==KeyMapping.FollowReference2:
			# 	self.followRef(drones = set(["/Drone2"]))
			# elif key ==KeyMapping.FollowReference3:
			# 	self.followRef(drones = set(["/Drone3"]))
			# elif key ==KeyMapping.FollowReference4:
			# 	self.followRef(drones = set(["/Drone4"]))
			# elif key ==KeyMapping.FollowWaypoint1:
			# 	self.followWayP(drones = set(["/Drone1"]))
			# elif key ==KeyMapping.FollowWaypoint2:
			# 	self.followWayP(drones = set(["/Drone2"]))
			# elif key ==KeyMapping.FollowWaypoint3:
			# 	self.followWayP(drones = set(["/Drone3"]))
			# elif key ==KeyMapping.FollowWaypoint4:
			# 	self.followWayP(drones = set(["/Drone4"]))

	def emergencyAll(self):
		'''
		This function is called when emergency button/key is pressed
		request an emergency service through controller when called
		:return:
		'''
		drone_IDs = np.arange(self.num_drones) + 1
		self.safe_conduct_client(EventEnum.EmergencyRequested, drone_IDs)


	def takeoff(self, _ = None, drones = "fromDroneWindow"):
		'''
		This function is called when takeoff button/key is pressed
		request an takeoff service through controller
		:param _: GUI button clicked signal. Added as a default param to
					  keep compatiblity with keyboard controller
		:param drone: if the drone is selected from the GUI, then is default value
					  othersiwe, it will be a set which contains
					  one of "All", "/Drone1", "Drone2', etc
		:return:
		'''
		if drones == "fromDroneWindow":
			# self.droneSelected is also a set which contains names of drone selected
			# E.g. ["All", "/Drone1"]
			drones = self.droneSelected
		if "All" in drones:
			drone_IDs = np.arange(self.num_drones) + 1
		else:
			drone_IDs = []
			for drone in drones:
				# self.controllers[drone].takeOff()
				drone_IDs.append(int(drone[6:]))

		self.safe_conduct_client(EventEnum.TakeoffRequested, drone_IDs)

	def land(self, _ = None, drones = "fromDroneWindow"):
		'''
		This function is called when land button/key is pressed
		request an land service through controller
		:param _: GUI button clicked signal. Added as a default param to
					  keep compatiblity with keyboard controller
		:param drone: if the drone is selected from the GUI, then is default value
					  	  othersiwe, it will be a set which contains
	  					  one of "All", "/Drone1", "Drone2', etc
		:return:
		'''
		if drones == "fromDroneWindow":
			drones = self.droneSelected
		if "All" in drones:
			# for controller in self.controllers.values():
			# 	controller.land()
			drone_IDs = np.arange(self.num_drones) + 1

		else:
			drone_IDs = []
			for drone in drones:
				# self.controllers[drone].land()
				drone_IDs.append(int(drone[6:]))
		self.stop_controller()
		self.safe_conduct_client(EventEnum.LandRequested, drone_IDs)


	def hover(self, _ = None, drones = "fromDroneWindow"):
		if drones == "fromDroneWindow":
			drones = self.droneSelected
		if "All" in drones:
			# for controller in self.controllers.values():
			# 	controller.land()
			drone_IDs = np.arange(self.num_drones) + 1

		else:
			drone_IDs = []
			for drone in drones:
				print(drone)
				# self.controllers[drone].land()
				drone_IDs.append(int(drone[6:]))
		self.stop_controller()
		self.safe_conduct_client(EventEnum.HoverRequested, drone_IDs)


	def load_controller(self):
		input_name = self.ui.ctrlName.currentText()
		if (len(input_name) ==0):
			rospy.logwarn("[GUI]: Please input controller name!")
		else:
			self.add_controller(str(input_name))


	def start_controller(self):
		input_name = self.ui.ctrlName.currentText()
		if (len(input_name) ==0):
			rospy.logwarn("[GUI]: Please input controller name!")
		else:
			self.req_custom_control(ControllerStatusEnum.ON, str(input_name))

	def stop_controller(self):
		input_name = self.ui.ctrlName.currentText()
		if (len(input_name) ==0):
			rospy.logwarn("[GUI]: Please input controller name!")
		else:
			self.req_custom_control(ControllerStatusEnum.OFF, str(input_name))

	def pause_controller(self):
		input_name = self.ui.ctrlName.currentText()
		if (len(input_name) ==0):
			rospy.logwarn("[GUI]: Please input controller name!")
		else:
			self.req_custom_control(ControllerStatusEnum.PAUSED, str(input_name))

	def add_logger(self):
		controller_name = self.ui.ctrlName.currentText()
		output_dir = self.ui.outputDirText.toPlainText()
		if len(output_dir)!=0 and output_dir[-1] != '/':
			output_dir += '/'

		if(len(controller_name) ==0):
			rospy.logwarn("[GUI]: Please type controller name in the Custom Controller Block to use logger!")
		else:
			self.req_logger_add(str(controller_name), str(output_dir))

	def start_logger(self):
		controller_name = self.ui.ctrlName.currentText()

		if(len(controller_name) == 0):
			rospy.logwarn("[GUI]: Please type controller name in the Custom Controller Block to use logger!")
		else:
			self.req_logger_action(True, str(controller_name))

	def stop_logger(self):
		controller_name = self.ui.ctrlName.currentText()

		if(len(controller_name) == 0):
			rospy.logwarn("[GUI]: Please type controller name in the Custom Controller Block to use logger!")
		else:
			self.req_logger_action(False, str(controller_name))

	def updateControllerHubStatus(self, msg):
		curr_controller =  str(self.ui.ctrlName.currentText())
		for i in range(len(msg.controllers_name)):
			if msg.controllers_name[i] == curr_controller:
				status = msg.controllers_status[i]
				self.ui.ctrlstatusLabel.setText(status)


# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('crazyflie_user_interface')

	# Now we construct our Qt Application and associated controllers and windows
	app = QtGui.QApplication(sys.argv)


	display = KeyboardController()
	display.show()


	# executes the QT application
	status = app.exec_()

	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)
