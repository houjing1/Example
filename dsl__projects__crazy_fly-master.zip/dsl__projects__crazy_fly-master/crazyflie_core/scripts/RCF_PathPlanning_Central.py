#!/usr/bin/env python

'''
Implementation of paper,

Generation of collision-free trajectories for a quadrocopter fleet: a sequential convex programming approach
Available: http://www.dynsyslab.org/wp-content/papercite-data/pdf/augugliaro-iros12.pdf

Author: Xintong Du
Email: xintong.du@mail.utoronto.ca
'''

import pyipopt
import numpy as np
from scipy.linalg import block_diag
from scipy.interpolate import CubicSpline

POS = 0;
VEL= 1;
ACC = 2;
JRK = 3;
STATE_X = 0;
STATE_Y = 1;
STATE_Z = 2;
INF_BOUND = 200 #2.0 * pow(10.0, 9)
g = 9.81
NUM_NZ_JAC = 0
NUM_NZ_HSS = 0



class CollisionFreeTraj():
    def __init__(self, num_agent, init, final, lb, ub, dis_min, traj_time, h):
        self.num_agent = int(num_agent)
        self.traj_time = traj_time
        self.h = h
        self.K = int(self.traj_time / self.h)
        self.num_var = 3 * self.num_agent * self.K
        self.num_cons_pos = 3 * self.num_agent * self.K
        self.num_cons_vel = 3 * self.num_agent * self.K
        self.num_cons_jrk = 3 * self.num_agent * (self.K - 1)
        self.num_cons_mindis = self.num_agent * (self.num_agent - 1) / 2 * self.K
        self.num_cons_nonlinear = self.num_cons_pos + self.num_cons_vel + self.num_cons_jrk + self.num_cons_mindis

        self.set_init_final_states(init, final)
        self.set_states_bound(lb, ub)
        self.set_min_dis_bound(dis_min)

        self.tolerance = 0.01

    def set_init_final_states(self, init, final):
        '''
        inputs:
        init: [pos[1], vel[1], acc[1]] R^3X3
        final: [pos[1], vel[1], acc[1]] R^3X3
        '''

        self.init_states = np.array(init, dtype="float")
        self.final_states = np.array(final, dtype="float")


    def set_states_bound(self, lb, ub):
        '''
        inputs:
        lb: lower bound [pos, vel, acc, jerk]
        ub: upper bound [pos, vel, acc, jerk]

        We assume bounds are the same for all robots at all time step
        '''
        lb = list(lb)
        ub = list(ub)
        self.lb = lb
        self.ub = ub


        pos = [lb[POS]] * self.num_agent * self.K
        vel = [lb[VEL]] * self.num_agent * self.K
        acc = [lb[ACC]] * self.num_agent * self.K
        jrk = [lb[JRK]] * self.num_agent * (self.K - 1)

        self.pos_lb = np.array(pos, dtype="float").reshape(self.num_agent, self.K, 3)
        self.vel_lb = np.array(vel, dtype="float").reshape(self.num_agent, self.K, 3)
        self.acc_lb = np.array(acc, dtype="float").reshape(self.num_agent, self.K, 3)
        self.jrk_lb = np.array(jrk, dtype="float").reshape(self.num_agent, (self.K - 1), 3)


        pos = [ub[POS]] * self.num_agent * self.K
        vel = [ub[VEL]] * self.num_agent * self.K
        acc = [ub[ACC]] * self.num_agent * self.K
        jrk = [ub[JRK]] * self.num_agent * (self.K - 1)
        self.pos_ub = np.array(pos, dtype="float").reshape(self.num_agent, self.K, 3)
        self.vel_ub = np.array(vel, dtype="float").reshape(self.num_agent, self.K, 3)
        self.acc_ub = np.array(acc, dtype="float").reshape(self.num_agent, self.K, 3)
        self.jrk_ub = np.array(jrk, dtype="float").reshape(self.num_agent, self.K - 1, 3)


        self.pos_lb[:, 0] = self.init_states[:,POS]
        self.pos_ub[:, 0] = self.init_states[:,POS]
        self.vel_lb[:, 0] = self.init_states[:,VEL]
        self.vel_ub[:, 0] = self.init_states[:,VEL]
        self.acc_lb[:, 0] = self.init_states[:,ACC]
        self.acc_ub[:, 0] = self.init_states[:,ACC]

        self.pos_lb[:, self.K-1] = self.final_states[:, POS]
        self.pos_ub[:, self.K-1] = self.final_states[:, POS]
        self.vel_lb[:, self.K-1] = self.final_states[:, VEL]
        self.vel_ub[:, self.K-1] = self.final_states[:, VEL]
        self.acc_lb[:, self.K-1] = self.final_states[:, ACC]
        self.acc_ub[:, self.K-1] = self.final_states[:, ACC]

    def set_min_dis_bound(self, dis_min):
        '''
        input:
        dis_min: minimum distance between any pair of robots at any time step
        '''
        self.dis_min = dis_min

        self.dis_lb = [dis_min ** 2] * self.num_cons_mindis
        self.dis_ub = [INF_BOUND] * self.num_cons_mindis

        self.dis_lb = np.array(self.dis_lb, dtype="float")
        self.dis_ub = np.array(self.dis_ub, dtype="float")

    def finalize_bounds(self):
        '''
        finalize bounds for non-linear constraints(g(x) in solver example)
        and linear constraint(x in solver exmaple)

        sequence of non-linear constraints:
            position    3*N*K
            velocity    3*N*K
            jerk        3*N*K
            minimum distance N*(N-1)/2*K

        linear constraints:
            acceleration 3*N*k

        All organized as 1-D array with sequence:
            state dimension,
            time,
            agent
        '''
        self.g_L = np.vstack((self.pos_lb, self.vel_lb)).reshape((2*self.num_cons_pos,))
        self.g_L = np.hstack((self.g_L, self.jrk_lb.reshape((self.num_cons_jrk,)), self.dis_lb))

        self.g_U = np.vstack((self.pos_ub, self.vel_ub)).reshape((2*self.num_cons_pos,))
        self.g_U = np.hstack((self.g_U, self.jrk_ub.reshape((self.num_cons_jrk,)), self.dis_ub))
        assert len(self.g_U) == self.num_cons_nonlinear
        assert len(self.g_L) == self.num_cons_nonlinear

        self.x_L = self.acc_lb.reshape((self.num_var,))
        self.x_U = self.acc_ub.reshape((self.num_var,))

    def eval_f(self, x):
        '''
        input:
        x: acceleration of all agents at all time step, R^(3*N*K)

        return:
        cost function: sum of thrust(squared)
        '''

        assert len(x) == self.num_var

        x = np.array(x, dtype="float")

        ngravity = np.array([[0,0,g]] * self.num_agent * self.K,dtype="float").reshape((self.num_var,))
        thrust = x + ngravity

        return np.sum(thrust**2)

    def eval_grad_f(self, x):
        '''
        input:
        x: acc

        return:
        gradient of cost function:
            f = (acc + grav).T(acc + grav)
            grad_f = 2 * (acc + grav)
        '''
        assert len(x) == self.num_var


        x = np.array(x, dtype="float")
        ngravity = np.array([[0,0,g]] * self.num_agent * self.K, dtype="float").reshape((self.num_var,))
        grad_f = 2 * (x + ngravity)

        return np.array(grad_f)

    def get_position(self,x):
        '''
        input:
        x: acceleration
        '''
        x = np.array(x, dtype="float")
        x = x.reshape((self.num_agent, self.K, 3))
        position = []
        for agent in range(self.num_agent):
            # position
            #taylor_exp = self.init_states[agent][POS]
            taylor_exp = self.init_states[agent][POS]+ \
                        (self.h * np.arange(self.K).reshape((self.K,1))) * self.init_states[agent][VEL] +\
                        self.h ** 2 / 2 * self.C_acc_pos *np.matrix(x[agent])
            position.append(taylor_exp)

        return np.array(position)

    def get_velocity(self,x):
        '''
        input:
        acceleration
        output:
        velocity
        '''

        x = np.array(x, dtype="float")
        x = x.reshape((self.num_agent, self.K, 3))
        velocity = []

        for agent in range(self.num_agent):
            taylor_exp = self.init_states[agent][VEL] +\
                         self.h * self.C_acc_vel * np.matrix(x[agent])
            velocity.append(taylor_exp)

        return np.array(velocity)


    def get_matrices(self):
        self.C_acc_pos = []
        self.C_acc_vel = []
        self.C_acc_jrk = []

        for i in range(self.K):
            # acceleration -> position
            row = np.zeros((self.K,))
            if i != 0:
                row[:i] = np.arange(2 * i - 1, -1, -2)
            self.C_acc_pos.append(row)

            # accleration -> velocity
            if i == 0:
                self.C_acc_vel.append([0] * self.K)
            else:
                row = np.zeros((self.K,))
                row[:i] = np.ones((i,))
                self.C_acc_vel.append(row)

            # acceleration -> jerk
            if i != self.K-1:
                row = np.zeros(self.K)
                row[i:i+2] = np.array([-1, 1], dtype="float")
                self.C_acc_jrk.append(row)

        self.C_acc_pos = np.matrix(self.C_acc_pos)
        self.C_acc_vel = np.matrix(self.C_acc_vel)
        self.C_acc_jrk = np.matrix(self.C_acc_jrk)


    def eval_g(self, x):
        '''
        evaluate non-linear constraints

        sequence of non-linear constraints:
            position    3*N*K
            velocity    3*N*K
            jerk        3*N*K
            minimum distance N*(N-1)*K

        All organized as 1-D array with order:
            state dimension,
            time,
            agent

        return:
        g(x): position, velocity, jerk, distances between drones, as a 1-D array

        NOTE:
        order of g(x) should be the same as constraints
        '''
        assert len(x) == self.num_var

        x = np.array(x, dtype="float").reshape((self.num_agent, self.K, 3))

        self.get_matrices()


        position = []
        velocity = []
        jerk = []
        min_distance = []

        for agent in range(self.num_agent):
            # position
            #taylor_exp = self.init_states[agent][POS]

            taylor_exp = self.init_states[agent][POS] + \
                         self.h * np.arange(self.K).reshape((self.K,1)) * \
                         self.init_states[agent][VEL] +\
                         self.h ** 2 / 2 * self.C_acc_pos *np.matrix(x[agent])
            position.append(taylor_exp)

            # velocity
            taylor_exp = self.init_states[agent][VEL] +\
                         self.h * self.C_acc_vel * np.matrix(x[agent])
            velocity.append(taylor_exp)

            # jerk
            taylor_exp = self.C_acc_jrk * np.matrix(x[agent]) / self.h
            jerk.append(taylor_exp)

        for agent in range(self.num_agent):
            # distance between a pair of agents
            for agent_prime in range(agent+1, self.num_agent):
                pos1 = np.array(position[agent], dtype="float")
                pos2 = np.array(position[agent_prime], dtype="float")
                dis = np.sum((pos1 - pos2) ** 2, axis=1)
                min_distance.append(dis)

        position = np.array(position, dtype="float").reshape((self.K * self.num_agent * 3,))
        velocity = np.array(velocity, dtype="float").reshape((self.K * self.num_agent * 3,))
        jerk = np.array(jerk, dtype="float").reshape(((self.K-1) * self.num_agent * 3,))
        min_distance = np.array(min_distance, dtype="float").reshape((self.num_agent *(self.num_agent -1) / 2 * self.K, ))

        g = np.hstack((position, velocity, jerk, min_distance))
        g = g.reshape((self.num_cons_nonlinear,))
        return g


    # def encoder_pair(self, ind1, ind2):
    #     res = self.num_agent - ind1
    #     res = ((res - 1) + res + ind1) * ind1 / 2
    #     res += ind2 - ind1 - 1
    #     return res

    def encoding_pair(self, ind1, ind2):
        return (self.num_agent - 1) * ind1 - (ind1 - 1) * ind1 / 2 + (ind2 - ind1 - 1)

    def encoder(self, info):
        '''
        input:
        info: information of a particular non-linear constraint
        return:
        the index of constaint in g(as computed in eval_g)
        '''
        agent_index = info[0]
        time_index = info[1]
        state_d = info[2]
        info_type = info[3]
        if info_type < 2:
            return info_type * self.num_agent * self.K * 3 + agent_index * self.K * 3 + time_index * 3 + state_d
        if info_type == 2:
            return info_type * self.num_agent * self.K * 3 + agent_index * (self.K-1) * 3 + time_index * 3 + state_d

        agent_index2 = state_d
        #return self.num_agent * self.K * 9 +  time_index * self.num_agent * (self.num_agent - 1) / 2 + encoder_pair(agent_index, agent_index2)
        return self.num_agent * (self.K * 6 + (self.K - 1) * 3) + self.encoding_pair(agent_index, agent_index2) * self.K + time_index

    def eval_jac_g(self, x, flag):
        '''
        evaluate jacobian of non-linear constraints

        sequence of non-linear constraints:
            position    3*N*K
            velocity    3*N*K
            jerk        3*N*K

            minimum distance N*(N-1)/2*K

        All organized as 1-D array with order:
            state dimension,
            time,
            agent

        return:
        grad_g(x): gradient of contraints, position, velocity, jerk, distances between drones, as a 1-D array

        self.C_acc_pos = K*K
        self.C_acc_vel = K*K
        self.C_acc_jrk =

        '''
        if flag == True:
            x = np.ones(self.num_var) * np.random.randn(self.num_var)


        # p_i = C + h^2 / 2 * self.C_acc_pos * a_i
        # v_i = C + h * self.C_acc_vel * a_i
        # j_i = 1/h * self.C_acc_jrk * a_i
        matrix_ind1 = []
        matrix_ind2 = []
        cell_values = []

        # taking derivative of
        #   P[agent_index][time_index1][state_d] w.r.t a[agent_index][time_index2][state_d]
        #   Same for Velocity and jerk
        for agent_index in range(self.num_agent):
            for time_index1 in range(self.K):
                for state_d in range(3):
                    for time_index2 in range(self.K):
                        cell_value = self.C_acc_pos[time_index1, time_index2] * (self.h ** 2) / 2

                        if cell_value != 0:
                            info1 = [agent_index, time_index1, state_d, POS]
                            info2 = [agent_index, time_index2, state_d, 0]
                            matrix_ind1.append(self.encoder(info1))
                            matrix_ind2.append(self.encoder(info2))
                            cell_values.append(cell_value)

                        cell_value = self.C_acc_vel[time_index1, time_index2] * self.h
                        if cell_value !=0:
                            info1 = [agent_index, time_index1, state_d, VEL]
                            info2 = [agent_index, time_index2, state_d, 0]
                            matrix_ind1.append(self.encoder(info1))
                            matrix_ind2.append(self.encoder(info2))
                            cell_values.append(cell_value)

                        if time_index1 != self.K-1:
                            cell_value = self.C_acc_jrk[time_index1, time_index2] / self.h
                            if cell_value != 0:
                                # since ACC is not in g(x), we need JRK-1 to access the correct index
                                info1 = [agent_index, time_index1, state_d, JRK-1]
                                info2 = [agent_index, time_index2, state_d, 0]
                                matrix_ind1.append(self.encoder(info1))
                                matrix_ind2.append(self.encoder(info2))
                                cell_values.append(cell_value)
        # taking derivative of
        # (P[agent_index1][time_index1] - P[agent_index2][time_index1])T(P[agent_index1][time_index1] - P[agent_index2][time_index1])
        # w.r.t
        # a[agent_index1][time_index2][state_d] and a[agent_index2][time_index2][state_d]
        for agent_index1 in range(self.num_agent):
            for agent_index2 in range(agent_index1+1, self.num_agent):
                position = self.get_position(x)
                pos1 = position[agent_index1]
                pos2 = position[agent_index2]
                for time_index1 in range(self.K):
                    C_k = self.C_acc_pos[time_index1].reshape((self.K,1))
                    grad = 2 * C_k * (pos1[time_index1] - pos2[time_index1]) * (self.h ** 2) / 2
                    for time_index2 in range(self.K):
                        for state_d in range(3):
                            cell_value = grad[time_index2,state_d]
                            if cell_value != 0:
                                #print(x)

                                info1 = [agent_index1, time_index1, agent_index2, 3]
                                info2 = [agent_index1, time_index2, state_d, 0]
                                info3 = [agent_index2, time_index2, state_d, 0]
                                matrix_ind1.append(self.encoder(info1))
                                matrix_ind2.append(self.encoder(info2))
                                cell_values.append(cell_value)

                                matrix_ind1.append(self.encoder(info1))
                                matrix_ind2.append(self.encoder(info3))
                                cell_values.append(-cell_value)


        gradient = np.zeros((self.num_cons_nonlinear, self.num_var))
        gradient[np.array(matrix_ind1), np.array(matrix_ind2)] = cell_values

        if flag:
            global NUM_NZ_JAC
            NUM_NZ_JAC = len(matrix_ind1)
            return (np.array(matrix_ind1), np.array(matrix_ind2))
        else:
            assert len(x) == self.num_var
            #print(cell_values)
            return np.array(cell_values, dtype="float")

    def decoder(self, agent_index, time_index, state_d):
        return agent_index *  3 * self.K + time_index * 3 + state_d


    def eval_h(self, x, lagrange, obj_factor, flag):

        if flag:
            lagrange = np.ones(self.num_cons_nonlinear)
            x = np.ones(self.num_var)
            obj_factor = 1

        hss = {(i,j):0 for i in range(self.num_var) for j in range(i+1)}

        for agent_index1 in range(self.num_agent):
            for agent_index2 in range(agent_index1 + 1, self.num_agent):
                for time_index in range(self.K):
                    const_info = [agent_index1, time_index, agent_index2, 3]
                    #print(agent_index1, time_index, agent_index2,self.encoder(const_info))
                    const_index = self.encoder(const_info)
                    lambda_const = lagrange[const_index]

                    C_k = self.C_acc_pos[time_index]
                    grad = 2 * C_k.reshape((self.K,1)) * C_k * self.h**4 / 4
                    for time_index1 in range(self.K):
                        for time_index2 in range(self.K):
                            cell_value_ii = grad[time_index1, time_index2] * lambda_const
                            cell_value_jj = grad[time_index1, time_index2] * lambda_const
                            cell_value_ij = -grad[time_index1, time_index2] * lambda_const
                            for state_d in range(3):
                                if cell_value_ii != 0:
                                    info1 = self.encoder([agent_index1, time_index1, state_d, 0])
                                    info2 = self.encoder([agent_index1, time_index2, state_d, 0])
                                    if info1 >= info2:
                                        hss[(info1, info2)] += cell_value_ii

                                    info1 = self.encoder([agent_index2, time_index1, state_d, 0])
                                    info2 = self.encoder([agent_index2, time_index2, state_d, 0])
                                    if info1 >= info2:
                                        hss[(info1, info2)] += cell_value_ii

                                if cell_value_ij != 0:
                                    info1 = self.encoder([agent_index1, time_index1, state_d, 0])
                                    info2 = self.encoder([agent_index2, time_index2, state_d, 0])
                                    if info1 >= info2:
                                        hss[(info1, info2)] += cell_value_ij

                                    info1 = self.encoder([agent_index2, time_index1, state_d, 0])
                                    info2 = self.encoder([agent_index1, time_index2, state_d, 0])
                                    if info1 >= info2:
                                        hss[(info1, info2)] += cell_value_ij

        for i in range(self.num_var):
            hss[(i,i)] += 2 * obj_factor
        keys = np.array(hss.keys())
        matrix_ind1 = np.array(keys)[:,0]
        matrix_ind2 = np.array(keys)[:,1]
        cell_values = [hss[(matrix_ind1[i],matrix_ind2[i])] for i in range(len(matrix_ind1))]

        #print(cell_values)
        # gradient = np.zeros((self.num_var, self.num_var))
        # gradient[np.array(matrix_ind1,dtype="int"), np.array(matrix_ind2,dtype="int")] = cell_values
        # print(gradient)


        if flag:
            global NUM_NZ_HSS
            NUM_NZ_HSS = len(matrix_ind1)
            return (np.array(matrix_ind1), np.array(matrix_ind2))
        else:
            return np.array(cell_values, dtype="float")

    def create_solver(self):
        self.finalize_bounds()
        print("num g(x):",self.num_cons_nonlinear)
        self.get_matrices()

        x_test = np.ones((self.num_var,))
        lagrange = np.ones(self.num_cons_nonlinear)
        obj_factor = 1
        self.eval_jac_g(np.ones((self.num_var,)), True)
        self.eval_h(np.ones((self.num_var,)),lagrange, obj_factor,True)

        self.nlp = pyipopt.create(self.num_var, \
                                  self.x_L, \
                                  self.x_U, \
                                  self.num_cons_nonlinear, \
                                  self.g_L, \
                                  self.g_U, \
                                  NUM_NZ_JAC, \
                                  0, \
                                  self.eval_f, \
                                  self.eval_grad_f, \
                                  self.eval_g, \
                                  self.eval_jac_g)
        self.nlp.str_option('linear_solver', 'ma86')
        self.nlp.num_option('tol', 1e-1)
        self.nlp.num_option('constr_viol_tol', 5e-3)
        self.nlp.num_option('dual_inf_tol', 1)
        self.nlp.num_option('compl_inf_tol', 1e-1)
        self.nlp.int_option('max_iter', 2000)

        #self.nlp.str_option('derivative_test', 'second-order')
        #self.nlp.num_option('derivative_test_perturbation', 5e-8)
        #self.nlp.str_option('derivative_test_print_all', 'yes')

    def get_acc(self, x0):

        self.acc, zl, zu, constraint_multipliers, obj, status = self.nlp.solve(x0)
        self.nlp.close()

        return self.acc, status

class RCFP_Central():

    def __init__(self, num_agent, init, final, lb, ub, dis_min, traj_time=1.5, h=0.2):
        self.num_agent = num_agent
        self.init = init
        self.final = final
        self.lb = lb
        self.ub = ub
        self.dis_min = dis_min
        self.traj_time = traj_time
        self.h = h

    def get_trajectory(self):
        print("initial:", self.init)
        print("final", self.final)

        self.status = 2
        i = 0
        while(self.status != 0 and self.status != 1):
            print("iteration:", i)
            i += 1
            self.CFT = CollisionFreeTraj(self.num_agent, \
                                        self.init, \
                                        self.final, \
                                        self.lb, \
                                        self.ub, \
                                        0, \
                                        self.traj_time, \
                                        self.h)
            self.CFT.create_solver()
            self.initial_guess, self.status = self.CFT.get_acc(np.zeros(self.CFT.num_var))

            if self.status == 2:
                self.traj_time = int(self.traj_time / self.h) * 1.5 * self.h

                continue

            self.CFT = CollisionFreeTraj(self.num_agent, \
                                        self.init, \
                                        self.final, \
                                        self.lb, \
                                        self.ub, \
                                        self.dis_min, \
                                        self.traj_time, \
                                        self.h)
            self.CFT.create_solver()
            self.acc, self.status = self.CFT.get_acc(self.initial_guess)

            print(self.status)

            if self.status == 2:
                self.traj_time = int(self.traj_time / self.h) * 1.2 * self.h

                continue
            else:
                if (self.status != 0 and self.status != 1):
                    print("undesired states:", self.status)
                self.vel = self.CFT.get_velocity(self.acc)
                self.pos = self.CFT.get_position(self.acc)
                self.acc = self.acc.reshape((self.num_agent, self.CFT.K, 3))

                t = np.arange(0, self.traj_time, self.h)
                # continuous position
                cs = CubicSpline(t, self.pos,axis=1)
                ts = np.arange(0, self.traj_time, self.h/2)
                self.pos_cont = np.array(cs(ts))
                exceed_bound = False
                for agent_index1 in range(self.num_agent):
                    for agent_index2 in range(agent_index1+1, self.num_agent):
                        pos1 = self.pos_cont[agent_index1]
                        pos2 = self.pos_cont[agent_index2]
                        dis = np.sum((pos1 - pos2) ** 2, axis=1) ** 0.5
                        indexes = np.where(dis < 0.15)[0]
                        if len(indexes) != 0:
                            exceed_bound = True
                            break
                if exceed_bound == True:
                    print("exceed_bound")

                    self.h = self.h / 2.0
                    self.status = 2
                    continue
                else:
                    print("Pass continous position test")
                    print(self.pos)
                    return [self.pos, self.vel, self.acc]
