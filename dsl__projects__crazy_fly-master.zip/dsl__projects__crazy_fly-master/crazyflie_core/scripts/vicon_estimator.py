#!/usr/bin/env python2

"""
Python Class to process messages of type TransformStamped and output the full state
(position, velocity, acceleration), by using the python class StateEstimator
"""

from __future__ import division, print_function
import rospy

import numpy
import tf.transformations as tf

from dsl__estimation__vicon.srv import GetState
from std_msgs.msg import Empty
from geometry_msgs.msg import TransformStamped
from dsl__utilities__msg.msg import StateData
from dsl__utilities__msg.msg import StateVector
from state_estimation import state_vector_to_data, StateEstimator

from crazyflie_core.msg import SwarmStates, FullState

# Needed to send numpy.array as a msg
from rospy.numpy_msg import numpy_msg


class ViconCoordinates(object):

    def __init__(self, filter_parameters):
        """Initialization."""
        super(ViconCoordinates, self).__init__()

        # Lock for access to state
        # Makes sure the service does not conflict with normal updatessub

        self.estimator = StateEstimator(filter_parameters)

        # Publish to the /current_coordinates topic
        # queue_size: Only continous time controllers should
        # subscribe to this, and they only care about the latest
        # state information. Everything else should use the service
        # self.pub_state = rospy.Publisher('estimated_state',
        #                                  numpy_msg(SwarmStates),
        #                                  queue_size=1)


    def convert_measurement(self, vicon):
        """Convert vicon measurements and calculate velocities.

        Parameters
        ----------
        vicon : geometry_msgs.msg.TransformStamped

        Returns
        -------
        time : float
        position : ndarray
        quaternion : ndarray
        """
        # Record the time at which the state was determined
        time = (float(vicon.header.stamp.secs)
                + float(vicon.header.stamp.nsecs) * 1e-9)

        # Get the translational position from VICON
        position = numpy.array([vicon.transform.translation.x,
                               vicon.transform.translation.y,
                               vicon.transform.translation.z])

        # Get the rotational position in the form of a quaternion
        quaternion = numpy.array([vicon.transform.rotation.x,
                                 vicon.transform.rotation.y,
                                 vicon.transform.rotation.z,
                                 vicon.transform.rotation.w])

        return time, position, quaternion

    def estimate_state(self, vicon):
        """Calculate the current state based on the VICON information.

        Parameters
        ----------
        vicon : geometry_msgs.msg.TransformStamped
        """

        time, position, quaternion = self.convert_measurement(vicon)

        # tic1 = rospy.Time.now()
        # t01 = (float(tic1.secs)
        #         + float(tic1.nsecs) * 1e-9)

        # Compute the velocities from the current and past measurements
        self.estimator.get_new_measurement(time, position, quaternion)

        # toc1 = rospy.Time.now()
        # tf1 = (float(toc1.secs)
        #         + float(toc1.nsecs) * 1e-9)
        # delay1 = tf1 - t01
        # #
        # tic2 = rospy.Time.now()
        # t02 = (float(tic2.secs)
        #         + float(tic2.nsecs) * 1e-9)
        # Predict future states (double integrator)
        # dt is not always constant, can't do it after publish_vicon()

        self.estimator.prior_update()
        #
        # toc2 = rospy.Time.now()
        # tf2 = (float(toc2.secs)
        #         + float(toc2.nsecs) * 1e-9)
        # delay2 = tf2 - t02
        # #
        # tic3 = rospy.Time.now()
        # t03 = (float(tic3.secs)
        #         + float(tic3.nsecs) * 1e-9)

        # Update with measurements
        self.estimator.measurement_update()

        # toc3 = rospy.Time.now()
        # tf3 = (float(toc3.secs)
        #         + float(toc3.nsecs) * 1e-9)
        # delay3 = tf3 - t03
        #
        # print("Delay of estimates = {0:.4f}, {1:.4f}, {2:.4f}".format(delay1*1000, delay2*1000, delay3*1000))
