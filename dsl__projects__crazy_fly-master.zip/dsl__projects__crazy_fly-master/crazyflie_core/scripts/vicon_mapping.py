#!/usr/bin/env python

from __future__ import division, print_function
import rospy
from vicon_bridge.msg import Markers
from vicon_bridge.msg import Marker
from sensor_msgs.msg import PointCloud
from std_srvs.srv import Empty
from geometry_msgs.msg import Point32
import numpy
from geometry_msgs.msg import TransformStamped, TwistStamped
from crazyflie_driver.srv import UpdateParams
from crazyflie_driver.msg import FullControl

update_rate = 100

mode = "Nonlinear"

class translator:
	#locations will hold the TransformStamped location of each crazyflie
	locations = {}
	num_drones = 1
	#pubs holds all the publishers for all tnew crazyflie messages
	point_clouds = {}
	baseClouds = {}
	pubs = {}
	takeoff_services = {}
	land_service = {}
	pub_cmd_vel = {}
	test_height = 60

	frame_drop_num_limit = 50
	seconds_to_failure = 1
	frame_drone_too_close_limit = 50
	frame_drop_num = {}
	frame_drone_too_close = {}
	trigger_height = 100
	update_params = {}
	last_markers = Markers()
	override = {}

	activate = {}

	def __init__(self, number_drones, positions):
		'''
		Initialize a translator (from vicon marker data to position estimate of crazyflie)
		:param number_drones:
		:param positions:
		'''
		self.time = rospy.Time.now()
		self.delay = 0.0
		self.num_drones = number_drones
		prefix = "/Drone"

		#positions is a dictionary of arrays, where the input is the name and the list contains the location of each individual marker
		for drone in positions:
			#rospy.wait_for_service(drone+"/override")
			#self.override[drone] = rospy.ServiceProxy(drone+"/override", Empty)
			m = Marker()
			m.translation.x = positions[drone][0]
			m.translation.y = positions[drone][1]
			m.translation.z = positions[drone][2]

			self.locations[drone] = m
			self.frame_drop_num[drone] = 0
			self.frame_drone_too_close[drone] = 0

	def read_vicon(self, Markers):
		self.time = rospy.Time.now()
		# self.time = Markers.header.stamp
		t0 = (float(self.time.secs)
				+ float(self.time.nsecs) * 1e-9)
		# print("t0 is : {} ".format(self.time))

		for i in range(len(Markers.markers)):
			if len(self.last_markers.markers) <= i:
				self.last_markers.markers.append(Marker())
			self.last_markers.markers[i].marker_name = Markers.markers[i].marker_name
			self.last_markers.markers[i].translation.x = Markers.markers[i].translation.x
			self.last_markers.markers[i].translation.y = Markers.markers[i].translation.y
			self.last_markers.markers[i].translation.z = Markers.markers[i].translation.z

		limit = 150
		for drone in self.locations:
			curr_pos = self.locations[drone]
			marker_index = None
			marker_num = 0
			for i in range(len(Markers.markers)):
				if Markers.markers[i].marker_name != "":
					continue
				marker_pos = Markers.markers[i]
				dist = self.dist(curr_pos, marker_pos)
				if dist < limit:
					marker_index = i
					marker_num += 1

			if marker_num > 1:						# If there are two markers in the scanning area, land the drone
				self.frame_drone_too_close[drone] += 1
				if self.frame_drone_too_close[drone] > self.frame_drone_too_close_limit:
					#print ("Drones are too close!")
					#self.land_service[drone]()
					pass
			elif marker_num == 0:					# If there is no marker in the scanning area for certain number of
				self.frame_drop_num[drone] += 1		# frames, land the drone
				if self.frame_drop_num[drone] > self.frame_drop_num_limit:
					#print("Vicon signal lost!")
					#self.land_service[drone]()
					pass
			else:									# If there is a unique marker in the scanning area, update the
				self.frame_drop_num[drone] = 0		# position of the drone to that position
				self.frame_drone_too_close[drone] = 0
				self.locations[drone].translation.x = Markers.markers[marker_index].translation.x
				self.locations[drone].translation.y = Markers.markers[marker_index].translation.y
				self.locations[drone].translation.z = Markers.markers[marker_index].translation.z
				#print("Marker:")
				#print([Markers.markers[marker_index].translation.x, Markers.markers[marker_index].translation.y, Markers.markers[marker_index].translation.z])
		final = rospy.Time.now()
		tf = (float(final.secs)
				+ float(final.nsecs) * 1e-9)
		self.delay = tf - t0
		# print("The delay is: {0:.2f} ms".format(self.delay*1000))

			#print("Crazyflie:")
			#print([self.locations[drone].translation.x, self.locations[drone].translation.y, self.locations[drone].translation.z])

	def run(self):
		#print("run")
		rate = rospy.Rate(update_rate)
		while not rospy.is_shutdown():
			for i in self.locations:
				m = TransformStamped()
				frame_id = "CF" + i[6:]
				m.header.frame_id = frame_id
				m.header.stamp = rospy.Time.now()
				m.transform.translation.x = self.locations[i].translation.x
				m.transform.translation.y = self.locations[i].translation.y
				m.transform.translation.z = self.locations[i].translation.z
				m.transform.translation.x /= 1000.0
				m.transform.translation.y /= 1000.0
				m.transform.translation.z /= 1000.0
				m.transform.rotation.x = 0.0
				m.transform.rotation.y = 0.0
				m.transform.rotation.z = 0.0
				m.transform.rotation.w = 1.0
				self.pubs[i].publish(m)
			rate.sleep()

	def dist(self, point, point2):
		return ((float(point.translation.x) - float(point2.translation.x))**2 + (float(point.translation.y) - float(point2.translation.y))**2 + (float(point.translation.z) - float(point2.translation.z))**2)**0.5

	def wait_for_update_param(self):
		if mode != "PID":
			return
		for i in range(self.num_drones):
			drone = "/Drone{}".format(i+1)
			rospy.wait_for_service(drone + '/update_params')
			self.update_params[drone] = rospy.ServiceProxy(drone+'/update_params', UpdateParams)

	def set_althold_mode(self, drone, althold):
		p = 0
		q = 1
		if not althold:
			p = 1
			q = 0

		if mode == "PID":
			rospy.set_param(drone+"/flightmode/posSet", p)
			self.update_params[drone](["flightmode/posSet"])
			rospy.set_param(drone+"/flightmode/althold", q)
			self.update_params[drone](["flightmode/althold"])

	def new_cmd(self, id):
		if mode == "PID":
			cmd = TwistStamped()
			cmd.header.frame_id = id
			cmd.twist.linear.x = 0
			cmd.twist.linear.y = 0
			cmd.twist.linear.z = 30000
			cmd.twist.angular.x = 0
			cmd.twist.angular.y = 0
			cmd.twist.angular.z = 0
			return cmd
		elif mode == "Nonlinear":
			cmd = FullControl()
			cmd.header.frame_id = id
			cmd.enable = True
			cmd.xmode = 0b001
			cmd.ymode = 0b001
			cmd.zmode = 0b001
			cmd.x = [0,0,0]
        	cmd.y = [0,0,0]
        	cmd.z = [0,0,0]
        	cmd.yaw = [0,0]
    		return cmd


	def auto_assign(self, req):
		possible_markers = []
		for marker in self.last_markers.markers:
			#print (marker.marker_name)
			if marker.marker_name != "":
				continue
			x, y, z = marker.translation.x, marker.translation.y, marker.translation.z
			if z < 75 and x < 3000 and x > -3000 and y < 3000 and y > -3000:
				possible_markers.append(marker)

		#print (len(possible_markers))
		if len(possible_markers) < self.num_drones:
			print ("Could not find enough empty markers in the center of arena!")
			#return

		self.wait_for_update_param()
		for i in range(self.num_drones):
			drone = '/Drone{}'.format(i+1)
			self.set_althold_mode(drone, True)
			rate = 100.0
			rt = rospy.Rate(rate)
			count = 0
			success = False
			while count < self.seconds_to_failure:
				count += 1 / rate
				### Publishing coammands for a small takeeoff or land
				t = self.new_cmd(drone[6:])
				if count < 0.25:
 					if mode == "PID":
						t.twist.linear.z = 30000
					elif mode == "Nonlinear":
						t.z[2] = 0.01
					self.pub_cmd_vel[drone].publish(t)
				elif count < 0.5:
					if mode == "PID":
						t.twist.linear.z = 24000
					elif mode == "Nonlinear":
						t.z[2] = -0.2
				else:
					if mode == "PID":
						t.twist.linear.z = 0
					elif mode == "Nonlinear":
						t.z[2] = 0
						t.enable = False
				self.pub_cmd_vel[drone].publish(t)

				for marker in possible_markers:
					x, y, z = marker.translation.x, marker.translation.y, marker.translation.z
					if z >= self.test_height:
						success = True
						self.locations[drone].translation.x = x
						self.locations[drone].translation.y = y
						self.locations[drone].translation.z = z
						#print (self.locations[drone])
				rt.sleep()

			if success:
				print ("Drone %s configured Successfully"%(drone[6:]))
			else:
				print ("Drone %s failed to configure"%(drone[6:]))
			self.set_althold_mode(drone, False)

		return ()

if __name__=="__main__":
	rospy.init_node("crazyflie_vicon_translator")
	number_drones = rospy.get_param("~num_drones", 1)
	#my_file = Path("crazyflie_initial_state.yaml")
	positions = {}
	'''if my_file.is_file():
		with open('crazyflie_initial_state.yaml','r') as f:
			doc = yaml.load(f)
			for i in range(number_drones):
				positions["crazyflie" + str(1+i)] = (float(doc["crazyflie" + str(1+i)]["x"]), float(doc["crazyflie" + str(1+i)]["y"]), float(doc["crazyflie" + str(1+i)]["z"]))
			#do stuff if else
	'''
 	for i in range(number_drones):
		x = rospy.get_param("/Drone{}/init_x".format(i + 1)) * 1000.0
		y = rospy.get_param("/Drone{}/init_y".format(i + 1)) * 1000.0
		z = rospy.get_param("/Drone{}/init_z".format(i + 1)) * 1000.0
		positions["/Drone{}".format(i+1)] = (x, y, z)

	rospy.loginfo("Starting")
	#positions = {"/Drone1":(-500,-500,0), "/Drone2":(500,500,0), "/Drone3": (0, 0, 0)}
	t = translator(number_drones, positions)
	rospy.Subscriber("/vicon/markers", Markers, t.read_vicon)
	rospy.loginfo("ready for ascent")
	rospy.Service("auto_assign", Empty, t.auto_assign)
	#rospy.Service("random_assign", Empty, t.random_assign)
	#rospy.Service("assigned_takeoff", Empty, t.assigned_takeoff)

	#t.auto_assign(None)
	t.run()
	rospy.spin()
