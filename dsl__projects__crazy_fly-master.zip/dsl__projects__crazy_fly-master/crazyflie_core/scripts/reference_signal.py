#!/usr/bin/env python

import rospy
import math
import numpy as np
import tf
from dsl__utilities__msg.msg import StateData
#from sensor_msgs.msg import Joy
from math import fabs
from std_srvs.srv import Empty as Emptysrv

lastData = None

class SimpleTrajectory(object):
    def __init__(self, model):
        self.worldFrame = rospy.get_param("~worldFrame", "/world")
        self.name = model + "/path_coordinates"
        self.r = rospy.get_param("~cmd_rate",30)
        self.num_drones = rospy.get_param('~num_drones',1)
        self.drone_id = int(model[6:])
        self.traj_inx = rospy.get_param("~traj_inx", "circle")
        self.plane = rospy.get_param("~plane", "xy")
        self.use_nonlinear_controller = rospy.get_param("nonlinear_controller", False)
        rospy.set_param("~traj_inx", self.traj_inx)
        rospy.set_param("~plane", self.plane)


        self.init_x = rospy.get_param(model + "/init_x", 0)
        self.init_y = rospy.get_param(model + "/init_y", 0)
        self.init_z = rospy.get_param(model + "/init_z", 0)
        self.s = np.array([self.init_x, self.init_y, 1.5])
        self.ref_pub = rospy.Publisher(self.name, StateData, queue_size=10)

        self.start = False
        self.count = 0

        self.target_state = StateData()
        self.target_state.header.stamp = rospy.get_rostime()
        self.target_state.x = self.init_x
        self.target_state.y = self.init_y
        self.target_state.z = 0
        self.target_state.vx = 0
        self.target_state.vy = 0
        self.target_state.vz = 0
        self.target_state.yaw = 0

    def run(self):
        self.timer = rospy.Timer(rospy.Duration(1.0/self.r), self.publish_path)
        self.start = True

    def publish_path(self, _):
        print("Start Following")
        start_time = rospy.get_rostime()
        start_time = start_time.secs + start_time.nsecs * 10 ** (-9)
        k = 0

        self.traj_inx = rospy.get_param("~traj_inx", "polar_curve")
        self.plane = rospy.get_param("~plane", "yz")
        while self.start:
            now = rospy.get_rostime()
            now_time = now.secs + now.nsecs * 10 ** (-9)
            elapse = now_time - start_time
            if self.count < 1:
                x, y, z, vx, vy, vz, ax, ay, az= self.getRef(elapse)
            else:
                x, y, z, vx, vy, vz, ax, ay, az= self.getRef(elapse)
            r = np.array([x,y,z])

            if (now_time - start_time > 1.5):
                if (np.sum((r-self.s)**2)**0.5 < 2e-2):
                    self.count += 1
                    start_time = rospy.get_rostime()
                    start_time = start_time.secs + start_time.nsecs * 10 ** (-9)

                    if self.count == 2:
                        self.count = 0
                        self.start = False

            self.target_state.header.stamp = now
            self.target_state.x = x
            self.target_state.y = y
            self.target_state.z = z
            self.target_state.vx = vx
            self.target_state.vy = vy
            self.target_state.vz = vz
            self.target_state.ax = ax
            self.target_state.ay = ay
            self.target_state.az = az
            self.target_state.yaw = 0

            self.ref_pub.publish(self.target_state)

        self.timer.shutdown()

    def getRef(self, time_n, accel=False):
        if self.traj_inx == "circle":
            target_radius = 1.0
            frequency = 0.15
            omega = 2.0 * math.pi * frequency
            z_0 = 1.5
            increase_time = target_radius * (2 / frequency)
            if self.use_nonlinear_controller and accel and time_n < increase_time:
                radius = target_radius/increase_time * time_n
            else:
                radius = target_radius

            phase_shift = (2.0/self.num_drones) * math.pi * (self.drone_id-1)

            dim_1 = (radius * np.cos(omega * time_n + phase_shift))
            dim_2 = (radius * np.sin(omega * time_n + phase_shift))
            dim_3 = 0
            dim_1_dot= -(radius * omega * np.sin(omega * time_n + phase_shift))
            dim_2_dot = (radius * omega * np.cos(omega * time_n + phase_shift))
            dim_3_dot = 0
            dim_1_ddot = -(radius * omega * omega * np.cos(omega * time_n + phase_shift))
            dim_2_ddot = -(radius * omega * omega * np.sin(omega * time_n + phase_shift))
            dim_3_ddot = 0
            return self.choosePlane(z_0, dim_1, dim_2, dim_3, dim_1_dot, dim_2_dot, dim_3_dot, dim_1_ddot, dim_2_ddot, dim_3_ddot)

        elif self.traj_inx == "polar_curve":
            target_radius = 1.4
            frequency = 0.2
            omega = frequency * math.pi
            phase_shift = (1.0 / self.num_drones) * math.pi * (self.drone_id-1)
            radius = 1
            z_0 = 1.5
            t = omega * time_n + phase_shift
            dim_1 = radius * np.cos(3 * t) * np.cos(t)
            dim_2 = radius * np.cos(3 * t) * np.sin(t)
            dim_3 = 0
            dim_1_dot = radius * (-3 * omega * np.cos(t) * np.sin(3 * t) - omega * np.sin(t) * np.cos(3 * t))
            dim_2_dot = radius * (-3 * omega * np.sin(t) * np.sin(3 * t) + omega * np.cos(t) * np.cos(3 * t))
            dim_3_dot = 0
            dim_1_ddot = radius * (6 * omega * omega * np.sin(t) * np.sin(3 * t) - 10 * omega * omega * np.cos(t) * np.cos(3 * t))
            dim_2_ddot = radius * (-6 * omega * omega * np.cos(t) * np.sin(3 * t) - 10 * omega * omega * np.sin(t) * np.cos(3 * t))
            dim_3_ddot = 0
            return self.choosePlane(z_0, dim_1, dim_2, dim_3, dim_1_dot, dim_2_dot, dim_3_dot, dim_1_ddot, dim_2_ddot, dim_3_ddot)
        else:
            return (0, 0, 0, 0, 0, 0)

    def choosePlane(self, z_0, dim_1, dim_2, dim_3, dim_1_dot, dim_2_dot, dim_3_dot, dim_1_ddot, dim_2_ddot, dim_3_ddot):
        if self.plane == "xy":
            return (dim_1, dim_2, dim_3 + z_0, dim_1_dot, dim_2_dot, dim_3_dot, dim_1_ddot, dim_2_ddot, dim_3_ddot)
        elif self.plane == "yz":
            return (dim_3, dim_1, dim_2 + z_0, dim_3_dot, dim_1_dot, dim_2_dot, dim_3_ddot, dim_1_ddot, dim_2_ddot)
        elif self.plane == "xz":
            return (dim_1, dim_3, dim_2 + z_0, dim_1_dot, dim_3_dot, dim_2_dot, dim_1_ddot, dim_3_ddot, dim_2_ddot)
        else:
            print ("Did not specify plane!")
            return None
if __name__=="__main__":
    '''code for testing'''
    rospy.init_node("SimpleTrajectory")
    signal = SimpleTrajectory("/Drone1")
    signal.run()
    rospy.spin()
