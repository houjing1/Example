#!/usr/bin/env python

"""Simulates the quadrocopter interfaced with ROS.
Written By: Adrian Esser and David Wu
Modified By: Philip Huang
Changes:
- Aug 2015 - Separated and vectorized quadrotor dynamics, PEP8
- May 2017 - Added onboard controller for crazyflie.
This ROS node represents a physically accurate drone object. It receives
flight commands from the crazyflie_nonlinear controller just as a real drone would do, and it
publishes it's state data to the Vicon/lps bridge too. Onboard control and
dynamics are all calculated in this file.

 SUBSCRIBED TOPICS
/Drone(1,2,...)/estimated_state
=======

 PUBLISHED TOPICS
/Drone(1,2,...)/external_position
=======
SUBSCRIBED TOPICS
/cmd_vel
/ardrone/takeoff
/ardrone/land
/path_coordinates
PUBLISHED TOPICS
/vicon/ARDroneShare/ARDroneShare
/ardrone/navdata
/gazebo/set_model_state
"""

from __future__ import division, print_function, absolute_import

import numpy as np
import rospy
import tf

from crazyflie_driver.srv import UpdateParams
from std_msgs.msg import Empty
from geometry_msgs.msg import TransformStamped, PointStamped
from dsl__utilities__msg.msg import StateVector


class ViconControllerBridge():

    def __init__(self):
        self.vicon_freq = 70
        #uri = rospy.get_param('~uri')
        #address = uri.split('/')[5]
        #self.id = int('0x' + address[-2:],0)    # id is the last two hex num of uri
        #self.id = str(self.id)
        self.id = rospy.get_namespace()
        self.id = self.id[6:-1] #get the id of the drone
        self.pub_extpos = rospy.Publisher('external_position', PointStamped, queue_size=1)
        self.sub_vicon = rospy.Subscriber('estimated_state', StateVector, self.cb)
        self.vicon_pos = [0] * 3

        rospy.wait_for_service('update_params')
        self._update_param = rospy.ServiceProxy('update_params', UpdateParams)

    def run(self):
        rospy.sleep(5)
        self.reset_ekf()
        rospy.pub_timer = rospy.Timer(rospy.Duration(1/self.vicon_freq), self.publish_pos)

    def cb(self, state):
        self.vicon_pos[0] = state.pos[0]
        self.vicon_pos[1] = state.pos[1]
        self.vicon_pos[2] = state.pos[2]
        #self.vicon_pos += 0.001 * np.random.randn(3)

    def publish_pos(self, _):
        vicon_pos = PointStamped()
        vicon_pos.header.frame_id = self.id
        vicon_pos.point.x, vicon_pos.point.y, vicon_pos.point.z = self.vicon_pos[0],\
                    self.vicon_pos[1], self.vicon_pos[2]
        self.pub_extpos.publish(vicon_pos)

    def reset_ekf(self):
        # print("resetting ekf1!!!!!!!!!!!!!!")
        rospy.set_param("kalman/resetEstimation", 1)
        self._update_param(["kalman/resetEstimation"])

        rospy.sleep(0.3)
        rospy.set_param("kalman/resetEstimation", 0)
        self._update_param(["kalman/resetEstimation"])


if __name__ == '__main__':
    rospy.init_node('vicon_cf_bridge')

    # Example forces that could be added to the Drone
    bridge = ViconControllerBridge()
    bridge.run()

    rospy.spin()
