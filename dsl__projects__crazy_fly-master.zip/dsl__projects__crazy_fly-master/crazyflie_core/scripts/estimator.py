#!/usr/bin/env python

"""
ROS node to provide the full state (position, velocity and acceleration) of a group
of Drones, running at 100Hz.

Takes raw marker information from VICON, runs an ICP algorithm to match points to drones
and finally the position measurements are fed to a Kalman Filter to estimate its velocity
and acceleration.

SUBSCRIBED TOPICS
/vicon/markers

PUBLISHED TOPICS
/full_state
"""
from __future__ import division, print_function
import rospy
from vicon_bridge.msg import Markers
from vicon_bridge.msg import Marker
import numpy as np
from geometry_msgs.msg import TransformStamped
from vicon_mapping import translator
from vicon_estimator import ViconCoordinates
from crazyflie_core.msg import SwarmStates, FullState
# Needed to send numpy.array as a msg
from rospy.numpy_msg import numpy_msg

update_rate = 100 # Publisher frequency in Hz

class Estimator:

    positions = {} # Dictionary that matches DroneX to a position (x,y,z)
    estimator = [] # List of objects 'estimator', one KF for each drone
    avg = 0.0
    swarm_states = SwarmStates()

    def __init__(self):
        init_pos = rospy.get_param("vehicles/init_pos")
        self.number_drones = rospy.get_param("vehicles/num")

        # Fill up the dictionary with the known initial positions
        for i in range(self.number_drones):
            x = init_pos[i][0] * 1000.0
            y = init_pos[i][1] * 1000.0
            z = 0 * 1000.0
            self.positions["/Drone{}".format(i+1)] = (x, y, z)

        # Create an object translator and specify the callback for the Vicon topic
        self.translator = translator(self.number_drones, self.positions)
        rospy.Subscriber("/vicon/markers", Markers, self.translator.read_vicon)

        # Setting up the Estimator:
        # Tuning parameters for Kalman Filter
        # increase in tau -> increase in c or d -> trust measurements less
        tau_est_trans = rospy.get_param('~tauEstTrans', 0.00001)
        tau_est_trans_dot = rospy.get_param('~tauEstTransDot', 0.045)
        tau_est_trans_dot_dot = rospy.get_param('~tauEstTransDotDot', 0.750)
        tau_est_rot = rospy.get_param('~tauEstRot', 0.001)
        tau_est_rot_dot = rospy.get_param('~tauEstRotDot', 0.025)

        # Make sure the parameters are set if default values used
        rospy.set_param('~tauEstTrans', tau_est_trans)
        rospy.set_param('~tauEstTransDot', tau_est_trans_dot)
        rospy.set_param('~tauEstTransDotDot', tau_est_trans_dot_dot)
        rospy.set_param('~tauEstRot', tau_est_rot)
        rospy.set_param('~tauEstRotDot', tau_est_rot_dot)

        # Create a list of objects ViconCoordinates
        for i in range(self.number_drones):
            self.estimator.append(ViconCoordinates((tau_est_trans,
                                              tau_est_trans_dot,
                                              tau_est_trans_dot_dot,
                                              tau_est_rot,
                                              tau_est_rot_dot),
                                              ))

        # Publisher of the full_state topic
        # SwarmStates is a list of messages FullState that have pos,vel,acc
        self.pub_state = rospy.Publisher('full_state',
                                         numpy_msg(SwarmStates),
                                         queue_size=1)
        # Timer to publish full_state topic @ update_state Hz
        self.pubtimer = rospy.Timer(rospy.Duration(1.0/update_rate), self.publish)

    def estimate(self):
        """
        For each drone, get the translation of its position (x,y,z) and feed it to
        its own estimator (Kalman Filter).
        """

        state = SwarmStates() # object to be published
        fullstate = FullState() # object to be appended to the list
        m = TransformStamped() # object to be interpreted from the translator
        k = 1
        self.avg = 0.0

        # Create the list of type FullState to be published
        for i in range(self.number_drones):
            state.fullstate.append(FullState())

        while not rospy.is_shutdown():

            # Uncomment to measure latency of translator loop
            # if k <= 2000:
            #     self.avg = (self.avg + self.translator.delay*1000)
            #     if k == 2000:
            #         print("Average delay of translator loop = {0:.2f} ms".format(self.avg/k))
            #     k = k + 1

            # tic = rospy.Time.now()
            # t0 = (float(tic.secs)
            #         + float(tic.nsecs) * 1e-9)

            # Loop through all the drones
            for i in range(self.number_drones):

                # Name of each drone in the translator dictionary
                prefix = '/Drone{}'.format(i+1)

                # Create a message of type TransformStamped
                m.header.stamp = self.translator.time
                m.transform.translation.x = self.translator.locations[prefix].translation.x
                m.transform.translation.y = self.translator.locations[prefix].translation.y
                m.transform.translation.z = self.translator.locations[prefix].translation.z
                m.transform.translation.x /= 1000.0
                m.transform.translation.y /= 1000.0
                m.transform.translation.z /= 1000.0

                # Call the method to estimate the state using the KF
                self.estimator[i].estimate_state(m)

                # Fill the corresponding drone's full state to the list
                state.fullstate[i].pos = self.estimator[i].estimator.pos
                state.fullstate[i].vel = self.estimator[i].estimator.vel
                state.fullstate[i].acc = self.estimator[i].estimator.acc

            # Add the time stamp to the published message and publish it
            state.header.stamp = rospy.Time.now()
            self.swarm_states = state

            # toc = rospy.Time.now()
            # tf = (float(toc.secs)
            #         + float(toc.nsecs) * 1e-9)
            # delay = tf - t0
            # print("Delay of estimator = {0:.2f} ms".format(delay*1000))

            # if k <= 2000:
            #     self.avg = (self.avg + delay*1000)
            #     if k == 2000:
            #         print("Average delay of estimator loop = {0:.2f} ms".format(self.avg/k))
            #     k = k + 1

    def publish(self, _):
        """
        Publish the latest full state of all drones in a single topic at 100Hz
        """
        self.pub_state.publish(self.swarm_states)


if __name__=="__main__":
    rospy.init_node("estimator")
    rospy.loginfo("Starting")
    t = Estimator() # Create an object Estimator to start processing the VICON frames
    t.estimate() # Run the loop to estimate the state of the whole swarm
    rospy.spin()
