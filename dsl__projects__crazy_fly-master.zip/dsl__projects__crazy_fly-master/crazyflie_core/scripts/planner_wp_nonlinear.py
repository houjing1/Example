#!/usr/bin/env python

import rospy
import math
import numpy as np

from geometry_msgs.msg import Twist
from dsl__utilities__msg.msg import StateData, StateVector

GRAVITY = 9.81
MAX_JERK = 10.0 # m/s^3
MAX_ACCEL = 1.0# m/s^2
MAX_VEL = 10.0 # m/s

def integrate(state, j, t):
    s, v, a = state
    new_a = a + j * t
    new_v = v + a * t + 0.5 * j * t * t
    new_s = s + v * t + 0.5 * a * t * t + 1.0 / 6.0 * j * t * t * t
    return new_s, new_v, new_a

def solve(a, b, c):
    return (-b + ((b * b - 4.0 * a * c) ** 0.5)) / 2.0 / a

class BasicPlanner(object):
    def __init__(self):
        self.r = rospy.get_param("~rate", 30)
        self.rate = rospy.Rate(self.r)
        self.start_time = rospy.get_rostime()
        self.start = False

        self.target_state = StateData()
        self.curr_state = StateVector()

        self.pubPath = rospy.Publisher("path_coordinates", StateData, queue_size = 10)
        self.subPoint = rospy.Subscriber("waypoints", Twist, self.updatePoint)
        self.subState = rospy.Subscriber("estimated_state", StateVector, self.updateState)



    def updatePoint(self, point):
        start_location = np.zeros((3,))
        target_location = np.zeros((3,))
        for i in range(3):
            start_location[i] = self.curr_state.pos[i]
        target_location[0] = point.linear.x
        target_location[1] = point.linear.y
        target_location[2] = point.linear.z

        self.start = True
        now = rospy.get_rostime()
        self.start_time = now.secs + now.nsecs * 10 ** (-9)
        self.pub_plan(start_location, target_location)


    def updateState(self, state):
        self.curr_state = state


    def pub_plan(self, start, target):
        goal = target - start
        dist = np.linalg.norm(goal)
        goal_n = goal / dist

        pos = np.copy(goal)
        vel = np.zeros((3,))
        acc = np.zeros((3,))
        while self.start:
            now = rospy.get_rostime()
            now_time = now.secs + now.nsecs * 10 ** (-9)
            elapse = now_time - self.start_time
            [pos, vel, acc] = self.get_state(dist, elapse)

            if np.linalg.norm(pos - dist) < 1e-8:
                self.start = False

            self.target_state.header.stamp = now
            self.target_state.x = start[0] + pos * goal_n[0]
            self.target_state.y = start[1] + pos * goal_n[1]
            self.target_state.z = start[2] + pos * goal_n[2]
            self.target_state.yaw = 0
            self.target_state.vx = vel * goal_n[0]
            self.target_state.vy = vel * goal_n[1]
            self.target_state.vz = vel * goal_n[2]
            self.target_state.ax = acc * goal_n[0]
            self.target_state.ay = acc * goal_n[1]
            self.target_state.az = acc * goal_n[2]

            #print(pos, vel, acc)
            self.pubPath.publish(self.target_state)
            self.rate.sleep()

    def get_state(self, dist, t):
        j_lim = MAX_JERK
        a_lim = MAX_ACCEL
        v_lim = MAX_VEL
        t_a = a_lim / j_lim #
        t_v = (v_lim - j_lim * (t_a ** 2.0)) / a_lim
        if t_v >= 0:
            t_temp = (dist / 2.0 / j_lim) ** (1.0 / 3.0)
            if t_temp < t_a:
                t_int = [t_temp, t_temp * 2.0, t_temp]
                j_int = [j_lim, -j_lim, j_lim]
            else:
                s_temp = 2.0 * j_lim * (t_a ** 3.0) + (t_a ** 2.0) * t_v * j_lim + (t_v ** 2.0) * a_lim + 2 * t_a * t_v * a_lim
                if s_temp > dist:
                    t_temp = solve(a_lim, 2.0 * a_lim * t_a + j_lim * (t_a ** 2.0), 2.0 * (t_a ** 3.0) * j_lim - dist)
                    t_int = [t_a, t_temp, t_a * 2.0, t_temp, t_a]
                    j_int = [j_lim, 0, -j_lim, 0, j_lim]
                else:
                    t_temp = (dist - 2.0 * (j_lim * (t_a ** 3.0) + t_a * ((t_v) * a_lim) + (j_lim * (t_a ** 2.0) + (t_v) * a_lim) / 2.0 * (t_v)))/ v_lim
                    t_int = [t_a, t_v, t_a, t_temp, t_a, t_v, t_a]
                    j_int = [j_lim, 0, -j_lim, 0, -j_lim, 0, j_lim]
        else:
            t_v = (v_lim / j_lim) ** 0.5
            t_temp = (dist / 2.0 / j_lim) ** (1.0 / 3.0)
            if t_temp < t_v:
                t_int = [t_temp, t_temp * 2.0, t_temp]
                j_int = [j_lim, -j_lim, j_lim]
            else:
                t_temp = (dist - 2 * (t_v ** 3.0) * j_lim) / v_lim
                t_int = [t_v, t_v, t_temp, t_v, t_v]
                j_int = [j_lim, -j_lim, 0, -j_lim, j_lim]

        int_num = len(t_int)
        state = [0, 0, 0]
        for i in range(int_num):
            if t <= t_int[i]:
                return integrate(state, j_int[i], t)
            state = integrate(state, j_int[i], t_int[i])
            t -= t_int[i]
        return [dist, 0, 0]



if __name__ == "__main__":
    rospy.init_node("planner_wp_nonlinear")
    Planner = BasicPlanner()
    rospy.spin()
