#!/usr/bin/env python


import numpy as np
from geometry_msgs.msg import Point,TransformStamped
from dsl__utilities__msg.msg import StateData
import rospy
import time
from crazyflie_driver.msg import GenericLogData


class DataManager:
    def __init__(self, filename):
        self.filename = filename
        self.sub_pos_est = rospy.Subscriber("/crazyflie/crazyflie_position", Point, self.updateEstimatePosition)
        self.sub_pos_vicon = rospy.Subscriber("/vicon/CF1/CF1", TransformStamped, self.updateTruePosition)
        self.pub_error_avg = rospy.Publisher('error_avg_d', GenericLogData, queue_size=10)
        self.pub_error_std = rospy.Publisher('error_std_d', GenericLogData, queue_size=10)

        self.pos_vicon = np.zeros((3,))
        self.pos_error = np.zeros((3,))


    def getData(self):
        my_file = open(self.filename, 'r')
        my_string = my_file.read()
        title = my_string.split('\n')[0].split(',,')
        title = [e.split(',') for e in title]
        title = [e for m in title for e in m]
        self.fields = np.array(title).reshape((-1,))

        data = my_string.split('\n')[1:]
        data = [d.split(',,') for d in data]
        data = [d.split(',') for m in data for d in m][:-1]
        data = [e for d in data for e in d]
        self.data = np.array(data, dtype='float64')
        self.data = self.data.reshape((-1, self.fields.shape[0]))

        print(self.data[1][0] - self.data[2,0])

    def getInterval(self, start, end):
        M,N = self.data.shape
        start_array = np.ones((M,))*start
        half_interval_index = np.where(self.data[:,0] > start_array )#and self.data[:][0] < end_array)
        half_interval = self.data[half_interval_index]

        M,N = half_interval.shape
        end_array = np.ones((M,))*end
        interval_index = np.where(half_interval[:,0] < end_array)
        interval = half_interval[interval_index]

        print(interval)

    def updateEstimatePosition(self, data):
        #self.pos_est = np.array(data.values)
        self.pos_est = np.array([data.x, data.y, data.z])
        error = self.pos_est - self.pos_vicon
        self.pos_error = np.vstack((self.pos_error, error))

        N = self.pos_error.shape[0]
        if N > 1e3:
            avg = np.average(self.pos_error, axis=0)
            std = np.std(self.pos_error, axis=0)
            msg = GenericLogData()
            msg.values = avg
            self.pub_error_avg.publish(msg)

            msg = GenericLogData()
            msg.values = std
            self.pub_error_std.publish(msg)

            self.pos_error = np.zeros((3,))
            rospy.loginfo('Clearing data')

    def updateTruePosition(self, data):

        self.pos_vicon[0] = data.transform.translation.x
        self.pos_vicon[1] = data.transform.translation.y
        self.pos_vicon[2] = data.transform.translation.z



class currentGoal:

    def __init__(self):
        self.pub_goal = rospy.Publisher('Drone1/goal',Point,queue_size=1)
        self.sub_path = rospy.Subscriber('Drone1/path_coordinates', StateData, self.new_path_coordinate)
        self.curr = Point()
        self.curr.z = 0.5
        self.timer = rospy.Timer(rospy.Duration(1.0/200.0), self.publish)


    def new_path_coordinate(self, path_coordinate):

        self.curr.x = path_coordinate.x
        self.curr.y = path_coordinate.y
        self.curr.z = path_coordinate.z

    def publish(self,event):
        self.pub_goal.publish(self.curr)




if __name__ == "__main__":
    rospy.init_node("data_analysis")
    bridge = currentGoal()
    datamanager = DataManager('test')
    rospy.spin()
