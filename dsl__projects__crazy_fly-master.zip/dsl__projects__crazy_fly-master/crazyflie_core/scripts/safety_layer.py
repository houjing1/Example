#!/usr/bin/env python

import rospy
import numpy as np
from dsl__utilities__msg.msg import StateData
from geometry_msgs.msg import TransformStamped, Twist
from crazyflie_driver.msg import FullControl
from vicon_bridge.msg import Markers
import math
from std_srvs.srv import Empty as Emptysrv
import rvo2

#number of frames saved for the moving average
SAVED_FRAMES = 1

#type of filter used to smooth message
#can be "low_pass" or "mov_avg"
filter_type = "low_pass"

#rate at which the low_pass will assume the commands are coming in
update_rate = 100.0

#Increase to make the path more smooth, decrease to make more aggressive
low_pass_constant = 0.1

#The z axis requires more smothing to prevent flipping on the nonlinear controller
low_pass_constant_z = low_pass_constant * 2.5

#used to determine steepness of potential field
steepness = 0.003

# constant increase to potential field (location of 'wall')
offset_threshold = 0.35

#Increase to acceleration to create desired effect
nonlinear_correction_factor = 10

#mode can either be potential or surface
mode = "surface"

#number of seconds you want the land command to take
seconds_to_land = 5.0

#for the potential mode this determines when the locking layer is activated
threshold_dist = 0.7

max_dist = 3.0

# correction node is called for each drone
class correction_node:
    def __init__(self, index, safety_layer):
        self.location = [0,0,0]
        self.saved_pos_cmd = []
        self.saved_vel_cmd = []
        self.saved_acc_cmd = []
        self.prev_state = -1
        self.index = index
        self.safety = safety_layer
        i = index
        self.prev_state = -1
        self.last_cmd = None

        self.cmd_buffer = None
        self.is_within_field = False
        self.manual_trigger = False
        self.pub_pid = rospy.Publisher("Drone" + str(i+1) + "/cmd_vel", Twist, queue_size=1)
        self.pub_nonlinear = rospy.Publisher("Drone" + str(i+1) + "/full_control", FullControl, queue_size=10)
        rospy.Subscriber("Drone" + str(i+1) + "/pre_cmd_vel", Twist, self.pid_correction_node)
        rospy.Subscriber("Drone" + str(i+1) + "/pre_full_control", FullControl, self.nonlinear_correction_node)
        rospy.Subscriber("vicon/CF" + str(i+1) + "/CF" + str(i+1), TransformStamped, self.save_pos)

    #reads from external pos to save the location of each drone in real time
    def save_pos(self, pos):
        self.location = [pos.transform.translation.x, pos.transform.translation.y, pos.transform.translation.z]

    #called for pid (REQUIRES TESTING, MAY HAVE ERRORS)
    def pid_correction_node(self, prev_command):
        new_cmd = Twist()
        new_cmd.linear.x = prev_command.linear.x + self.safety.drone_cmd_states[self.index].x[0]
        new_cmd.linear.y = prev_command.linear.y + self.safety.drone_cmd_states[self.index].y[0]
        new_cmd.linear.z = prev_command.linear.z + (self.safety.drone_cmd_states[self.index].z[0]) * 1000
        new_cmd.angular.x = prev_command.angular.x
        new_cmd.angular.y = prev_command.angular.y
        new_cmd.angular.z = prev_command.angular.z

        new_cmd = self.check_constraints(new_cmd)

        if self.safety.mode == "land":
            new_cmd.linear.z = 0.2
            self.safety.count += 1

        if (self.safety.count > 300):
            new_cmd.linear.z = 0.001

        self.pub_pid.publish(new_cmd)

    #Applies filters and if needed constraints to the robot
    def check_constraints(self, cmd):
        if filter_type == "mov_avg":
            res = self.moving_average(cmd)
        elif filter_type == "low_pass":
            res = self.low_pass(cmd)

        if type(res) == FullControl:
            if res.z[0] > max_dist:
                res.z[0] = max_dist
            elif res.z[0] < -max_dist:
                res.z[0] = -max_dist

            if res.y[0] > max_dist:
                res.y[0] = max_dist
            elif res.y[0] < -max_dist:
                res.y[0] = -max_dist
    
            if res.x[0] > max_dist:
                res.x[0] = max_dist
            elif res.x[0] < -max_dist:
                res.x[0] = -max_dist

        return res

    def apply_potential_field(self, new_cmd, correction_factor):
        new_cmd.x = [new_cmd.x[0] + correction_factor.x[0], new_cmd.x[1] + correction_factor.x[0], new_cmd.x[2] + nonlinear_correction_factor * correction_factor.x[0]]
        new_cmd.y = [new_cmd.y[0] + correction_factor.y[0], new_cmd.y[1] + correction_factor.y[0], new_cmd.y[2] + nonlinear_correction_factor * correction_factor.y[0]]
        new_cmd.z = [new_cmd.z[0] + correction_factor.z[0], new_cmd.z[1] + correction_factor.z[0], new_cmd.z[2] + nonlinear_correction_factor * correction_factor.z[0]]
        return new_cmd

    #Only should be called in "surface" mode
    def apply_potential_field_pos(self, new_cmd, correction_factor):
        change_vec = np.array([correction_factor.x[0], correction_factor.y[0], correction_factor.z[0]])

        if self.safety.flags[self.index] == "Potential" and self.cmd_buffer != None: 
            #print ("correction_factor x: %f  y: %f, z: %f" % (correction_factor.x[0], correction_factor.y[0], correction_factor.z[0]))
            new_cmd.x = [self.cmd_buffer.x[0] + correction_factor.x[0], 0, 0]
            new_cmd.y = [self.cmd_buffer.y[0] + correction_factor.y[0], 0, 0]
            new_cmd.z = [self.cmd_buffer.z[0] + correction_factor.z[0], 0, 0]
        elif self.safety.flags[self.index] == "Manual" and self.cmd_buffer != None: 
            new_cmd.x = [self.cmd_buffer.x[0] + correction_factor.x[0], 0, 0]
            new_cmd.y = [self.cmd_buffer.y[0] + correction_factor.y[0], 0, 0]
            new_cmd.z = [self.cmd_buffer.z[0] + correction_factor.z[0], 0, 0]
        return new_cmd

    #called for nonlinear controller
    def nonlinear_correction_node(self, prev_command):
        new_cmd = FullControl()
        new_cmd.x = prev_command.x[:]
        new_cmd.y = prev_command.y[:]
        new_cmd.z = prev_command.z[:]

        if (mode == "potential"):
            new_cmd = self.apply_potential_field(new_cmd, self.safety.drone_cmd_states[self.index])
        elif mode == "surface":
            new_cmd = self.apply_potential_field_pos(new_cmd, self.safety.drone_cmd_states[self.index])

        new_cmd = self.check_constraints(new_cmd)
        new_cmd.header.frame_id = prev_command.header.frame_id
        new_cmd.enable = True
        new_cmd.xmode = prev_command.xmode
        new_cmd.ymode = prev_command.ymode
        new_cmd.zmode = prev_command.zmode
        new_cmd.yaw = prev_command.yaw[:]

        #if the land service has been called the commands are overridden
        if self.safety.mode == "land":
            change = (seconds_to_land * update_rate * self.safety.num_drones  - self.safety.count) / (seconds_to_land * update_rate * self.safety.num_drones)
            new_cmd.z = list(np.array(new_cmd.z) * change)
            self.safety.count += 1

        if (self.safety.count >= seconds_to_land * update_rate * self.safety.num_drones):
            new_cmd.z = [0.001, 0, 0]

        if mode == "surface":
            new_cmd.x = [new_cmd.x[0], 0, 0]
            new_cmd.y = [new_cmd.y[0], 0, 0]
            new_cmd.z = [new_cmd.z[0], 0, 0]

        self.last_cmd = new_cmd
        self.pub_nonlinear.publish(new_cmd)


    def moving_average(self, cmd):
        if type(cmd) == FullControl:
            state = FullControl()
            self.saved_pos_cmd.append(np.array([cmd.x[0], cmd.y[0], cmd.z[0]]))
            self.saved_vel_cmd.append(np.array([cmd.x[1], cmd.y[1], cmd.z[1]]))
            self.saved_acc_cmd.append(np.array([cmd.x[2], cmd.y[2], cmd.z[2]]))

            if len(self.saved_pos_cmd) > SAVED_FRAMES:
                self.saved_pos_cmd.remove(self.saved_pos_cmd[0])
            if len(self.saved_vel_cmd) > SAVED_FRAMES:
                self.saved_vel_cmd.remove(self.saved_vel_cmd[0])
            if len(self.saved_acc_cmd) > SAVED_FRAMES:
                self.saved_acc_cmd.remove(self.saved_acc_cmd[0])

            pos = sum(self.saved_pos_cmd) / len(self.saved_pos_cmd)
            vel = sum(self.saved_vel_cmd) / len(self.saved_vel_cmd)
            acc = sum(self.saved_acc_cmd) / len(self.saved_acc_cmd)

            state.x[0], state.y[0], state.z[0] = list(pos[:])
            state.x[1], state.y[1], state.z[1] = list(vel[:])
            state.x[2], state.y[2], state.z[2] = list(acc[:])
        else:
            state = Twist()
            self.saved_pos_cmd.append(np.array([cmd.linear.x, cmd.linear.y, cmd.linear.z]))

            if len(self.saved_pos_cmd) > SAVED_FRAMES:
                self.saved_pos_cmd.remove(self.saved_pos_cmd[0])

            result = sum(self.saved_pos_cmd) / len(self.saved_pos_cmd)

            state.linear.x = result[0]
            state.linear.y = result[1]
            state.linear.z = result[2]
            state.angular.x = cmd.angular.x
            state.angular.y = cmd.angular.y
            state.angular.z = cmd.angular.z

        return state

    def low_pass(self, cmd):

        if type(cmd) == FullControl:

            state = FullControl()

            if self.prev_state == -1:
                self.prev_state = cmd
                return cmd
            else:
                h = 1/update_rate
                a = h / (low_pass_constant + h)
                az = h / (low_pass_constant_z + h)
                x = np.array(cmd.x[:])
                y = np.array(cmd.y[:])
                z = np.array(cmd.z[:])

                state.x = list((1-a) * np.array(self.prev_state.x[:]) + a * x)
                state.y = list((1-a) * np.array(self.prev_state.y[:]) + a * y)
                state.z = list((1-az) * np.array(self.prev_state.z[:]) + az * z)

                self.prev_state = state
        else:
            state = Twist()

            if self.prev_state == -1:
                self.prev_state = cmd
                return cmd
            else:
                h = 1/update_rate
                a = h / (low_pass_constant + h)
                state.linear.x = (1-a) * self.prev_state.linear.x + a * cmd.linear.x
                state.linear.y = (1-a) * self.prev_state.linear.y + a * cmd.linear.y
                state.linear.z = (1-a) * self.prev_state.linear.z + a * cmd.linear.z

                self.prev_state = state

        return state

#overarching manager of all classes
class safety:
    pubs = []
    num_drones = 0
    markers = []
    flags = []
    drone_cmd_states = []
    correction_nodes = []
    mode = ""
    count = 0
    manual_start_time = None

    def __init__(self, num_drones):
        self.num_drones = num_drones
        #flags are only use in surface demo
        if mode == "surface":
            self.flags = ["Normal"] * self.num_drones
        rospy.Service('land_all', Emptysrv, self.land)
        rospy.Service('start_wave', Emptysrv, self.trigger_wave) 
        rospy.Subscriber("vicon/Markers", Markers, self.read_markers)
        self.count = 0

        for i in range(num_drones):
            self.drone_cmd_states.append(FullControl())
            self.correction_nodes.append(correction_node(i, self))
            self.pubs.append(rospy.Publisher("/Drone" + str(i+1) + "/correction_state", FullControl, queue_size=30))
        rospy.Subscriber("/vicon/markers", Markers, self.read_markers) 
    #detects and saved marker positions from vicon
    def read_markers(self, markers):
        self.markers = markers.markers[:]

    def correct_acceleration(self):
        for i in range(self.num_drones):
            acc = self.get_acc(i)
            state = FullControl()
            state.x[0] = acc[0]
            state.y[0] = acc[1]
            state.z[0] = acc[2]

            self.pubs[i].publish(state)
            self.drone_cmd_states[i] = state

    def correct_offset(self): 
        for i in range(self.num_drones):
            pos = self.get_pos(i)
            state = FullControl()
            state.x[0] = pos[0]
            state.y[0] = pos[1]
            state.z[0] = pos[2]
            
            self.pubs[i].publish(state)
            self.drone_cmd_states[i] = state

    def get_acc(self, drone_index):
        drone = "/Drone" + str(drone_index)
        sum_drone = np.array([0,0,0])
        m = self.markers[:]
        for point in range(len(m)):
            sum_drone = sum_drone + self.repulsion_formula(np.array(self.correction_nodes[drone_index].location[:]) * 1000, \
            [float(m[point].translation.x), float(m[point].translation.y), float(m[point].translation.z)])

        return sum_drone

    def get_pos(self, drone_index):
        drone = "/Drone" + str(drone_index)
        sum_drone = np.zeros((3,))
        m = self.markers[:]
        self.correction_nodes[drone_index].is_within_field = False
        for point in range(len(m)):
            sum_drone = sum_drone + self.repulsion_formula_pos(np.array(self.correction_nodes[drone_index].location[:]) * 1000, \
            [float(m[point].translation.x), float(m[point].translation.y), float(m[point].translation.z)], drone_index)
    
        if self.correction_nodes[drone_index].is_within_field:
            print ("Potential")
            self.correction_nodes[drone_index].cmd_buffer = self.correction_nodes[drone_index].last_cmd
            self.flags[drone_index] = "Potential"

        elif self.correction_nodes[drone_index].manual_trigger:
            sum_drone += self.manual_setpoint(drone_index)
            self.flags[drone_index] = "Manual"
        else:
            self.correction_nodes[drone_index].cmd_buffer = None
            self.flags[drone_index] = "Normal" 
        return sum_drone

    #tells the drone where to go in the field
    def repulsion_formula_pos(self, d1, d2, drone_index):
        pos1 = np.array(d1) / 1000
        pos2 = np.array(d2) / 1000
        diff = pos1 - pos2
        dist = np.linalg.norm(diff)

        if (self.correction_nodes[drone_index].cmd_buffer != None) and (dist > 0.05):
            pos1 = np.array([self.correction_nodes[drone_index].cmd_buffer.x[0], self.correction_nodes[drone_index].cmd_buffer.y[0], self.correction_nodes[drone_index].cmd_buffer.z[0]])

        diff = pos1 - pos2
        dist = np.linalg.norm(diff)

        is_detecting_drone = False

        for i in range(self.num_drones):
            if np.linalg.norm(np.array(self.correction_nodes[i].location) - pos2) < 0.05:
                is_detecting_drone = True

        if dist < threshold_dist and dist > 0.05 and not is_detecting_drone:
            self.correction_nodes[drone_index].is_within_field = True
            return (pos1 - pos2) / dist * (threshold_dist / 1.3 - dist)
        else:
            return np.zeros((3,))

    #true potential field
    def repulsion_formula(self, d1, d2):
        pos1 = np.array(d1)
        pos2 = np.array(d2)
        diff = pos1 - pos2
        dist = np.linalg.norm(diff)


        if dist != 0:
            unit = diff / dist
        else:
            unit = diff
        if dist > 10:
            mag = math.e**(-dist * steepness + offset_threshold)
            vec = mag * unit
            return vec
        else:
            return np.array([0,0,0])

    def manual_setpoint(self, id):
        dir = np.array([0,0,1], dtype=float)
        mag = 0.5

        des_offset = dir * mag
        wait_time = 2.5

        time = rospy.get_rostime()
        time = time.secs + time.nsecs * 10 **(-9)
        if (time - self.manual_start_time) > wait_time:
            self.manual_start_time = None
            self.correction_nodes[id].manual_trigger = False
        
        return des_offset


    def run(self): 
        rate = rospy.Rate(100)
        while not rospy.is_shutdown():
            if mode == "potential": 
                self.correct_acceleration()
            elif mode == "surface": 
                self.correct_offset()
            rate.sleep()

    #simple service that turns land mode on
    def land(self, req):
        self.mode = "land"
        return ()

    def trigger_wave(self, req):
        # choose a drone from 0 to (num_drones-1)
        print ("Wave Triggered")
        id = 0
        time = rospy.get_rostime()
        self.manual_start_time = time.secs + time.nsecs * 10 **(-9)
        if self.correction_nodes[id].cmd_buffer == None:
            self.correction_nodes[id].cmd_buffer = self.correction_nodes[id].last_cmd
        else:
            return ("False")
        if not self.correction_nodes[id].manual_trigger:
            self.correction_nodes[id].manual_trigger = True 
        return ()

if __name__=="__main__":
    rospy.init_node("safety_layer")
    safe = safety(rospy.get_param("~num_drones", 1))
    safe.run()
    rospy.spin()
