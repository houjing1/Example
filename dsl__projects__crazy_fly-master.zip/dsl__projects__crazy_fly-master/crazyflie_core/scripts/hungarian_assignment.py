#!/usr/bin/env python


import numpy as np
from munkres import Munkres

class HungarianAssignment:

    def __init__(self,):
        pass

    def dist(self, a, b):

        return np.linalg.norm(np.array(a) - np.array(b))

    def attemp_assignment(self, dist_cap, matrix):
        agent_num = len(matrix)
        target_num = len(matrix[0])

        new_matrix = []
        for i in range(agent_num):
            temp = []
            for j in range(target_num):
                if matrix[i][j] > dist_cap:
                    temp.append(dist_cap * (agent_num + 1))
                else:
                    temp.append(matrix[i][j])
            new_matrix.append(temp)

        m = Munkres()
        assignment = m.compute(new_matrix)

        sum = 0
        for i in range(agent_num):
            sum += new_matrix[assignment[i][0]][assignment[i][1]]
        if sum >= dist_cap * (agent_num + 1):
            return False, assignment
        return True, assignment


    def assign(self, full_obs):
        '''
        input:
        agents: 2-d list, num_agent * pos_dim(3)
        targets: 2-d list, num_targets * pos_dim(3)

        return:
        acc: acceleration induced by potential field
        '''
        agents = full_obs[0]
        targets = full_obs[1]

        agent_num = len(agents)
        target_num = len(targets)

        # Build graph
        matrix = []
        max_dist = 0
        for i in range(agent_num):
            temp = []
            for j in range(target_num):
                temp.append(self.dist(agents[i], targets[j]))
                if temp[j] > max_dist:
                    max_dist = temp[j]
            matrix.append(temp)

        # Solve for action

        lower_bound = 0
        upper_bound = max_dist

        _, best_assignment = self.attemp_assignment(upper_bound, matrix)
        while(upper_bound - lower_bound > 0.001):
            mid = (lower_bound + upper_bound) / 2.0
            success, assignment = self.attemp_assignment(mid, matrix)
            if success:
                best_assignment = assignment
                upper_bound = mid
            else:
                lower_bound = mid

        waypoints = []
        for i in range(agent_num):
            temp = targets[best_assignment[i][1]]
            waypoints.append(temp)

        return waypoints
