#!/usr/bin/env python

# Created by: Tracy Du and Philip Huang 	Last update: June 19, 2017
# Contact: philip.huang@outlook.com

# The ui_basic_cmd node is adapted from DSL Central for the AR.Drone and ROS

# This class implements basic control functionality
# It can command takeoff/landing/emergency as well as drone movement based on predefined waypoints
# It also update the navdata

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib; roslib.load_manifest('crazyflie_core')
import rospy

# Import the messages we're interested in sending and receiving
from geometry_msgs.msg import Twist   # for sending commands to the drone
from std_srvs.srv import Empty as Emptysrv
from ardrone_autonomy.msg import Navdata # for receiving navdata feedback
from dsl__utilities__msg.msg import StateData # for publishing way points
# An enumeration of Drone Statuses
from drone_status import DroneStatus


# Some Constants
cmd_rate = rospy.get_param('cmd_rate',70); # set frequency to command_rate = cycling rate of controller [hz]
COMMAND_PERIOD = 1.0/cmd_rate


class BasicDroneController(object):
  def __init__(self, model):
    '''
    initialize the drone controller for one drone
    :param model: the namespace of the specific drone. For example '/Drone1'
    '''

    # Holds the current drone status
    self.status = DroneStatus.Landed

    # Subscribe to the /ardrone/navdata topic, of message type navdata, and call self.ReceiveNavdata when a message is received
    self.subNavdata = rospy.Subscriber(model + '/navdata',Navdata,self.ReceiveNavdata)

    # Allow the controller to call emergency, land and takeoff service

    rospy.loginfo("waiting for emergency service")
    #rospy.wait_for_service('/emergency')
    rospy.loginfo("found emergency service")
    # self.emergency = rospy.ServiceProxy('/emergency', Emptysrv)

    rospy.loginfo("waiting for safe_conduct service")
    rospy.wait_for_service('safe_conduct')
    # self.land = rospy.ServiceProxy(model + '/land', Emptysrv)

    # rospy.wait_for_service(model + '/takeoff')
    # self.takeOff = rospy.ServiceProxy(model + '/takeoff', Emptysrv)
    #
    # rospy.wait_for_service(model + '/calibrate')
    # self.calibrate = rospy.ServiceProxy(model + '/calibrate', Emptysrv)

    rospy.loginfo("found takeoff, land and calibrate service")
     # Allow the controller to publish to the path_coordinates topic and thus control the drone

    # self.waypoint_planner = rospy.get_param("~use_waypoint_planner", False)
    # if self.waypoint_planner:
    #     self.pubWaypoints = rospy.Publisher(model + '/waypoints', Twist, queue_size=10)
    # else:
    #     self.pubWaypoints = rospy.Publisher(model + '/path_coordinates', StateData, queue_size=10)
    # Setup publishing of control packets on demands
    self.waypoints = []
    init_pos = rospy.get_param('/vehicles/init_pos',[0,0,0])
    self.init_x = init_pos[int(model[-1]) - 1][0]
    self.init_y = init_pos[int(model[-1]) - 1][1]
    self.init_z = 0
    self.init_yaw = 0

    self.currWaypointIndex = 0
    # Allow the controller to publish to the /cmd_vel topic and thus control the drone
    # self.pubCommand = rospy.Publisher('/cmd_vel',Twist,queue_size=10)

    # Setup regular publishing of control packets
    self.command = StateData
    # self.commandTimer = rospy.Timer(rospy.Duration(COMMAND_PERIOD),self.SendCommand)

    # Land the drone if we are shutting down
    # rospy.on_shutdown(self.land)
    self.currWaypointIndex = 0

  def ReceiveNavdata(self,navdata):
    # Although there is a lot of data in this packet, we're only interested in the state at the moment
    self.status = navdata.state

  def SetWaypointArray(self,cmd_array):
    # Called by the main program to set the current command
    # cmd_array is a 2-d array
    init_pos = [self.init_x,self.init_y, 0, 0]
    self.waypoints = [[(init_pos[i] + row[i]) for i in range(len(row))] for row in cmd_array]

  def SendWaypoint(self):
    '''
    publish waypoint to path_coordinates topic
    :return:
    '''
    if len(self.waypoints) == 0 or len(self.waypoints) == self.currWaypointIndex:
        rospy.loginfo("No waypoints available!")
    elif self.status == DroneStatus.Flying or self.status == DroneStatus.GotoHover or self.status == DroneStatus.Hovering:
        if self.waypoint_planner:
            cmd = Twist()
            cmd.linear.x, cmd.linear.y, cmd.linear.z, cmd.angular.z = self.waypoints[self.currWaypointIndex]
            rospy.loginfo("Sending Planned Waypoint x: %f, y: %f, z: %f, yaw: %f",
                                            cmd.linear.x, cmd.linear.y, cmd.linear.z, cmd.angular.z)
        else:
            cmd = StateData()
            cmd.x, cmd.y, cmd.z, cmd.yaw = self.waypoints[self.currWaypointIndex]
            cmd.header.stamp = rospy.get_rostime()
            rospy.loginfo("Sending Waypoint x: %f, y: %f, z: %f, yaw: %f",
                                        cmd.x, cmd.y, cmd.z, cmd.yaw)
        # self.pubWaypoints.publish(cmd)
        self.currWaypointIndex += 1

    else:
        rospy.loginfo("Drone is not ready!")

    # def SendCommand(self,event):
    # The previously set command is then sent out periodically if the drone is flying
    #     if self.status == DroneStatus.Flying or self.status == DroneStatus.GotoHover or self.status == DroneStatus.Hovering:
            # self.pubCommand.publish(self.command)
