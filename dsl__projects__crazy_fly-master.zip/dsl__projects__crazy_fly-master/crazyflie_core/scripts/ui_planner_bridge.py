#!/usr/bin/env python

# to be modified to communicate between the UI component and the crazyflie controller bridge

from __future__ import division, print_function

import rospy
from dsl__utilities__msg.msg import StateData, StateVector
from PA_Planner import PathPlanner
from fluid_planner import Fluid
#from CollisionFree_Planner import CFPlanner
import numpy as np
import math
import re

class Ui_Planner_bridge():
    '''
    Guide for adding a new path_planning module:
    1. Create your file for your planning module
    2. Implement the interface for receiving estimations and getting commands:
        def getCommands(estimations, endpoints(optional)):
            ...
            return commands
        Both estimations and commands will be a 3-D numpy arrays, whose
            dim 1: drone_id
            dim 2: x, y, z axis
            dim 3: position, velocity, acceleration
        offline_commands is a 4-D numpy array with
            dim 1: time_step
            dim 2: drone_id
            dim 3: x,y,z axis
            dim 4: position, velocity, acceleration
    3. Implement the interface for getting cmd rate
        def getRate():
            return cmd_rate (in Hz)
    4. Import your module in this file and add it to the list of modules below
    5. Test your code in the ROS simulator and enjoy your flight!
    '''

    modules = {"PA_Planner": PathPlanner, "Fluid_Planner": Fluid}
    module_modes = {"PA_Planner": "online",  "Fluid_Planner": "online"}
    pub_cmds = {}
    sub_ests = {}

    def __init__(self, num_drones):

        # first dimension: drone_id
        # second dimension: x, y, z axis
        # third dimension: position, velocity, acceleration
        self.num_drones = num_drones
        self.estimations = np.zeros((num_drones, 3 , 3))
        self.commands = np.zeros((num_drones, 3, 3))
        self.cur_module = "Fluid_Planner"
        self.cur_mode = self.module_modes[self.cur_module]
        self.planner = self.modules[self.cur_module]()
        self.timer = None

        self.started = False
        self.states_received = np.array([False] * self.num_drones)
        self.rate = rospy.get_param("~cmd_rate",30)

        if self.cur_mode == "offline":
            self.cmd_indx = 0
            self.num_cmd = 0
            self.offline_called = False

        self.endPosition = rospy.get_param("~endPosition", [])

        for i in range(num_drones):
            drone = "/Drone{}".format(i + 1)
            self.pub_cmds[drone] = rospy.Publisher(drone + "/path_coordinates", StateData, queue_size = 1)
            self.sub_ests[drone] = rospy.Subscriber(drone + "/estimated_state", StateVector, self._update_state)


    def start(self, module):
        self.cur_module = module
        #self.cur_mode = self.module_modes[self.cur_module]

        self.rate = self.planner.getRate()
        self.timer = rospy.Timer(rospy.Duration(1.0/self.rate), self.update_with_planner)
        self.started = True

    def stop(self):
        if self.started:
            self.timer.shutdown()
            self.started = False

    def reset_rate(self, new_rate):
        if math.fabs(new_rate - self.rate) > 1e-2 :
            rospy.set_param("~cmd_rate", new_rate)
            self.rate = new_rate
            self.stop()
            rospy.sleep(0.1)
            self.start()

    def update_with_planner(self, _):
        if not self.started:
            return
        #print("test")

        if self.cur_mode == "online":
            self.commands = self.planner.getCommands(self.estimations, endpoints = self.endPosition)
        if self.cur_mode == "offline":
            if self.num_cmd != 0:
                if self.cmd_indx < self.num_cmd:

                    self.commands = self.offline_commands[self.cmd_indx]
                    print("publishing cmd", self.commands)
                    self.cmd_indx += 1
                else:
                    self.commands = self.offline_commands[-1]
            else:
                self.commands = self.estimations


        self.reset_rate(self.planner.getRate())

        self._publish_path()

    def _update_state(self, state):

        # frame_id is CF1, CF2, ... drone namespace is Drone1, Drone2, ...
        # take the last set of number from string as drone ID
        drone_id = re.match('.*?([0-9]+)$', state.header.frame_id).group(1)
        drone_id = int(drone_id) - 1
        for i in range(3):
            self.estimations[drone_id, i, 0] = state.pos[i]
            self.estimations[drone_id, i, 1] = state.vel[i]
            self.estimations[drone_id, i, 2] = state.acc[i]

        if self.started and self.cur_mode == "offline":
            self.states_received[drone_id] = True

            if self.states_received.all() == True and self.num_cmd == 0 and self.offline_called == False:
                self.offline_called = True
                init = (self.estimations * 100).astype(int).astype(float)
                init /= 100.0
                self.offline_commands = self.planner.getCommands(init, endpoints = self.endPosition)
                #self.offline_commands = [self.estimations]
                self.num_cmd = len(self.offline_commands)


    def _publish_path(self):
        for i in range(self.num_drones):
            drone = "/Drone{}".format(i + 1)
            planner_path = StateData()
            planner_path.header.stamp = rospy.get_rostime()
            planner_path.header.frame_id = drone[6:]

            planner_path.x  = self.commands[i, 0, 0]
            planner_path.vx = self.commands[i, 0, 1]
            planner_path.ax = self.commands[i, 0, 2]
            planner_path.y  = self.commands[i, 1, 0]
            planner_path.vy = self.commands[i, 1, 1]
            planner_path.ay = self.commands[i, 1, 2]
            planner_path.z  = self.commands[i, 2, 0]
            planner_path.vz = self.commands[i, 2, 1]
            planner_path.az = self.commands[i, 2, 2]

            self.pub_cmds[drone].publish(planner_path)


if __name__ == '__main__':
    rospy.init_node('ui_controller_bridge', anonymous=True)
    planner_bridge = Ui_Planner_bridge(2)

    rospy.spin()
