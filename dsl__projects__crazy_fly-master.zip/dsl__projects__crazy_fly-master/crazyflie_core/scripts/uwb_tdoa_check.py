#!/usr/bin/env python

'''
Utilities for TDoA Debugging
Author: Xintong Du

'''

import rospy
from crazyflie_driver.msg import GenericLogData
from dsl__utilities__msg.msg import StateData
from geometry_msgs.msg import TransformStamped, Point
import numpy as np
from std_srvs.srv import Empty as Emptysrv
import matplotlib.pyplot as plt

class TDoACheck:

    def __init__(self):

        self.rmse = 0
        self.traj_RMSE = False

        self.diff_est = np.zeros((8,))
        self.diff_est1 = np.zeros((4,))
        self.diff_est2 = np.zeros((4,))

        self.pos_vicon = np.zeros((3,))
        self.pos_error = np.zeros((3,))
        self.pos_est = np.zeros((3,))
        self.pos_vicon_all = np.zeros((3,))

        self.pos_est_all = np.zeros((3,))
        self.pos_vicon_all = np.zeros((3,))
        self.time = np.zeros((1,))

        self.pub_ref = rospy.Publisher('reference_d',
                                   GenericLogData, queue_size=10)
        self.pub_anch_std = rospy.Publisher('anch_std_d', GenericLogData, queue_size=10)
        self.pub_anch_avg = rospy.Publisher('anch_avg_d', GenericLogData, queue_size=10)
        self.pub_error_avg = rospy.Publisher('error_avg_d', GenericLogData, queue_size=10)
        self.pub_error_std = rospy.Publisher('error_std_d', GenericLogData, queue_size=10)
        self.pub_pos = rospy.Publisher('log_pos', StateData, queue_size = 10)

        self.srv_traj_RMSE = rospy.Service('traj_record', Emptysrv , self.srv_traj_RMSE)
        self.srv_traj_RMSE_plot = rospy.Service('traj_plot_results', Emptysrv , self.srv_traj_RMSE_plot)

        self.n_anchors = rospy.get_param("n_anchors")
        self.anchors_position = []
        for i in range(self.n_anchors):
            position = rospy.get_param("anchor{}_pos".format(i))
            self.anchors_position.append(position)
            rospy.loginfo("Anchor {} at {}".format(i, position))
        self.anchors_position = np.array(self.anchors_position, dtype='float64')
        #self.sub_pos_est = rospy.Subscriber("log_kfpos", GenericLogData, self.updateEstimatePosition)
        self.sub_pos_est = rospy.Subscriber("crazyflie_position", Point, self.updateEstimatePosition)
        self.sub_pos_vicon = rospy.Subscriber("/vicon/CF1/CF1", TransformStamped, self.updateTruePosition)

        self.sub_diff_est1 = rospy.Subscriber("log_tdoa1", GenericLogData, self.updateDiffEst1)
        self.sub_diff_est2 = rospy.Subscriber("log_tdoa2", GenericLogData, self.updateDiffEst2)


        self.timer_pubPos = rospy.Timer(rospy.Duration(1.0/200.0), self.publishPos)
        self.timer_pubRef = rospy.Timer(rospy.Duration(1.0/200.0), self.publishRef)
        self.timer_pubRMSE = rospy.Timer(rospy.Duration(1.0/200.0), self.publishRMSE)

        #self.timer_pubAvg = rospy.Timer(rospy.Duration(1.0/0.05), self.publishAvgStd)

    def publishRMSE(self, event):
        err_2 = np.array(self.pos_est - self.pos_vicon) ** 2
        rmse = np.average(err_2) ** 0.5
        self.rmse += rmse

    def srv_traj_RMSE(self, req):
        rospy.loginfo("start recording")
        self.traj_RMSE = True

        return []


    def srv_traj_RMSE_plot(self,req):
        rospy.loginfo("plotting results")
        time = self.time[1:]
        time -= time[0]
        pos_vicon_all = self.pos_vicon_all[1:]
        pos_est_all = self.pos_est_all[1:]

        xy_rmse_t = np.average((pos_vicon_all[:,:2] - pos_est_all[:,:2]) ** 2, axis=1)
        xy_rmse_t = xy_rmse_t ** 0.5

        xyz_rmse_t = np.average((pos_vicon_all - pos_est_all) ** 2, axis=1)
        xyz_rmse_t = xyz_rmse_t ** 0.5

        xy_rmse = np.average((pos_vicon_all[:,:2] - pos_est_all[:,:2]) ** 2)
        xy_rmse = xy_rmse ** 0.5

        xyz_rmse = np.average((pos_vicon_all - pos_est_all) ** 2)
        xyz_rmse = xyz_rmse ** 0.5

        rospy.loginfo("xy_RMSE: {}".format(xy_rmse))
        rospy.loginfo("xyz_RMSE:{}".format(xyz_rmse))

        f, axarr = plt.subplots(4, sharex=True)
        for i in range(3):
            axarr[i].plot(time, pos_vicon_all[:,i], c='blue', label='vicon', alpha=0.3)
            axarr[i].plot(time, pos_est_all[:,i], c='red', label='uwb', alpha=0.3)
            axarr[i].grid(True)
            axarr[i].set_ylim([-2.5,2.5])



        print(time.shape)

        axarr[3].scatter(time, xy_rmse_t, c='blue', label='rms_xy',
                   alpha=0.3)
        axarr[3].scatter(time, xyz_rmse_t, c='red', label='rms_xyz',
                      alpha=0.3)
        axarr[3].grid(True)
        axarr[3].legend()

        axarr[2].legend()

        fig, ax = plt.subplots()
        ax.plot(pos_vicon_all[:,0], pos_vicon_all[:,1], c='blue', label='vicon',
                    alpha=0.3)
        ax.plot(pos_est_all[:,0], pos_est_all[:,1], c='red', label='uwb',
                    alpha=0.3)

        plt.show()

        return []


    def run(self):
        rospy.spin()

    def updateEstimatePosition(self, data):
        '''
        moving average of position estimation error
        '''
        #self.pos_est = np.array(data.values)
        self.pos_est = np.array([data.x, data.y, data.z])
        error = self.pos_est - self.pos_vicon
        N = self.pos_error.shape[0]

        if N < 1e3:
            self.pos_error = np.vstack((self.pos_error, error))

        else:
            self.pos_error = np.vstack((self.pos_error[1:], error))

        avg = np.average(self.pos_error, axis=0)
        std = np.std(self.pos_error, axis=0)
        msg = GenericLogData()
        msg.values = avg
        self.pub_error_avg.publish(msg)

        msg = GenericLogData()
        msg.values = std
        self.pub_error_std.publish(msg)

    def publishPos(self, event):
        '''
        sample estimated position and vicon position at certain rate
        '''
        msg = StateData()
        msg.x, msg.y, msg.z = self.pos_est
        msg.vx, msg.vy, msg.vz = self.pos_vicon
        self.pub_pos.publish(msg)
        if self.traj_RMSE:
            self.pos_vicon_all = np.vstack((self.pos_vicon_all, self.pos_vicon))
            self.pos_est_all = np.vstack((self.pos_est_all, self.pos_est))
            time = rospy.get_rostime()
            time = time.secs + time.nsecs * 10 ** (-9)
            self.time = np.hstack((self.time, time))



    def updateTruePosition(self, data):

        self.pos_vicon[0] = data.transform.translation.x
        self.pos_vicon[1] = data.transform.translation.y
        self.pos_vicon[2] = data.transform.translation.z

    def updateDiffEst1(self,data):
        self.diff_est1 = np.array(data.values[:4])

    def updateDiffEst2(self,data):
        '''
        moving average of estimated distance difference
        '''
        self.diff_est2 = np.array(data.values)
        diff = np.hstack((self.diff_est1, self.diff_est2))
        N = self.diff_est.shape[0]

        if N < 1e3:
            self.diff_est = np.vstack((self.diff_est, diff))
        else:
            self.diff_est = np.vstack((self.diff_est[1:], diff))

        avg = np.average(self.diff_est, axis=0)
        std = np.std(self.diff_est, axis=0)

        msg = GenericLogData()
        msg.values = list(avg)
        self.pub_anch_avg.publish(msg)

        msg = GenericLogData()
        msg.values = list(std)
        self.pub_anch_std.publish(msg)


    def publishRef(self,event):
        '''
        publish the target value for log_tdoa1 and log_tdoa2

        '''
        distances = np.sum((self.anchors_position - self.pos_vicon) ** 2, axis=1) ** 0.5
        distances_shift = np.zeros((8,))
        distances_shift[1:] = distances[:-1]
        distances_shift[0] = distances[-1]
        self.diff_truth = distances - distances_shift

        msg = GenericLogData()
        msg.values = list(self.diff_truth)
        self.pub_ref.publish(msg)


if __name__ == "__main__":
    rospy.init_node('uwb_tdoa_check')
    check = TDoACheck()
    check.run()
