import numpy as np


if __name__ == "__main__":
    with open('/Users/Tracy/Desktop/UWB1.txt', 'r') as f:
        data = f.read().split('\n')
    
    coord = []
    for r in data:
        coord.append(r.split(',')[1:])
    
    coord = np.array(coord, dtype='float64')
    
    vec = coord - coord[0]
    
    basis = vec[1:3]
    basis = (basis.T / np.linalg.norm(basis, axis=1)).T
    z_hat = np.cross(basis[0].T, basis[1])
    basis = np.vstack((basis, z_hat))
    
    anch_vec = vec[3:]
    anch_coord = np.matmul(anch_vec, basis.T)
    np.savetxt('UWB_Cal', anch_coord,fmt='%.4f')
    