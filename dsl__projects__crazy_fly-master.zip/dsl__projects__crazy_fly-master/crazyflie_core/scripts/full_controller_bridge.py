#!/usr/bin/env python
'''
Bridge between ROS environment and mike hammer's onboard nonlinear controller
Written by: Philip Huang on July 5th, 2017
Add safety layer in during takeoff & flying in vicon lab
'''

from __future__ import print_function, division
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty as Emptymsg
from std_srvs.srv import Empty as Emptysrv
from crazyflie_driver.srv import UpdateParams
from crazyflie_driver.msg import FullControl
from ardrone_autonomy.msg import Navdata # for publishing navdata feedback

# An enumeration of Drone Statuses
from drone_status import DroneStatus
from dsl__utilities__msg.msg import StateData, StateVector

import time
import numpy as np

# Takeoff and landing speed in ms^-1
TAKEOFF_SPEED = 0.3
LANDING_SPEED = 0.3
UPDATE_RATE = rospy.get_param('cmd_rate',100)
UPDATE_RATE_STATE = 10
low_pass_constant = 0.1



class ControllerBridge:
    def __init__(self):
        self.frame_id = rospy.get_namespace()
        self.frame_id = self.frame_id[6:-1] #get the id of the drone
        self.target_setpoint = self.new_cmd()
        self.target_setpoint.x[0] = rospy.get_param("~x", 0)
        self.target_setpoint.y[0] = rospy.get_param("~y", 0)
        self.target_setpoint.z[0] = rospy.get_param("~z", 1)
        self.calibrated_setpoint = self.new_cmd()
        self.offsets = np.zeros((3,))
        self.est_pos = None 
        self.pos_all = [] 

        self.landed_setpoint = self.new_cmd()
        self.state = DroneStatus.Landed

        # variables used for takeoff and landing
        self.takeoff_height = self.target_setpoint.z[0]
        self.transient_height = 0
        self.wait_time = 0

        # parameters
        self.assisted_takeoff = rospy.get_param("~assisted_takeoff", True)
        self.assisted_landing = rospy.get_param("~assisted_landing", True)
        self.reconnect_on_takeoff = rospy.get_param("~reconnect_on_takeoff",
                                                    False)

        # Subscriber and publisher
        self.goal_sub = rospy.Subscriber("goal", StateData, self.new_goal)
        self.state_sub = rospy.Subscriber("estimated_state", StateVector, self.vicon_cb)
        self.cmd_vel_pub = rospy.Publisher("full_control", FullControl, queue_size=1)
        self.state_pub = rospy.Publisher("navdata",Navdata, queue_size=1)

        # takeoff/land for simulator
        self.takeoff_pub = rospy.Publisher("takeoff", Emptymsg, queue_size=1)
        self.land_pub = rospy.Publisher("land", Emptymsg, queue_size=1)

        # Services
        self.ts = rospy.Service('takeoff', Emptysrv, self.takeoff)
        self.ls = rospy.Service('land', Emptysrv, self.land)
        self.os = rospy.Service('override', Emptysrv, self.manual_override)
        self.offset_srv = rospy.Service('calibrate', Emptysrv, self.tune_offset)

        #rospy.loginfo("waiting for update_params service")
        #rospy.wait_for_service('update_params')
        #rospy.loginfo("found update_params service")
        #self._update_params = rospy.ServiceProxy('update_params', UpdateParams)

        if self.reconnect_on_takeoff:
            self._reconnect = rospy.ServiceProxy('reconnect', Emptysrv)

        # Send position setpoints 30 times per seconds
        self.timer = rospy.Timer(rospy.Duration(1.0/UPDATE_RATE),
                                 self.send_setpoint)


        # Send NavData
        self.timer2 = rospy.Timer(rospy.Duration(1.0/UPDATE_RATE_STATE),
                                 self.send_navdata)
    def new_cmd(self):
        cmd = FullControl()
        cmd.header.frame_id = self.frame_id
        cmd.enable = True
        cmd.xmode = 0b111
        cmd.ymode = 0b111
        cmd.zmode = 0b111
        cmd.x = [0,0,0]
        cmd.y = [0,0,0]
        cmd.z = [0,0,0]
        cmd.yaw = [0,0]

        return cmd
    def run(self):
        rospy.spin()

    def send_navdata(self,event):
        nd = Navdata()
        nd.state = self.state
        self.state_pub.publish(nd)

    def manual_override(self, event):
        self.state = DroneStatus.Override
        print ("override controller bridge")
        return ()
    
    def send_setpoint(self, event): 
        if self.state == DroneStatus.Override:
            return
        elif self.state == DroneStatus.TakingOff:
            if self.assisted_takeoff:
                sp = self.new_cmd()
                sp.x[0] = self.target_setpoint.x[0]
                sp.y[0] = self.target_setpoint.y[0]
                sp.z[0] = self.transient_height
                sp.z[1] = TAKEOFF_SPEED 
                if sp.z[0] > self.takeoff_height:
                    sp.z[0]= self.takeoff_height
                    sp.z[1]= 0 
                self.cmd_vel_pub.publish(sp)
                self.transient_height += TAKEOFF_SPEED/UPDATE_RATE

                # Force the drone to hover for 2 sec before flying
                if sp.z[0] >= self.takeoff_height:
                    if self.wait_time > 140:
                        self.transient_height = 0
                        self.state = DroneStatus.Flying
                        print ("Flying Mode!")
                        self.wait_time = 0
                    else:
                        self.wait_time += 1

        elif self.state == DroneStatus.Landing:
            if self.assisted_landing:
                sp = self.new_cmd()
                sp.x[0] = self.target_setpoint.x[0]
                sp.y[0] = self.target_setpoint.y[0]
                sp.z[0] = self.transient_height
                sp.z[1] = -LANDING_SPEED 
                if self.transient_height <= 0.1:
                    sp.enable = False
                if self.transient_height <= 0:
                    self.transient_height = 0
                    sp.z[0] = 0
                    sp.z[1] = 0
                    self.state = DroneStatus.Landed 
                self.cmd_vel_pub.publish(sp)
                self.transient_height -= LANDING_SPEED/UPDATE_RATE

            else:
                self.cmd_vel_pub.publish(self.landed_setpoint)

        elif self.state != DroneStatus.Emergency and \
             self.state != DroneStatus.Landed: 
             self.safety_layer()
             self.apply_offset()
             self.transient_height = self.calibrated_setpoint.z[0]
             self.cmd_vel_pub.publish(self.calibrated_setpoint)


    def safety_layer(self):
        if self.target_setpoint.x[0] > 2.5:
            self.target_setpoint.x[0] = 2.5
            print ("X direction is too far!")
        elif self.target_setpoint.x[0] < -2.5:
            self.target_setpoint.x[0] = -2.5
            print ("X direction is too far!")
        if self.target_setpoint.y[0] > 2.5:
            self.target_setpoint.y[0] = 2.5
            print ("Y direction is too far!")
        elif self.target_setpoint.y[0] < -2.5:
            self.target_setpoint.y[0] = -2.5
            print ("Y direction is too far!")
        if self.target_setpoint.z[0] > 2.5:
            self.target_setpoint.z[0] = 2.5
            print ("Z direction is too far!")
        elif self.target_setpoint.z[0] < 0:
            self.target_setpoint.z[0] = 0
            print ("Z direction is too far!")


    def new_goal(self, goal):
        if self.state == DroneStatus.Flying:
            self.cmds = None
            self.target_setpoint.x[0] = goal.x
            self.target_setpoint.x[1] = goal.vx
            self.target_setpoint.x[2] = goal.ax
            self.target_setpoint.y[0] = goal.y 
            self.target_setpoint.y[1] = goal.vy
            self.target_setpoint.y[2] = goal.ay

            if goal.z > 0: 
                self.target_setpoint.z[0] = goal.z
                self.target_setpoint.z[1] = goal.vz
                self.target_setpoint.z[2] = goal.az
            else:
                self.target_setpoint.z[0] = 0.001
                self.target_setpoint.z[1] = 0
                self.target_setpoint.z[2] = 0
                rospy.logwarn("Cannot set <=0 Z setpoint!")


            # yaw movement should be disabled
            self.target_setpoint.yaw[0] = goal.yaw
            while self.target_setpoint.yaw[0] > 180:
                self.target_setpoint.yaw[0]-= 360
            while self.target_setpoint.yaw[0] < -180:
                self.target_setpoint.yaw[0] += 360

            self.target_setpoint.yaw[1] = 0

    def vicon_cb(self, state):
         
        pos = np.array(state.pos[:])
        self.pos_all.append(pos)
        if len(self.pos_all) > 100:
            del self.pos_all[0]
        self.est_pos = sum(np.array(self.pos_all))/len(self.pos_all)

    def tune_offset(self, req):
        if self.est_pos != None  and self.state == DroneStatus.Flying:
            self.offsets[0] = self.calibrated_setpoint.x[0] - self.est_pos[0]
            self.offsets[1] = self.calibrated_setpoint.y[0] - self.est_pos[1]
            self.offsets[2] = self.calibrated_setpoint.z[0] - self.est_pos[2]   
            print ("calibrating constant offset!")
            return () 
        elif self.state == DroneStatus.TakingOff \
            or self.state == DroneStatus.Landing \
            or self.state == DroneStatus.Landed:
            print ("cannot calibrate during takoff or landing")
            return () 
        else:
            self.offsets = np.zeros((3,))

    def apply_offset(self): 
        self.calibrated_setpoint = self.new_cmd()
        # copy the target setpoint to calibrated setpoint
        for i in range(0, 3):
            self.calibrated_setpoint.x[i] = self.target_setpoint.x[i]
            self.calibrated_setpoint.y[i] = self.target_setpoint.y[i]
            self.calibrated_setpoint.z[i] = self.target_setpoint.z[i]

        self.calibrated_setpoint.x[0] += self.offsets[0]
        self.calibrated_setpoint.y[0] += self.offsets[1]
        self.calibrated_setpoint.z[0] += self.offsets[2] 

    def takeoff(self, req):

        if self.reconnect_on_takeoff and self.state != DroneStatus.Flying and \
           self.state != DroneStatus.Landing and self.state != DroneStatus.TakingOff:
            self._reconnect()
            time.sleep(2)

        #rospy.set_param("flightmode/posSet", 1)
        #self._update_params(["flightmode/posSet"])
        if self.state == DroneStatus.Landed:
            self.state = DroneStatus.TakingOff

            self.takeoff_pub.publish(Emptymsg())
            print("taking off!")

        return ()


    def land(self, req):
        if self.state == DroneStatus.TakingOff or \
           self.state == DroneStatus.Flying or \
           self.state == DroneStatus.Override:
            self.state = DroneStatus.Landing
            print("landing!")

            self.land_pub.publish(Emptymsg())
        return ()



if __name__ == "__main__":
    rospy.init_node("controller_bridge")
    cb = ControllerBridge()
    cb.run()
