#!/usr/bin/env python

# Created by Philip Huang
# Contact: philip.huang@outlook.com
# A Module for Store and process vicon and uwb data of crazyflies
# Use together with the GUI


# Subscribers:
# ns = /Drone1 or /Drone2 or /Drone3, etc....
# ns/crazyflie_position: uwb_information
# ns/estimated_state: vicon_information
# ns/path_coordinates: desired path
# ns/battery: battery voltage
# ns/imu: imu information from onboard

# Publishers:
# ns/external_position vicon information that is going to be passed onboard
#
import rospy
import rospkg

import sys
import math
import random
import time
import numpy as np
from dsl__utilities__msg.msg import StateData, StateVector
from crazyflie_driver.msg import FullControl
from geometry_msgs.msg import Point, TransformStamped, PointStamped, TwistStamped
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty, Int64MultiArray, String, Float32

class DroneData(object):
    def __init__(self, name):
        '''
        initialize the data structures, subscribers and publishers and initial positions
        :param name: namespace of the drone. For example: '/Drone1'
        '''
        self.in_simulation = False
        self.name = name

        # initialize plot data
        # est_uwb/vicon/goal will contain all the data points
        # ***_temp will only and always contain one data point

        # The idea is that incoming data from subscribers have different frequency
        # This node will filter all the data to 100Hz
        # so that the lengths of the np arrays time, est_uwb, est_vicon, goal are the same
        self.time = [np.zeros((1,)),np.zeros((1,)),np.zeros((1,))]
        self.est_uwb = np.zeros((6,)) # [[x],[y],[z],[vx],[vy],[vz]] for each drone
        self.est_vicon = np.zeros((9,))# [[x],[y],[z],[vx],[vy],[vz],[ax],[ay],[az]] for each drone
        self.est_vicon_full = np.zeros((9,))
        self.est_uwb_temp = np.zeros((9,))
        self.est_vicon_temp = np.zeros((9,))
        self.goal = np.zeros((9,))
        self.goal_temp = np.zeros((9,))
        self.status = "Init"
        self.start_time = 0
        self.uwbFreq = 0
        self.battery = 0
        self.imu_working = False
        self.vicon_working = False
        self.vicon_working_frames = 0


        self.init_x = rospy.get_param("{0}/init_x".format(self.name), 0)
        self.init_y = rospy.get_param("{0}/init_y".format(self.name), 0)
        self.init_z = rospy.get_param("{0}/init_z".format(self.name), 0)

        # self.sub_pos_uwb = rospy.Subscriber("{0}/crazyflie_position".format(self.name), Point, self.updateUWB)
        # self.sub_pos_vicon = rospy.Subscriber("{0}/estimated_state".format(self.name),StateVector, self.updateVicon)
        # self.sub_cmd_vel = rospy.Subscriber("{0}/cmd_vel".format(self.name), TwistStamped, self.updateCmd)
        # self.sub_full_control  = rospy.Subscriber("{0}/full_control".format(self.name), FullControl, self.updateFullCmd)

        # if not self.in_simulation:
        #     self.sub_battery = rospy.Subscriber("{0}/battery".format(self.name), Float32, self.update_battery_percent)
        #     self.sub_imu = rospy.Subscriber("{0}/imu".format(self.name), Imu, self.updateImu)

        #self.pub_pos_vicon = rospy.Publisher("{0}/external_position".format(self.name), PointStamped, queue_size=1)

    def run(self, start_time):
        '''
        start the timer for filtering datas
        :param start_time: start_time of the data recording
        :return:
        '''
        self.start_time = start_time
        # self.timer_pubPos = rospy.Timer(rospy.Duration(1.0/100.0), self.publishPos)


    def updateUWB(self, point):
        '''
        Callback function that will update uwb positions to est_uwb_temp
        Also performs a velocity estimation
        :param point: UWB coordinates
        :return:
        '''
        self.est_uwb_temp[3] = (point.x - self.est_uwb_temp[0])/self.uwbFreq
        self.est_uwb_temp[4] = (point.y - self.est_uwb_temp[1])/self.uwbFreq
        self.est_uwb_temp[5] = (point.z - self.est_uwb_temp[2])/self.uwbFreq
        self.est_uwb_temp[0] = point.x
        self.est_uwb_temp[1] = point.y
        self.est_uwb_temp[2] = point.z

    def update_battery_percent(self, state):
        '''
        ROS publish a voltage data to the topic /Drone1/battery
        Thus, Battery level is a linear approximation of voltage levels during flight
        based on a highest voltage and lowest voltage
        Thus, voltage(estimated battery) level would be high if crazyflie are not flying
        because voltage will build up.
        param:
        state : Float32 msg type.
        '''
        est_max_battery_static = 4.10
        est_min_battery_static = 3.55
        est_max_battery_fly = 3.65 # the estimated voltage when battery is full
        est_min_battery = 3.10  # the estimated voltage when battery is about to die

        if self.est_vicon_temp[2] > self.init_z+ 0.05 or self.est_uwb_temp[2] > 0.50:
            battery = (state.data-est_min_battery)/(est_max_battery_fly-est_min_battery) * 100.0
        else:
            battery = (state.data-est_min_battery_static)/(est_max_battery_static-est_min_battery_static) * 100.0
        self.battery = max(0, min(100, int(battery)))

    def updateVicon(self, state, time):
        '''
        callback function that will update vicon positions to est_uwb_temp
        :param point: vicon datas (StateVector msg)
        :return:
        '''
        self.est_vicon_temp[0] = state.pos[0]
        self.est_vicon_temp[1] = state.pos[1]
        self.est_vicon_temp[2] = state.pos[2]
        self.est_vicon_temp[3] = state.vel[0]
        self.est_vicon_temp[4] = state.vel[1]
        self.est_vicon_temp[5] = state.vel[2]
        self.est_vicon_temp[6] = state.acc[0]
        self.est_vicon_temp[7] = state.acc[1]
        self.est_vicon_temp[8] = state.acc[2]

        self.est_vicon = np.vstack((self.est_vicon, self.est_vicon_temp))

        time = time.secs + time.nsecs * 10 ** (-9) - self.start_time

        self.time[0] = np.vstack((self.time[0], time))

        if not self.vicon_working:
            # we suppose vicon dectection error has a radius of  0.15m
            if math.fabs(self.est_vicon_temp[0] - self.init_x) <  0.15 and \
                math.fabs(self.est_vicon_temp[1] - self.init_y) <  0.15 and \
                math.fabs(self.est_vicon_temp[2] - self.init_z) <  0.15 and \
                self.est_vicon_temp[0] != self.init_x and \
                self.est_vicon_temp[1] != self.init_y and \
                self.est_vicon_temp[2] != self.init_z:
                self.vicon_working_frames +=1
            if self.vicon_working_frames >= 10:
                self.vicon_working = True

    def updateImu(self, state):
        '''
        :param state: imu datas
        :return:
        '''
        if state.angular_velocity. x != None and state.angular_velocity.y != None \
            and state.angular_velocity.z != None:
            self.imu_working = True

    def updateCmd(self, state):
        '''
        update the desired positions for taking off/landing
        because take off and landing are done by the crazyflie_controller bridge
        so, path_coordinates does not update during takeoff or landing
        :param state: cmd_vel (Twist)
        :return:
        '''
        # cmd_vel = np.array([state.twist.linear.x, state.twist.linear.y, state.twist.linear.z/1000.0, state.twist.angular.z])
        cmd_vel = state.values
        for i in range(3):
            self.goal_temp[i] = cmd_vel[i]

        time = state.header.stamp
        time = time.secs + time.nsecs * 10 ** (-9) - self.start_time
        self.time[1] = np.vstack((self.time[1], time))

        self.goal = np.vstack((self.goal, self.goal_temp))


    def updateFullCmd(self, state):
        '''
        update the desired positions for taking off/landing when using nonlinear controller
        because take off and landing are done by the crazyflie_controller bridge
        so, path_coordinates does not update during takeoff or landing
        :param state: full_control (FullControl)
        :return:
        '''
        cmd_vel = np.array([state.x[0], state.y[0], state.z[0],\
                            state.x[1], state.y[1], state.z[1],\
                            state.x[2], state.y[2], state.z[2]])
        for i in range(9):
            self.goal_temp[i] = cmd_vel[i]



    def publishPos(self, _):
        '''
        Update the "correct" data arrays from the "temporary" data points
        Also publish Vicon external positions to crazyflie server(which will be sent onboard)
        :param _: a second argument needed for rospy timer. no real use here
        :return:
        '''
        time = rospy.get_rostime()
        time = time.secs + time.nsecs * 10 ** (-9) - self.start_time
        self.time = np.vstack((self.time, time))
        self.est_vicon = np.vstack((self.est_vicon, self.est_vicon_temp))
        self.goal = np.vstack((self.goal, self.goal_temp))
        self.est_uwb = np.vstack((self.est_uwb, self.est_uwb_temp))

        #print(self.name, self.goal_temp)
        '''
        vicon_pos = PointStamped()
        vicon_pos.point.x, vicon_pos.point.y, vicon_pos.point.z = self.est_vicon_temp[0],\
                                self.est_vicon_temp[1], self.est_vicon_temp[2]
        self.pub_pos_vicon.publish(vicon_pos)
        '''

    def save(self):
        # TODO: add more information in the log files(uwb datas, flight time, start time an date, initial positions, etc)
        '''
        Save the np data as a txt file
        :return:
        '''
        pts = min(self.est_vicon.shape[0], self.time.shape[0], self.goal.shape[0])
        flightData = np.hstack((self.est_vicon[1:pts],self.goal[1:pts]))
        data = np.hstack((self.time[1:pts],flightData))
        np.savetxt("../flight_data/{}_data.txt".format(self.name[1:]),data, \
                    fmt = "%1.3f", header = "{} Flight Data\n" \
         "Time Vicon(x,y,z,vx,vy,vz), Goal(x,y,z,vx,vy,vz,ax,ay,az)".format(self.name[1:]))
        # np.savetxt("../flight_data/{}_data.txt".format(self.name[1:]),self.est_vicon_full[1:], \
        #             fmt = "%1.6f", header = "Drone Flight Data\n" \
        #  "Time Vicon(x,y,z,vx,vy,vz)")

    def erase_all(self):
        '''
        Erase all the datas
        '''
        self.start_time = 0
        self.time = np.zeros((1,))
        self.est_uwb = np.zeros((6,)) # [[x],[y],[z],[vx],[vy],[vz]] for each drone
        self.est_vicon = np.zeros((6,))
        self.est_vicon_full = np.zeros((6,))
        self.est_uwb_temp = np.zeros((6,))
        self.est_vicon_temp = np.zeros((6,))
        self.goal = np.zeros((9,))
        self.goal_temp = np.zeros((9,))


if __name__ == "__main__":
    '''
    Main function is only used for testing
    '''
    rospy.init_node('ui_data')
    drone_model = rospy.get_namespace()
    print("drone_model")
    drone_data = DroneData(drone_model)
    time = rospy.get_rostime()
    time = time.secs + time.nsecs * 10 ** (-9)

    drone_data.run(time)

    rospy.spin()
