#!/usr/bin/env python

import numpy as np
from munkres import Munkres

class PA_Baseline_Policy_PPF:

    def __init__(self, discrete = False):
        self.pf_tar_steep = 0.1
        self.pf_tar_max = 100

        self.pf_agt_steep = 4
        self.pf_agt_max = 40
        self.pf_range = 1.4

        self.pf_parab_range = 0.4
        self.pf_parab_steep = 1
        self.pf_linear_slope = 0.2

        self.pd_KP = 2
        self.pd_KD = 4

        self.acc_lim = 10

    def control(self, obs):
        '''
        input:
        agents: 2-d list, num_agent * pos_dim(2)
        targets: 2-d list, num_targets * pos_dim(2)

        return:
        acc: acceleration induced by potential field
        '''
        #print(obs)
        agents = np.array(obs[0])
        targets = np.array(obs[1])
        if len(agents) == 0:
            agents = []
        if len(targets) == 0:
            targets = []
        print(agents.shape)
        #print(targets.shape)

        pf_ag = -self.generate_pf(agents, self.pf_agt_max, self.pf_agt_steep)
        #pf_tar = self.generate_pf(targets, self.pf_tar_max, self.pf_tar_steep)
        pf_tar = self.generate_pf_parab(targets)
        #pf_tar = pd_controller()
        acc = pf_ag + pf_tar

        return self.check_lim(acc)

    def pd_controller(self, vel_target, vel_current, acc_current):

        vel_tar = np.array(vel_target)
        vel_curr = np.array(vel_current)

        acc_tar = - vel_tar
        acc_cur = np.array(acc_current)

        vel_err = vel_tar - vel_curr
        acc_err = acc_tar - acc_curr

        acc = self.pd_KP * vel_err + self.pd_KD * acc_err

        return acc



    def generate_pf_parab(self, targets):

        if len(targets) == 0:
            return np.zeros((2,))
        targets = np.array(targets)
        distance = np.linalg.norm(targets, axis=1)
        basis = (targets.T / distance).T

        parab_indx = np.where(distance < self.pf_parab_range)
        parab = np.zeros(distance.shape)
        parab[parab_indx] = 1

        # paraboloid gradient = [x,y]

        mag = distance * parab + self.pf_linear_slope * (1 - parab)
        acc = np.matmul(mag, basis)

        return acc


    def generate_pf(self, obs, pf_max, pf_steep):
        '''
        input:
        obs: 2-d list, displacement

        output:
        acc: 2-d array, ax,ay
        '''
        if len(obs) == 0:
            return np.array([0, 0])
        dis = np.array(obs)
        norm = np.linalg.norm(dis, axis=1)

        # effective range
        close_neighbours = np.zeros(norm.shape)
        close_neighbours_indx = np.where(norm < self.pf_range)
        #print(close_neighbours_indx)
        close_neighbours[close_neighbours_indx] = 1

        basis = (dis.T / norm).T

        mag = pf_max * np.exp(-pf_steep * norm)
        acc = np.matmul(mag * close_neighbours, basis)

        return acc

    def check_lim(self, acc):

        mag = np.linalg.norm(acc)
        if mag > self.acc_lim:
            acc /= mag
            acc *= self.acc_lim

        return acc

class PA_Baseline_Policy_CPPF:

    def __init__(self,):
        pass

    def dist(self, a, b):
        return np.linalg.norm([a[0] - b[0], a[1] - b[1]])

    def attemp_assignment(self, dist_cap, matrix):
        agent_num = len(matrix)
        target_num = len(matrix[0])

        new_matrix = []
        for i in range(agent_num):
            temp = []
            for j in range(target_num):
                if matrix[i][j] > dist_cap:
                    temp.append(dist_cap * (agent_num + 1))
                else:
                    temp.append(matrix[i][j])
            new_matrix.append(temp)

        m = Munkres()
        assignment = m.compute(new_matrix)

        sum = 0
        for i in range(agent_num):
            sum += new_matrix[assignment[i][0]][assignment[i][1]]
        if sum >= dist_cap * (agent_num + 1):
            return False, assignment
        return True, assignment


    def control(self, full_obs):
        '''
        input:
        agents: 2-d list, num_agent * pos_dim(2)
        targets: 2-d list, num_targets * pos_dim(2)

        return:
        acc: acceleration induced by potential field
        '''
        agents = full_obs[0]
        targets = full_obs[1]

        agent_num = len(agents)
        target_num = len(targets)

        # Build graph
        matrix = []
        max_dist = 0
        for i in range(agent_num):
            temp = []
            for j in range(target_num):
                temp.append(self.dist(agents[i], targets[j]))
                if temp[j] > max_dist:
                    max_dist = temp[j]
            matrix.append(temp)

        # Solve for action

        lower_bound = 0
        upper_bound = max_dist * 1.5

        _, best_assignment = self.attemp_assignment(upper_bound, matrix)
        while(upper_bound - lower_bound > 0.001):
            mid = (lower_bound + upper_bound) / 2.0
            success, assignment = self.attemp_assignment(mid, matrix)
            if success:
                best_assignment = assignment
                upper_bound = mid
            else:
                lower_bound = mid

        waypoints = []
        for i in range(agent_num):
            temp = targets[best_assignment[i][1]]
            waypoints.append([temp[0], temp[1], 0, 0])
        return waypoints
