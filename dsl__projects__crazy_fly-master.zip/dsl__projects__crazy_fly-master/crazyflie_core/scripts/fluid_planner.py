#!/usr/bin/env python

from __future__ import absolute_import, division, print_function

import numpy as np
import math

dt = 0.05
low_pass_constant = 0.1
length = 1
Kp = 15.0
Kd = 0.5

class Fluid:
    def __init__(self):
        self.wave_started = False
        self.has_init = False
        self.num = None
        self.prev_pos = None
        self.conns = []
        self.z0 = None
        self.init_cmd = []
        self.states = []

    def getCommands(self, est, endpoints):
        # initilaization based on states
        if not self.has_init:
            self.has_init = True
            self.num = est.shape[0]
            self.prev_pos = [None] * self.num
            self.est_conn(est[:, :, 0])
            self.get_init_cmd(est[:, :, 0])

        # create an event with Drone<id>
        if not self.wave_started:
            z_offset = 0.5
            id = 0
            return self.move_drone(id, z_offset, est)

        cnt = np.zeros(self.num)
        for i in range(self.num):
            self.states[i][:, 2] = np.zeros(3)

        # target follow source
        for target in range(self.num):
            for source in self.conns[target]:
                self.states[target][:, 2] += self.apply(self.states[target], self.states[source])
                cnt[target] += 1

        # only enforce control in z direction
        cmd = np.zeros(est.shape)
        for i in range(self.num):
            if cnt[i] != 0:
                self.states[i][:, 2] /= cnt[i]
                self.states[i] = self.update(self.states[i])

            cmd[i, 0, 0] = self.init_cmd[i][0]
            cmd[i, 1, 0] = self.init_cmd[i][1]
            cmd[i, 2, :] = self.states[i][2, :]
        return cmd


    def integrate(self, state):
        pos, vel, acc = state
        vel_new = vel + acc * dt
        pos_new = pos + (vel + vel_new) / 2 * dt
        return (pos_new, vel_new, acc)

    def update(self, full_state):
        new_state = np.zeros((3, 3))
        for dim in range(3):
            new_state[dim, :] = self.integrate(full_state[dim, :])
        return new_state

    def apply(self, target, source):
        diff = source[2, 0] - target[2, 0]
        vel_diff = source[2, 1] - target[2, 1]
        return np.array([0, 0, diff * Kp + vel_diff * Kd])


    def low_pass(self, id, est):
        h = dt
        a = h / (low_pass_constant + h)

        pos = est[:,0]
        if self.prev_pos[id] == None:
            self.prev_pos[id] = pos
            return list(pos)

        lp_state = (1-a) * self.prev_pos[id] + a * pos
        self.prev_pos[id] = lp_state
        return list(lp_state)

    def est_conn(self, est):
        '''
        create adjacency list based on postion estimations
        '''
        self.conns = [[] for i in range(self.num)]
        for i in range(self.num):
            for j in range(self.num):
                if i == j:
                    continue
                diff = est[i][:2] - est[j][:2]
                if math.fabs(np.linalg.norm(diff) - length) < 0.15:
                    self.conns[i].append(j)

    def get_init_cmd(self, est):
        for i in range(self.num):
            x, y, z = est[i, :]
            x = round(x * 2) / 2
            y = round(y * 2) / 2
            z = round(z * 2) / 2
            self.z0 = z
            self.init_cmd.append([x,y])
            self.states.append(np.array([[x, 0, 0], [y, 0, 0], [z, 0, 0]]))

    def move_drone(self, id, z_offset, est):
        '''
        move Drone<id> up by <z_offset> while keeping other drones not moved
        '''
        cmd = np.zeros(est.shape)
        pos_est, vel_est = est[id, 2, :2]
        if math.fabs(pos_est - self.z0 - z_offset) < 0.15 and math.fabs(vel_est) < 0.05:
            self.wave_started = True

        for i in range(self.num):
            cmd[i, 0, 0] = self.init_cmd[i][0]
            cmd[i, 1, 0] = self.init_cmd[i][1]
            cmd[i, 2, 0] = self.z0

        cmd[id, 2, 0] += z_offset
        self.states[id][2, 0] = self.z0 + z_offset
        return cmd

    def getRate(self):
        return 1/dt
