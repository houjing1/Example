#!/usr/bin/env python

"""Simulates the quadrocopter interfaced with ROS.
Written By: Adrian Esser and David Wu
Modified By: Philip Huang
Changes:
- Aug 2015 - Separated and vectorized quadrotor dynamics, PEP8
- May 2017 - Added onboard controller for crazyflie.
This ROS node represents a physically accurate drone object. It receives
flight commands from the crazyflie_nonlinear controller just as a real drone would do, and it
publishes it's state data to the Vicon/lps bridge too. Onboard control and
dynamics are all calculated in this file.
SUBSCRIBED TOPICS
/cmd_vel
/ardrone/takeoff
/ardrone/land
/path_coordinates
PUBLISHED TOPICS
/vicon/ARDroneShare/ARDroneShare
/ardrone/navdata
/gazebo/set_model_state
"""

from __future__ import division, print_function, absolute_import

import numpy as np
import rospy
import tf

from crazyflie_driver.msg import GenericLogData
from crazyflie_driver.srv import UpdateParams
from std_msgs.msg import Empty
from geometry_msgs.msg import TransformStamped, PointStamped
from dsl__utilities__msg.msg import StateVector


class CRTPCount():

    def __init__(self):
        self.vicon_freq = 100

        self.pub_freq = rospy.Publisher('broadcast_frequency', GenericLogData, queue_size=1)
        self.sub_count = rospy.Subscriber('log_bc_count', GenericLogData, self.cb)
        self.count = [[0] * 4]

        self.time = [self.getTime()]

    def getTime(self,):
        curr = rospy.get_rostime()
        curr = curr.secs + curr.nsecs * 1e-9
        return curr

    def run(self):
        rospy.sleep(5)
        rospy.pub_timer = rospy.Timer(rospy.Duration(1/self.vicon_freq), self.publish_count)

    def cb(self, state):
        self.count.append(list(state.values))
        self.time.append(self.getTime())

        if len(self.count) > 200:
            self.count = self.count[1:]
            self.time = self.time[1:]


    def publish_count(self, _):
        broadcast_frequency = GenericLogData()
        counts = np.array(self.count)
        counts = counts[-1] - counts[0]
        time_elapsed = self.time[-1] - self.time[0]
        broadcast_frequency.values = counts / time_elapsed
        if len(self.count) > 199:
            self.pub_freq.publish(broadcast_frequency)


if __name__ == '__main__':
    rospy.init_node('crtp_count')

    # Example forces that could be added to the Drone
    count = CRTPCount()
    count.run()

    rospy.spin()
