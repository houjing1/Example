#!/usr/bin/env python
'''
Bridge between ROS environment and Crazyflie onboard controller

Written by: Bitcraze 2016
Modified by: Tracy Du & Philip Huang

Add safety layer in during takeoff & flying in vicon lab


'''
# TODO: Read PID parameters and set them in the Crazyflie parameters

import rospy
from geometry_msgs.msg import PoseStamped, TwistStamped, PointStamped
from std_msgs.msg import Empty as Emptymsg
from std_srvs.srv import Empty as Emptysrv
from crazyflie_driver.srv import UpdateParams
from ardrone_autonomy.msg import Navdata # for publishing navdata feedback
# An enumeration of Drone Statuses
from drone_status import DroneStatus
from dsl__utilities__msg.msg import StateData
from dsl__utilities__msg.msg import StateVector
import time

# Takeoff and landing speed in ms^-1
TAKEOFF_SPEED = 0.4
# Take off and landing acceleration 1m/s^2
TAKEOFF_ACC = 1.0
LANDING_ACC = 1.0
LANDING_SPEED = 0.3
UPDATE_RATE = rospy.get_param('cmd_rate',70)
UPDATE_RATE_STATE = 10

class ControllerBridge:
    def __init__(self):
        self.frame_id = rospy.get_namespace()
        self.frame_id = self.frame_id[6:-1] #get the id of the drone
        self.flight_mode = rospy.get_param("/flight_mode")

        self.target_setpoint = TwistStamped()
        self.target_setpoint.header.frame_id = self.frame_id

        if self.flight_mode == "posSet":
            self.target_setpoint.twist.linear.x = rospy.get_param("~x", 0)
            self.target_setpoint.twist.linear.y = rospy.get_param("~y", 0)
            self.target_setpoint.twist.linear.z = rospy.get_param("~z", 1) * 1000
        elif self.flight_mode == "althold":
            self.target_setpoint.twist.linear.x = 0.0
            self.target_setpoint.twist.linear.y = 0.0
            self.target_setpoint.twist.linear.z = 0.0

        self.takeoff_height = rospy.get_param("~z", 1) * 1000


        self.landed_setpoint = TwistStamped()
        self.landed_setpoint.header.frame_id = self.frame_id
        self.state = DroneStatus.Landed

        self.transient_height = 0
        self.transient_velocity = 0
        self.wait_time = 0


        self.assisted_takeoff = rospy.get_param("~assisted_takeoff", True)
        self.assisted_landing = rospy.get_param("~assisted_landing", True)
        self.reconnect_on_takeoff = rospy.get_param("~reconnect_on_takeoff",
                                                    False)

        self.goal_sub = rospy.Subscriber("goal", StateData, self.new_goal)

        self.cmd_vel_pub = rospy.Publisher("cmd_vel", TwistStamped, queue_size=1)
        self.state_pub = rospy.Publisher("navdata",Navdata, queue_size=1)
        self.takeoff_pub = rospy.Publisher("takeoff", Emptymsg, queue_size=1)
        self.land_pub = rospy.Publisher("land", Emptymsg, queue_size=1)


        # Services
        self.ts = rospy.Service('takeoff', Emptysrv, self.takeoff)
        self.ls = rospy.Service('land', Emptysrv, self.land)
        self.os = rospy.Service('override', Emptysrv, self.manual_override)
        self.offset_srv = rospy.Service('calibrate', Emptysrv, self.tune_offset)

        rospy.loginfo("waiting for update_params service")
        rospy.wait_for_service('update_params')
        rospy.loginfo("found update_params service")
        self._update_params = rospy.ServiceProxy('update_params', UpdateParams)

        if self.reconnect_on_takeoff:
            self._reconnect = rospy.ServiceProxy('reconnect', Emptysrv)

        # Send position setpoints 30 times per seconds
        self.timer = rospy.Timer(rospy.Duration(1.0/UPDATE_RATE),
                                 self.send_setpoint)

        # Send NavData
        self.timer = rospy.Timer(rospy.Duration(1.0/UPDATE_RATE_STATE),
                                 self.send_navdata)

    def run(self):
        rospy.spin()

    def send_navdata(self,event):
        nd = Navdata()
        nd.state = self.state
        self.state_pub.publish(nd)

    def manual_override(self, event):
        self.state = DroneStatus.Override
        return ()

    def send_setpoint(self, event):
        if self.state == DroneStatus.Override:
            return
        elif self.state == DroneStatus.TakingOff:
            if self.assisted_takeoff:
                sp = TwistStamped()
                sp.header.frame_id = self.frame_id

                if self.flight_mode == "posSet":
                    sp.twist.linear.x = self.target_setpoint.twist.linear.x
                    sp.twist.linear.y = self.target_setpoint.twist.linear.y
                    sp.twist.linear.z = self.transient_height*1000.0
                    if sp.twist.linear.z > self.takeoff_height:
                        sp.twist.linear.z = self.takeoff_height

                elif self.flight_mode == "althold":

                    # run off board position controller
                    sp.twist.linear.x = 0
                    sp.twist.linear.y = 0
                    sp.twist.linear.z = self.transient_velocity * 1000.0


                self.cmd_vel_pub.publish(sp)

                if self.flight_mode == "posSet":
                    self.transient_height += TAKEOFF_SPEED/UPDATE_RATE
                    if sp.twist.linear.z >= self.takeoff_height:
                        if self.wait_time > 140:
                            self.transient_height = 0
                            self.state = DroneStatus.Flying
                            print ("Flying Mode!")
                            self.wait_time = 0
                        else:
                            self.wait_time += 1

                elif self.flight_mode == "althold":
                    if self.transient_velocity > TAKEOFF_SPEED:
                        self.transient_velocity = TAKEOFF_SPEED
                    else:
                        self.transient_velocity += TAKEOFF_ACC / UPDATE_RATE
                    self.transient_height += self.transient_velocity/UPDATE_RATE
                    if self.transient_height * 1000.0 >= self.takeoff_height- 50:
                        if self.wait_time > 10:
                            self.transient_height = 0
                            self.transient_velocity = 0
                            self.state = DroneStatus.Flying
                            print ("Flying Mode!")
                            self.wait_time = 0
                        else:
                            self.wait_time += 1

        elif self.state == DroneStatus.Landing:
            if self.assisted_landing:
                sp = TwistStamped()
                sp.header.frame_id = self.frame_id
                if self.transient_height <= 0:
                    self.transient_height = 0
                    self.transient_velocity = 0
                    self.state = DroneStatus.Landed
                if self.flight_mode == "posSet":
                    sp.twist.linear.x = self.target_setpoint.twist.linear.x
                    sp.twist.linear.y = self.target_setpoint.twist.linear.y
                    sp.twist.linear.z = self.transient_height*1000.0
                elif self.flight_mode == "althold":
                    sp.twist.linear.x = 0
                    sp.twist.linear.y = 0
                    sp.twist.linear.z = self.transient_velocity*1000.0
                    print(self.transient_velocity*1000.0)

                self.cmd_vel_pub.publish(sp)
                if self.flight_mode == "posSet":
                    self.transient_height -= LANDING_SPEED/UPDATE_RATE
                elif self.flight_mode == "althold":
                    if self.transient_velocity < -LANDING_SPEED:
                        self.transient_velocity = -LANDING_SPEED
                    else:
                        self.transient_velocity -= LANDING_ACC/UPDATE_RATE

                    self.transient_height += self.transient_velocity/UPDATE_RATE



            else:
                self.cmd_vel_pub.publish(self.landed_setpoint)

        elif self.state != DroneStatus.Emergency and \
             self.state != DroneStatus.Landed:
             if self.flight_mode == "posSet":
                 self.safety_layer()
             self.transient_height = self.target_setpoint.twist.linear.z / 1000
             if self.target_setpoint.twist.linear.z / 1000 < 0.005:
                 self.target_setpoint.twist.linear.z = 0
             self.cmd_vel_pub.publish(self.target_setpoint)

    def safety_layer(self):
        if self.target_setpoint.twist.linear.x > 2.5:
            self.target_setpoint.twist.linear.x = 2.5
            print ("X direction is too far!")
        elif self.target_setpoint.twist.linear.x < -2.5:
            self.target_setpoint.twist.linear.x = -2.5
            print ("X direction is too far!")
        if self.target_setpoint.twist.linear.y > 2.5:
            self.target_setpoint.twist.linear.y = 2.5
            print ("Y direction is too far!")
        elif self.target_setpoint.twist.linear.y < -2.5:
            self.target_setpoint.twist.linear.y = -2.5
            print ("Y direction is too far!")
        if self.target_setpoint.twist.linear.z > 2500:
            self.target_setpoint.twist.linear.z = 2500
            print ("Z direction is too far!")
        elif self.target_setpoint.twist.linear.z < 0:
            self.target_setpoint.twist.linear.z = 0
            print ("Z direction is too far!")

    def tune_offset(self, req):
        '''
        Fake service if we have PID controller
        Since there is I term, we don't need to manual tune as if we did in nonlinear controller
        '''
        return()

    def new_goal(self, goal):
        if self.state == DroneStatus.Flying:
            self.target_setpoint.twist.linear.x = goal.x
            self.target_setpoint.twist.linear.y = goal.y
            if goal.z > 0:
                self.target_setpoint.twist.linear.z = goal.z*1000
            elif self.flight_mode == "posSet":
                self.target_setpoint.twist.linear.z = 1
                rospy.logwarn("Cannot set <=0 Z setpoint!")

            self.target_setpoint.twist.angular.z = goal.yaw
            while self.target_setpoint.twist.angular.z > 180:
                self.target_setpoint.twist.angular.z -= 360
            while self.target_setpoint.twist.angular.z < -180:
                self.target_setpoint.twist.angular.z += 360

    def takeoff(self, req):

        if self.reconnect_on_takeoff and self.state != DroneStatus.Flying and \
           self.state != DroneStatus.Landing and self.state != DroneStatus.TakingOff:
            self._reconnect()
            time.sleep(2)

        #rospy.set_param("flightmode/posSet", 1)
        #self._update_params(["flightmode/posSet"])
        if self.state == DroneStatus.Landed:
            self.state = DroneStatus.TakingOff

            self.takeoff_pub.publish(Emptymsg())
            print("taking off!")

        return ()

    def get_height_before_land(self, msg):
        if self.flight_mode == "posSet":
            self.target_setpoint.twist.linear.x = msg.pos[0]
            self.target_setpoint.twist.linear.y = msg.pos[1]

        self.transient_height = msg.pos[2]
        if self.transient_height == 0:
            rospy.logwarn("Estimated Height invalid when landing")
            self.transient_height = 1.5
        print(self.transient_height)
        self.state = DroneStatus.Landing
        print("landing!")
        self.land_pub.publish(Emptymsg())
        self.goal_sub.unregister()

    def land(self, req):
        if self.state == DroneStatus.TakingOff or \
           self.state == DroneStatus.Flying or \
           self.state == DroneStatus.Override:


           self.goal_sub = rospy.Subscriber('estimated_state', StateVector, self.get_height_before_land)

        return ()


if __name__ == "__main__":
    rospy.init_node("controller_bridge")
    cb = ControllerBridge()
    cb.run()
