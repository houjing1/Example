#!/usr/bin/env python

import numpy as np
class PA_Controller:
    def __init__(self,):
        self.KP = 7.5
        self.KD = 5
        self.acc_lim = 2

        self.pf_max = 100 #400
        self.pf_steep = 10
        self.pf_range = 0.7 #0.15

    def pd(self, curr_state, tar_state):
        '''
        input:
        curr_state:1-d list, x,y,vx,vy
        tar_state: 1-d list, x,y,vx,vy

        output:
        acc: 2-d array, ax,ay
        '''

        curr = np.array(curr_state)
        tar = np.array(tar_state)

        err = tar - curr

        acc = self.KP * err[:2] + self.KD * err[2:]

        return self.check_lim(acc)

    def pf_pos_PID(self, obs, cur):
        k1 = 2.0
        k2 = 25.0
        acc = self.pf(obs)
        pos_offset = [(acc[0] / k2) / k1, (acc[1] / k2) / k1]
        return pos_offset

    def pf_pos(self, obs):
        acc = self.pf(obs)
        pos_offset = [acc[0] / self.KP, acc[1] / self.KP]
        return pos_offset

    def pf(self, obs):
        '''
        input:
        obs: 2-d list, num_agent * pos_dim

        output:
        acc: 2-d array, ax,ay
        '''

        if len(obs) == 0:
            return np.array([0, 0])

        dis = np.array(obs)
        norm = np.linalg.norm(dis, axis=1)

        # effective range
        close_neighbours = np.zeros(norm.shape)
        close_neighbours_indx = np.where(norm < self.pf_range)
        close_neighbours[close_neighbours_indx] = 1

        basis = (dis.T / norm).T

        mag = self.pf_max * np.minimum(np.exp(-self.pf_steep * (norm - 0.3)), np.ones(len(obs)))
        mag *= close_neighbours
        acc = np.sum(mag* basis.T, axis=1)

        return -acc #-self.check_lim(acc)

    def check_lim(self, acc):

        mag = np.linalg.norm(acc)
        if mag > self.acc_lim:
            acc /= mag
            acc *= self.acc_lim

        return acc
