#!/usr/bin/env python2
#TODO: to be tested with imu data from onboard sensor


"""
Communication bridge between lps estimation and nonlinear controller

Author: "Xintong Du"
"""
# PURPOSE
# Subscribe to tf_prefic/imu to obtain acceleration
# Look up transfrom from worldFrame to frame to obtain pos and euler angles
# Note that transform info could either from vicon or uwb
# Estimate velocity with Euler Forward
# Publish new info as estimated_state (StateVector)

# NAMESPACE
# tf_prefix

# SUBSCRIBED
# imu

# PUBLISHED
# estimated_state

# PARAMS
# frame
# worldFrame



from dsl__utilities__msg.msg import StateVector
from sensor_msgs.msg import Imu
import tf
import numpy as np
import rospy


class bridge():
    # record translation from last time step for estimation
    last_msg_time = -1
    last_trans = np.array([0,0,0],dtype=np.float64)
    last_vel = np.array([0,0,0],dtype=np.float64)

    # message to be published as estimated_state
    msg = StateVector()

    # to lookup transform from /world to frame
    frame = rospy.get_param("frame")
    world_frame = rospy.get_param("worldFrame", "/world")

    def __init__(self):
        self.pub_estimation = rospy.Publisher("estimated_state_uwb",
                                   StateVector, queue_size=10)
        self.tf_prefix = rospy.get_param("tf_prefix")
        self.sub_imu = rospy.Subscriber(self.tf_prefix + "/imu", Imu, self.run)
        self.listener = tf.TransformListener()

    def run(self, imu_data):
        # tf info could come from vicon or uwb
        try:
            (trans,rot) = self.listener.lookupTransform(self.world_frame,
                                                        self.frame,
                                                        rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException,
                                    tf.ExtrapolationException):
            rospy.loginfo("transform lookup exception!Retry")

        trans = np.array(trans,dtype=np.float64)

        # for the first message set vel est as 0
        if self.last_msg_time == -1:
            self.last_trans = trans
            self.msg.vel = np.array([0,0,0],dtype=np.float64)

        else:
            dt = (imu_data.header.stamp.nsecs - self.last_msg_time.nsecs)* (1e-9)
            # average of current and last estimation
            self.msg.vel = 0.5 * (trans - self.last_trans) / dt +
                           0.5 * self.last_vel
            self.last_vel = self.msg.vel
            self.last_trans = trans

        self.last_msg_time = imu_data.header.stamp #ros_time

        self.msg.pos = trans
        self.msg.euler = tf.transformations.euler_from_quaternion(rot)
        self.msg.acc = np.array([imu_data.linear_acceleration.x,
                                 imu_data.linear_acceleration.y,
                                 imu_data.linear_acceleration.z],
                                 dtype=np.float64)

        self.msg.header.stamp = rospy.get_rostime()
        self.msg.header.frame_id = self.frame

        self.pub_estimation.publish(self.msg)


if __name__ == "__main__":
    rospy.init_node('lps_state_estimator')
    bridge()


    rospy.spin()
