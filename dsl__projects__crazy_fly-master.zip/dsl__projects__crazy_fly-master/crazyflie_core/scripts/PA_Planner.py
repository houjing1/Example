#!/usr/bin/env python

from PA_Baseline import PA_Baseline_Policy_CPPF as CPPF
from PA_Controller import PA_Controller
import numpy as np

class PathPlanner:
    def __init__(self):
        self.planner = CPPF()
        self.controller = PA_Controller()

    def getTargets(self, num):
        pts = []
        mag = 1.2
        for i in range(num):
            ang = i * np.pi * 2.0 / num
            pts.append([mag * np.cos(ang), mag * np.sin(ang)])
        return pts

    def getTargets2(self, obs):
        pts = [[-1.0, 0], [1.0, 0], [0, -1.0], [0, 1.0]]
        return pts

    def getRelativePos(self, agent_index, obs):
        agent_relative_pos = []
        for j in range(len(obs)):
            if agent_index != j:
                agent_relative_pos.append([obs[j][0] - obs[agent_index][0], obs[j][1] - obs[agent_index][1]])
        return agent_relative_pos

    def cap(self, vec, lim):
        mag = np.linalg.norm([vec[0], vec[1]])
        if mag > lim:
            ratio = lim / mag
        else:
            ratio = 1.0
        return [vec[0] * ratio, vec[1] * ratio]

    def getCommands(self, est_states, endpoints = []):
        height = 1.5
        agent_num = est_states.shape[0]
        obs = [[st[0][0], st[1][0], st[0][1], st[1][1]] for st in est_states]
        #waypoints = self.planner.control([obs, self.getTargets(obs)])
        waypoints = self.getTargets2(obs)
        #print waypoints
        # print "observation"
        # print obs
        # print "initial waypoints"
        commands = []
        for i in range(agent_num):
            relative_pos = self.getRelativePos(i, obs)
            pos_offset = self.controller.pf_pos_PID(relative_pos, obs[i])
            rel_waypoints = [waypoints[i][0] - obs[i][0], waypoints[i][1] - obs[i][1]]
            capped_rel_waypoints = self.cap(rel_waypoints, 0.5)

            #pos_offset = [0, 0]
            adjusted_waypoint = [capped_rel_waypoints[0] + pos_offset[0], capped_rel_waypoints[1] + pos_offset[1], 0, 0]
            #print adjusted_waypoint

            adjusted_waypoint2 = self.cap(adjusted_waypoint, 0.5)
            commands.append([[adjusted_waypoint2[0] + obs[i][0], 0, 0], [adjusted_waypoint2[1] + obs[i][1], 0, 0], [height, 0, 0]])
            print adjusted_waypoint2

        return np.array(commands)

    def getRate(self):
        return 20.0
