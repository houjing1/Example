"""
Game Environment Implementation

Author: "Xintong Du"
Email: xintong.du@mail.utoronto.ca
"""

import numpy as np

class LeverPullingEnv():

    def __init__(self,_agent_indx = [[1],[2],[3],[4],[5]],_lvr_num = 5):
        '''
        param _agent_indx: indexes of selected agent
        param _lvr_num: number of lever
        '''
        self.lvr_num = _lvr_num
        self.state = np.array(_agent_indx, dtype='float32')
        self.obs = self.state

    def step(self, action):
        '''
        param action: - 1-D array of agents' action
        return: self.state, reward(scalar), done(bool)
        '''

        reward = self.get_reward(action)

        return self.state, reward, True

    def get_reward(self, action):
        '''
        :return: reward for each agent dim(# agent, )
        '''

        bin_count = np.bincount(action)
        count = bin_count[action]
        rewards = np.where(count > 1, 0,1)
        #rewards = len(set(action))
        #r_agent = np.zeros((self.lvr_num,))
        #r_agent.fill(rewards / float(self.lvr_num))
        

        return rewards

    def get_obs(self):
        '''
        return: observation array of each agent(dim: n_agent X obs_dim)
        '''
        return self.state
