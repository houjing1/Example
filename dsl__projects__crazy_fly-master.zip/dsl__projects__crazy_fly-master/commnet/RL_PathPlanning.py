"""
Path Planning Reinforcement Learning Environment

RL formulation

Observed State: x, y, z, vx, vy, vz, roll, pitch, yaw, p, q, r (acceleration?)
Action: x, y, z (way point)
Reward: -100 (collision), -1 (per second spent)
Way point reach constraint:

Author: "Qiyang Li"
Email: colin.qiyang.li@gmail.com
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

TIME_PENALTY = 1
COLLISION_PENALTY = 100
COLLISION_RADIUS = 0.1
STEP_INTERVAL = 0.1

class Double_Integrator_Env():
    '''
    The initialization of the reinforcement learning environment
    The state of the agent can be described as a four dimension vector: (x, y, v_x, v_y)
    '''
    def __init__(self, init_state):
        '''
        The initialization of the double integrator environment
        :param _init_state: The initial state of the agent
        :param _resolution: The simulation resolution of the environment (defined by the time interval between each numerical simulation)
        '''
        self.state = _init_state


    def set_state(self, state):
        '''
        Set the state of the agent
        :param state: The state of the agent
        '''
        self.state = state

    def get_state(self):
        '''
        Get the current state of the agent
        :return: The current state of the agent
        '''
        return self.state

    def simulate(self, dt, action):
        '''
        Perform simulation of the environment
        :param dt: The simulation time
        :param action: The acceleartion on two direction (a_x, a_y)
        '''

        self.state = Double_Integrator_Env.simulate_state(self.state, dt, action)

    @staticmethod
    def simulate_state(state, dt, action):
        x = state[0]
        y = state[1]
        v_x = state[2]
        v_y = state[3]

        a_x = action[0]
        a_y = action[1]

        x += (v_x + (v_x + a_x * dt)) * dt / 2.0
        y += (v_y + (v_y + a_y * dt)) * dt / 2.0

        v_x += a_x * dt
        v_y += a_y * dt

        return np.array([x, y, v_x, v_y])


class RL_PathPlanning():

    def __init__(self, init_states, goal_states,  visualization_on = True):
        '''
        The initialization of the reinforcement learning environment
        :param agent_num: Number of agents
        '''

        self.agent_num = len(init_states)
        self.states = []
        self.goal_states = []

        self.cumul_reward = 0
        self.time_stamp = 0
        self.visualization_on = visualization_on

        for i in range(self.agent_num):
            self.states.append(init_states[i])
            self.goal_states.append(goal_states[i])

        self.record_time_stamp = [self.time_stamp]
        self.record_states = [self.states]
        self.record_cumul_reward = [self.cumul_reward]

        if self.visualization_on:
            self.visualization()

    def restart_visualization(self):
        self.record_states = []

    def add_drone(self, state):
        index = self.agent_num
        self.states.append(state)
        self.agent_num += 1
        return index

    def remove_drone(self, index):
        for i in range(index, self.agent_num - 1):
            self.states[i] = self.states[i + 1]
        self.agent_num -= 1

    def update_states(self, actions):
        new_states = []
        for i in range(self.agent_num):
            new_states.append(Double_Integrator_Env.simulate_state(self.states[i], STEP_INTERVAL, actions[i]))
        return new_states

    def get_state_reward(self, states):
        reward = -TIME_PENALTY
        for i in range(self.agent_num):
            for j in range(i+1, self.agent_num):
                if self.collide(states[i], states[j]):
                    reward -= COLLISION_PENALTY
        return reward

    def collide(self, state1, state2):
        x1 = state1[0]
        y1 = state1[1]

        x2 = state2[0]
        y2 = state2[1]

        if (x1 - x2) ** 2 + (y1 - y2) ** 2 < COLLISION_RADIUS ** 2:
            return True
        return False

    def check_arrival(self, curr_state, goal_state):

        rms_pos_bound = 0.5
        rms_vel_bound = 1

        x_curr = curr_state[0]
        y_curr = curr_state[1]
        vx_curr = curr_state[2]
        vy_curr = curr_state[3]

        x_goal = goal_state[0]
        y_goal = goal_state[1]
        vx_goal = goal_state[2]
        vy_goal = goal_state[3]

        if (x_curr - x_goal) ** 2 + (y_curr - y_goal) ** 2 < rms_pos_bound ** 2 and (vx_curr - vx_goal) ** 2 + (vy_curr - vy_goal) ** 2 < rms_vel_bound ** 2:
            return True
        return False

    def check_arrival_all(self):
        for i in range(self.agent_num):
            if not self.check_arrival(self.states[i], self.goal_states[i]):
                return False
        return True

    def step(self, actions):
        '''
        The transition of the environment after actions are executed
        param actions: - 1-D array of agents' actions
        return: self.state, reward(scalar), done(bool)
        '''

        new_states = self.update_states(actions)
        reward = self.get_state_reward(new_states)
        self.states = new_states
        self.time_stamp += STEP_INTERVAL
        self.cumul_reward += reward

        self.record_states.append(new_states)
        self.record_cumul_reward.append(self.cumul_reward)
        self.record_time_stamp.append(self.time_stamp)

        if self.visualization_on:
            self.animate()

        done = self.check_arrival_all()

        if done:
            print("Simulation Complete!")
            plt.show()

        return reward, done

    def get_reward(self, actions):
        '''
        :return: reward for each agent dim(# agent, )
        '''

        new_states = self.update_states(actions)
        reward = self.get_state_reward(new_states)

        return reward

    def get_obs(self):
        '''
        :return: current state for each agent dim(# agent, )
        '''
        return self.states

    def animate(self):
        self.ax1.clear()    # trajectory graph
        self.ax2.clear()    # reward graph
        #self.ax3.clear()    # motion graph

        for index in range(self.agent_num):
            self.ax1.plot([s[index][0] for s in self.record_states], [s[index][1] for s in self.record_states], label = "Agent " + str(index))
            self.ax1.scatter([self.states[index][0]], [self.states[index][1]], s = 20)

        self.ax1.legend()

        self.ax2.plot(self.record_time_stamp, self.record_cumul_reward, label = "Cumulative Reward")
        self.ax2.legend()

        plt.draw()
        plt.pause(0.01)

    def visualization(self):
        fig = plt.figure()
        self.ax1 = fig.add_subplot(2, 1, 1)
        self.ax2 = fig.add_subplot(2, 1, 2)
        #self.ax3 = fig.add_subplot(3, 1, 3)
        #ani = animation.FuncAnimation(fig, self.animate, interval = 1000)
        plt.show(block = False)
