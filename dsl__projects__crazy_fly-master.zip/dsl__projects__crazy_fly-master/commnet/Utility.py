# Created by Qiyang Li - Last update: Thursday May.18, 2017
# Contact me: colin.qiyang.li@gmail.com

# This is a utility file that contains pre-implemented neural network modules and useful functions

import tensorflow as tf
import numpy as np

class NNUtility(object):

    @staticmethod
    def get_scope_variable(var, shape=None):
        '''
        Get the variable in the current variable scope. If there doesn't exist a tensor with the name specified, the function
        creates a new variable.
        :param var: name of the tensor
        :param shape: shape of the tensor
        :return: the variable
        '''
        try:
            v = tf.get_variable(var, shape, initializer = tf.truncated_normal_initializer(stddev = 0.01))
        except ValueError:
            tf.get_variable_scope().reuse_variables()
            v = tf.get_variable(var)
        return v

    def random_order(data, label):
        '''
        Reorder the training data
        :param data: training input
        :param label: training output
        :return: A tuple of training input and training output in a random order
        '''
        if len(data) != len(label):
            print("Data and label have different sizes!")

        size = min(len(data), len(label))
        rand_index = np.random.permutation(size)

        data = [data[index] for index in rand_index]
        label = [label[index] for index in rand_index]

        return data, label

    def split_data(data, label, training_part = 0.75):
        '''
        Split the data into training part and testing part
        :param data: training input
        :param label: training output
        :param training_part: proportion of the training part
        :return: a tuple of training data input/output and testing data input/output
        '''
        if len(data) != len(label):
            print("Data and label have different sizes!")

        size = min(len(data), len(label))
        cutoff = int(size * 0.75)
        return data[:cutoff], label[:cutoff], data[cutoff:], label[cutoff:]

    def one_hot_rep(num, size):
        '''
        One hot representation conversion from a given integer
        :param size: Size of the one hot vector
        :return: The one hot vector after the conversion
        '''

        res = []
        for i in range(size):
            if i == num:
                res.append(1)
            else:
                res.append(0)
        return res

class NNModules(object):

    @staticmethod
    def encoding_module(inps, output_size, config = {"activation" : tf.nn.relu}):
        '''
        The encoding module perform a linear combination of the input tensors and the configured activation with dropout
        (if enabled). The default setting is ReLU activation function with no dropout.
        Occupied variable name: encoding*
        :param inps: The input tensors
        :param output_size: The size of the output sensor
        :param config: The configuration parameters for the encoding module (activation function and dropout)
        :return: The output tensor
        '''

        size = len(inps)    # Number of input tensors
        temp = []

        for i in range(size):
            W = NNUtility.get_scope_variable("encoding" + str(i), shape = [inps[i].shape[-1], output_size])     # Weight matrix
            temp.append(tf.matmul(inps[i], W))                                                                  # Populate tensor (after being multiplied by the weight matrix)

        if "dropout" in config:                                                                                 # Apply dropout and activation function to the sum of the tensors
            outp = tf.nn.dropout(config["activation"](tf.add_n(temp)), config["dropout"])
        else:
            outp = config["activation"](tf.add_n(temp))

        return outp        # output the resultant tensor

    def fcnn_module(inp, layer_config = [128, 128], config = {"activation" : tf.nn.relu}):
        '''
        The fcnn module establish a multi-layer connections with configured activation function and dropout.
        Occupied variable name: hidden_weight*, hidden_bias*
        :param layer_config: Number of layers for each layer
        :param config: The configuration parameters for the encoding module (activation function and dropout)
        :return: The output tensor
        '''

        layer_num = len(layer_config)   # Number of layers in the neural network
        layers = [inp]                  # Tensor for each layer

        for i in range(layer_num - 1):

            W = NNUtility.get_scope_variable("hidden_weight" + str(i), shape=[layer_config[i], layer_config[i + 1]])    # Weight matrix
            b = NNUtility.get_scope_variable("hidden_bias" + str(i), shape=[layer_config[i + 1]])                       # Bias vector

            if config["activation"] != None:
                if "dropout" in config:                                                                                     # Apply dropout and activation function
                    layers.append(tf.nn.dropout(config["activation"](tf.matmul(layers[i], W) + b), config["dropout"]))
                else:
                    layers.append(config["activation"](tf.matmul(layers[i], W) + b))
            else:
                if "dropout" in config:                                                                                     # Apply dropout and activation function
                    layers.append(tf.nn.dropout(tf.matmul(layers[i], W) + b, config["dropout"]))
                else:
                    layers.append(tf.matmul(layers[i], W) + b)


        return layers[layer_num - 1]    # Return the output tensor
