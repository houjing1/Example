# Created by Qiyang Li - Last update: Thursday May.18, 2017
# Contact me: colin.qiyang.li@gmail.com

# This is a replication of the lever pulling task in described in https://arxiv.org/abs/1605.07736.

import tensorflow as tf
import numpy as np
import Utility as Utility

class Commnet(object):

    def __init__(self, state_sizes = [1, 128, 128, 10], agent_num = 10):
        '''
        The initialization of the neural network
        :param state_sizes: This defines the number of neurons in each layer as well as the input/output sizes
        :param agent_num: Number of agents that in the lever pulling task
        '''
        tf.reset_default_graph()
        self.store_path = ""
        self.store_name = "CommNet"
        self.Graph = tf.Graph()
        self.sess = tf.Session(graph=self.Graph)
        with self.Graph.as_default():
            self.network = self.create_network(state_sizes, agent_num)  # Build the graph
        self.load_network()

    def kill(self):
        '''
        Kills the neural network
        :return: nothing
        '''
        self.sess.close()   # Close the session that this object is using


    def load_network(self):
        '''
        Load the network stored in self.store_path
        :return: nothing
        '''
        with self.Graph.as_default():
            self.sess.run(tf.initialize_all_variables())
            saver = tf.train.Saver()
            checkpoint = tf.train.get_checkpoint_state(self.store_path)

            if checkpoint and checkpoint.model_checkpoint_path:
                saver.restore(self.sess, checkpoint.model_checkpoint_path)
                print("---Successfully loaded: " + str(checkpoint.model_checkpoint_path) + '---')
            else:
                print("---Could Not Find Old Network Weights---")

    def save_network(self):
        '''
        Save the network in self.store_path with name self.store_name
        :return:
        '''
        with self.Graph.as_default():
            saver = tf.train.Saver()
            saver.save(self.sess, self.store_name)

    def build_f_skip(self, inp_h, inp_c, inp_c0, outp_size, config):
        '''
        Replicate the nonlinear function f described in the paper with skip connections
        :param inp_h: Hidden node
        :param inp_c: Communication node
        :param inp_c0: Input node
        :param outp_size: The size of the output tensor
        :param config: Configuration of the connection
        :return: Output tensor
        '''
        return Utility.NNModules.encoding_module([inp_h, inp_c, inp_c0], outp_size, config)

    def build_f(self, inp_h, inp_c, outp_size, config):
        '''
        Replicate the nonlinear function f described in the paper without skip connections
        :param inp_h: Hidden node
        :param inp_c: Communication node
        :param outp_size: The size of the output tensor
        :param config: Configuration of the connection
        :return: Output tensor
        '''
        return Utility.NNModules.encoding_module([inp_h, inp_c], outp_size, config)

    def create_network(self, state_sizes = [5, 5, 5, 5], agent_num = 10):
        '''
        Create the CommNet
        :param state_sizes: size of each unit in each communication layer
        :param agent_num: number of agents
        :return: nothing
        '''
        # Input/Output Layer
        batch_input = tf.placeholder(tf.float32, [None, None, state_sizes[0]])

        inps = []
        outps = []

        for i in range(agent_num):
            inps.append(batch_input[:,i,:])

        states = [inps]

        # Establish Connections
        drop_out = tf.placeholder(tf.float32)
        config = {"activation" : tf.nn.relu, "dropout" : drop_out}

        depth = len(state_sizes)
        for k in range(depth-1):
            with tf.variable_scope("Layer" + str(k)):
                h = []
                for i in range(agent_num):
                    if k == 0:
                        h.append(Utility.NNModules.fcnn_module(states[k][i], [state_sizes[k], state_sizes[k+1]], config))
                    else:
                        if k == depth-2:
                            outps.append(tf.reshape(Utility.NNModules.fcnn_module(states[k][i], [state_sizes[k], state_sizes[k+1]], {"activation" : None, "dropout" : drop_out}), [-1, 1, state_sizes[-1]]))
                        else:
                            lst = []
                            for j in range(agent_num):
                                if i != j:
                                    lst.append(states[k][j])
                            h.append(self.build_f_skip(states[k][i], tf.add_n(lst) * (1/(agent_num-1)), states[0][i], state_sizes[k+1], config))

                states.append(h)

        # Train model
        batch_output = tf.placeholder(tf.float32, [None, None, state_sizes[-1]])
        final_output = tf.concat(outps, axis = 1)

        cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=batch_output, logits=final_output))
        train_step = tf.train.AdamOptimizer(0.001).minimize(cross_entropy)

        # Test trained model
        correct_prediction = tf.equal(tf.argmax(final_output, 2), tf.argmax(batch_output, 2))
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


        # Save the important tensors in a dictionary
        self.modules = {"input" : batch_input,
                        "label" : batch_output,
                        "output": final_output,
                        "train" : train_step,
                        "accuracy" : accuracy,
                        "loss"  : cross_entropy,
                        "dropout"  : drop_out}

    def train(self, data, label, iteration = 100, keep_prob = 0.5):
        '''
        Train the network with training input and output
        :param data: Training inputs
        :param label: Training outputs
        :param iteration: Number of iterations
        :param keep_prob: Dropout rate
        :return: nothing
        '''
        if self.modules == None:
            print("Please build the graph first. The network cannot be trained")
            return

        batch_input = self.modules["input"]
        batch_output = self.modules["label"]
        train_step = self.modules["train"]
        drop_out = self.modules["dropout"]

        batch_size = 10
        size = len(data)
        for _ in range(iteration):

            rand_index = np.random.random_integers(0, size - 1, batch_size)

            batch_xs = [data[index] for index in rand_index]
            batch_ys = [label[index] for index in rand_index]

            self.sess.run(train_step, feed_dict = {batch_input: batch_xs, batch_output: batch_ys, drop_out : keep_prob})

    def test(self, data, label):
        '''
        Test the loss and the accuracy of the given testing input/output
        :param data: testing input
        :param label: testing output
        :return: a tuple that contains the average accuracy and loss
        '''
        if self.modules == None:
            print("Please build the graph first. The network cannot be tested")
            return

        batch_input = self.modules["input"]
        batch_output = self.modules["label"]
        accuracy = self.modules["accuracy"]
        training_loss = self.modules["loss"]
        drop_out = self.modules["dropout"]

        acc = self.sess.run(accuracy, feed_dict = {batch_input : data, batch_output : label, drop_out : 1.0})
        loss = self.sess.run(training_loss, feed_dict = {batch_input : data, batch_output : label, drop_out : 1.0})
        return acc, loss

    def predict(self, inputs):
        '''
        Use the commnet model to evaluate the output given the inputs
        :param inputs: The given inputs
        :return: The evaluated outputs
        '''
        if self.modules == None:
            print("Please build the graph first. The network cannot be used")
            return

        batch_input = self.modules["input"]
        outputs = self.modules["output"]
        drop_out = self.modules["dropout"]

        print(drop_out)

        inputs = inputs.reshape(1, len(inputs))

        result = self.sess.run(outputs, feed_dict = {batch_input : inputs, drop_out : 1.0})

        return result

def gen_data(num = 1000, n = 10, m = 3):
    '''
    Generate lever pulling dataset
    :param num: Number of data points
    :param n: Number of agents
    :param m: Number of levers
    :return: The dataset (input, output)
    '''
    data = []
    label = []
    for _ in range(num):
        perm = np.sort(np.random.permutation(n)[:m])
        perm = perm.reshape(m, 1)
        data.append(perm[:m])
        temp = np.arange(m)
        #temp = np.random.permutation(m)
        label.append([Utility.NNUtility.one_hot_rep(t, m) for t in temp])
    return np.array(data), np.array(label)

if __name__ == '__main__':
    nlev = 5

    model = Commnet(state_sizes = [1, 128, 128, nlev], agent_num = nlev)  # Initialize CommNet instance
    data, label = gen_data(num = 1000, n = 100, m = nlev)              # Generate dataset

    print(data)
    print(label)

    data_p, label_p = Utility.NNUtility.random_order(data, label)   # Prepare the dataset
    data_train, label_train, data_test, label_test = Utility.NNUtility.split_data(data_p, label_p, training_part = 0.75)

    accuracy_plot = []

    iteration = 100         # Number of training iteration per loop
    for _ in range(200):
        model.train(data_train, label_train, iteration, keep_prob = 1)
        accuracy, loss = model.test(data_test, label_test)
        print("Iteration #%d:" % (_ * iteration + iteration))
        print("Accuracy:%f" % (accuracy))
        print("Loss:%f" % (loss))
        accuracy_plot.append(accuracy)

    
