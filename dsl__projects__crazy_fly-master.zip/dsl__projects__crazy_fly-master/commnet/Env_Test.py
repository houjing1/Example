"""
Testing Script for Path Planning Reinforcement Learning Environment

Author: "Qiyang Li"
Email: colin.qiyang.li@gmail.com
"""

import RL_PathPlanning
import math
import random

kd = 1
kp = 5

def PD(error, error_d):
    return error * kp + error_d * kd

def policy(curr_state, target_state):
    lim = 1.0
    error_x = target_state[0] - curr_state[0]
    error_y = target_state[1] - curr_state[1]
    error_vx = -curr_state[2]
    error_vy = -curr_state[3]
    return [PD(error_x, error_vx), PD(error_y, error_vy)]

agent_num = 10
random_init_states = []
random_goal_states = []
for i in range(agent_num):
    random_init_states.append([random.random(), random.random(), 0, 0])
    random_goal_states.append([random.random(), random.random(), 0, 0])

env = RL_PathPlanning.RL_PathPlanning(init_states = random_init_states, goal_states = random_goal_states, visualization_on = True)

while True:
    curr_states = env.get_obs()
    actions = [policy(curr_states[i], random_goal_states[i]) for i in range(agent_num)]
    reward, done = env.step(actions)
    print(reward)
    if done:
        break
