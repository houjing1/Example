/*
 * fakevicon.cpp
 *
 *  Created On : Apr 12, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#include <iostream>
#include <array>
#include <vector>
#include <algorithm>

#include "ros/ros.h"
#include "vicon_bridge/Marker.h"
#include "vicon_bridge/Markers.h"

/** Runs a ROS node to send fake Vicon markers to test the estimator.
 *
 * @param argc Not used
 * @param argv Not used
 * @return 0
 */
int main(int argc, char **argv){
    ros::init(argc, argv, "crazyflie_est_fakevicon");
    ros::NodeHandle nh;

    std::cout << "Fake Vicon operating\n";

    ros::Publisher pub = nh.advertise<vicon_bridge::Markers>("vicon/markers", 1);

    // Upload initial positions as initial marker locations
    int nveh;
    nh.getParam("vehicles/num", nveh);  // check it is updated!
    XmlRpc::XmlRpcValue init_pos;
    nh.getParam("vehicles/init_pos", init_pos);
    ROS_ASSERT(init_pos.getType() == XmlRpc::XmlRpcValue::TypeArray);
    if (nveh > init_pos.size())
        std::cout << "Not enough specified initial positions!\n";

    std::vector<vicon_bridge::Marker> viconmarkers;
    for (int i = 0; i < nveh; ++i)
    {
        XmlRpc::XmlRpcValue data = init_pos[i];
        ROS_ASSERT(data.getType() == XmlRpc::XmlRpcValue::TypeArray);
        if (data.size() != 2)
            std::cout << "violated\n";
        ROS_ASSERT(data[0].getType() == XmlRpc::XmlRpcValue::TypeDouble);
        ROS_ASSERT(data[1].getType() == XmlRpc::XmlRpcValue::TypeDouble);

        vicon_bridge::Marker pos;
        // to simulate vicon, express in mm rather than m   
        pos.translation.x = static_cast<double>(data[0]) * 1000.0;
        pos.translation.y = static_cast<double>(data[1]) * 1000.0;
        pos.translation.z = 0.0;
        viconmarkers.push_back(pos);
    }

    std::cout << "There are " << viconmarkers.size() << " vicon markers\n";

    double pos_incr = 1.0;  // mm
    double totaltime = 0.0;
    double waittime = 2.0;
    int freq = 100;
    double per = 1.0 / static_cast<double>(freq);
    ros::Rate r(freq);

    //bool init_autogrid = false;
    //nh.getParam("estimator/init_autogrid", init_autogrid);
    //if (init_autogrid)
    //    pos_incr = 0;  // shouldn't move for autogrid initialization

    while(ros::ok())
    {
        // Increment marker positions to simulate dynamics
        totaltime += per;
        if (totaltime > waittime) {  // only after wait time has passed
            for (int i = 0; i < viconmarkers.size(); ++i)
                viconmarkers.at(i).translation.x += pos_incr;
        }

        vicon_bridge::Markers markers_msg;
        markers_msg.markers = viconmarkers;
        markers_msg.header.stamp = ros::Time::now();

        // Permute the markers using built-in random generator:
        std::random_shuffle ( markers_msg.markers.begin(),
                              markers_msg.markers.end() );

        pub.publish(markers_msg);
        std::cout << "fake vicon published\n";

        r.sleep();
    }

    return 0;
}
