/*
 * cluster.h
 *
 *  Created On : May 13, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#ifndef PROJECT_CLUSTER_H
#define PROJECT_CLUSTER_H

#include <vector>

/** Assign each (x,y) data point to a grid point.
 *
 * The output is a vector (same size as xdat, ydat), ordering
 * the data points uniquely from 0 to (number of points)-1 in dictionary order
 * that is, x and y progress left/down to right/up, with y outer, x inner
 *
 * The result is empty if the assignment fails
 *
 * @param xdat vector of data point x values
 * @param Kx number of clusters in x direction
 * @param ydat vector of data point y values
 * @param Ky number of clusters in y direction
 * @param finalorder output result
 */
void gridcluster(const std::vector<double>& xdat, int Kx,
                 const std::vector<double>& ydat, int Ky,
                 std::vector<int>& finalorder);

#endif //PROJECT_CLUSTER_H
