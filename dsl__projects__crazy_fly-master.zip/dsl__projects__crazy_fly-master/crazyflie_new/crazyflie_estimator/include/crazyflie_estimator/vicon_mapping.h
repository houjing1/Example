/*
 * vicon_mapping.h
 *
 *  Created On : Apr 02, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#ifndef PROJECT_VICON_MAPPING_H
#define PROJECT_VICON_MAPPING_H

#include <array>
#include <vector>
#include <deque>

#include <Eigen/Dense>

#include "ros/ros.h"
#include "crazyflie_utility/perf_monitor.h"

#include "vicon_bridge/Marker.h"
#include "vicon_bridge/Markers.h"
#include "crazyflie_estimator/FullState.h"
#include "crazyflie_estimator/SwarmStates.h"
#include "crazyflie_estimator/FullStateRaw.h"
#include "crazyflie_estimator/SwarmStatesRaw.h"

typedef std::array<int, 3> Idx3;
typedef Eigen::Vector3d V3;
typedef std::vector<V3> V3vec;


/**
 *
 */
struct VehData {

    /** Include a brief description of the marker geometry set up...
     *
     */
    int nmax;           /**< maximum number of markers (1 or 3) */
    V3 m1;              /**< raw marker +y (or COM if single)*/
    V3 m2;              /**< raw marker -x */
    V3 m3;              /**< raw marker +x */
    Idx3 mstatus;       /**< corresponding marker mi validity (1 - matched, 0 - not) */
    Idx3 moutlier;      /**< nmax == 1 only: 1 - marker is outlier, 0 - not, per x,y,z */

    // Raw data for estimated state from markers
    // Only valid for now if mstatus = (1,1,1), can add more cases later
    V3 pos_r;      /**< center of mass from markers (m) */
    V3 vel_r;      /**< numerical velocities (m/s) */
    V3 acc_r;      /**< numerical accelerations (m/s/s) */
    V3 yrp_r;      /**< yaw, roll, pitch (ZXY) euler angles from markers (rad) */
    V3 omg_r;      /**< numerical body rates ?? (rad/s) */

    // Corresponding smoothed data using current and previous measurements
    // Various algorithms can be used, or can be a copy of the raw data
    // Only valid if raw data is valid
    V3 pos_s;      /**< smoothed positions */
    V3 vel_s;      /**< smoothed velocities */
    V3 acc_s;      /**< smoothed accelerations */
    V3 yrp_s;      /**< smoothed angles */
    V3 omg_s;      /**< smoothed body rates */

    // Prior updates
    V3 pos_p;      /**< prior updated positions */
    V3 vel_p;      /**< prior updated velocities */
    V3 acc_p;      /**< prior updated accelerations */
    V3 yrp_p;      /**< prior updated angles */
    V3 omg_p;      /**< prior updated body rates */

    // Final estimate by fusing data
    V3 pos_f;      /**< estimated positions */
    V3 vel_f;      /**< estimated velocities */
    V3 acc_f;      /**< estimated accelerations */
    V3 yrp_f;      /**< estimated angles */
    V3 omg_f;      /**< estimated body rates */

    /** Initialize all data to zero
     *
     */
    VehData(int n): nmax(n)
    {
        m1.Zero();
        m2.Zero();
        m3.Zero();
        mstatus = {{0, 0, 0}};
        moutlier = {{0, 0, 0}};

        pos_r.Zero();
        vel_r.Zero();
        acc_r.Zero();
        yrp_r.Zero();
        omg_r.Zero();

        pos_s.Zero();
        vel_s.Zero();
        acc_s.Zero();
        yrp_s.Zero();
        omg_s.Zero();

        pos_p.Zero();
        vel_p.Zero();
        acc_p.Zero();
        yrp_p.Zero();
        omg_p.Zero();

        pos_f.Zero();
        vel_f.Zero();
        acc_f.Zero();
        yrp_f.Zero();
        omg_f.Zero();
    }
};
/** A structure to hold a frame of raw and processed measurement data.
 *
 * Each vector in the structure is of the same size, indexing the vehicles
 *
 */
struct MeasData {
    double t;      /**< ROS time (s) */
    uint64_t tns;  /**< ROS time (ns) */

    std::vector<VehData> dat;  /**< one frame of data, per vehicle */

    /** Initialize all data to zero until updated later.
     *
     * @param nveh number of vehicles
     * @param nmarker number of markers
     * @param tstamp ROS time (s)
     * @param tnsstamp ROS time (ns)
     */
    MeasData(int nveh, int nmarker, double tstamp, uint64_t tnsstamp):
            t(tstamp),
            tns(tnsstamp)
    {
        dat.assign(nveh, VehData(nmarker));
    }  
};

/** Geometry constants for three marker configuration
 *
 */
struct Geo3M {
    double d1;
    double d2;
    double d3;
    double dsq12;
    double dsq13;
    double dsq23;

    Geo3M()
    {
        d1 = 0;
        d2 = 0;
        d3 = 0;
        dsq12 = 0;
        dsq13 = 0;
        dsq23 = 0;
    }
};

/** Use frame-by-frame Vicon markers to estimate swarm position, velocity, and acceleration.
 *
 */
class ViconMapper{
public:
    /** Establish topics to vicon markers and swarm states, intializes estimates.
     *
     * @param nh pointer to ROS handle
     */
    ViconMapper(ros::NodeHandle* nh);
    
private:
    /* Member variables */

    // ROS related members
    ros::NodeHandle* _nh;                   /**< ROS handle */
    ros::Publisher _pub_swarmstates;        /**< Publishs to full_state ROS topic */
    ros::Publisher _pub_swarmstates_meas;   /**< Publishes to (debug) full_state_meas ROS topic */
    ros::Subscriber _sub_markerupdate;      /**< Subscribes to vicon/markers ROS topic */

    int _nveh;                      /**< number of vehicles */
    bool _multim = false;           /**< true if all drones use multi-markers, else false */

    // Initialization status and other initialization helper members
    // Assumes vehicle is sitting on lab floor with roughly zero yaw
    bool _init_ready = false;       /**< true if initial estimates exist */
    bool _init_autogrid = false;    /**< true if auto-grid initialization is to be run */
    int _init_nframestry = 0;       /**< counts number of frames passed attempting initial estimate */
    int _init_nframesgood = 0;      /**< counts number of frames passed with good initial estimate */
    int _init_ncols = 1;            /**< auto-init grid size in x direction */
    int _init_nrows = 1;            /**< auto-init grid size in y direction */
    std::vector<int> _init_order;   /**< auto-init custom order on top of dictionary order */
    V3vec _initpos;                 /**< CM position per vehicle, either loaded or from auto-init */
    std::vector<Geo3M> _geo;        /**< fixed initialized geometries per vehicle (3 markers only) */

    // Store latest position measurements and numerically differentiated
    // velocities and accelerations in a queue (actually deque
    // since it allows any element access) of a measurement data structure
    int _qsize = 2;                     /**< queue size, history length, must be >= 2 */
    std::deque<MeasData> _measqueue;    /**< queue containing latest measurements */
    int _algsmooth = 0;                 /**< 0 - nothing, else - recursive exp. */
    std::vector<int> _nframesbad;   /**< frames passed with no marker assignment per vehicle */
    std::vector<int> _nframesout;   /**< frames passed with marker as outlier, per vehicle (1 marker only) */

    // For recursive exponential smoothening, values closer to zero use latest measurement more
    double _expsm_pos = 0.005;         /**< gain for recursive exponential position smoothening */
    double _expsm_vel = 0.005;         /**< gain for recursive exponential velocity smoothening */
    double _expsm_acc = 0.005;         /**< gain for recursive exponential acceleration smoothening */

    // Kalman filter parameters (same for all vehicles, and in x,y,z), all > 0
    // Values closer to zero will rely on measurements more
    double _tau_estpos = 0.0001;    /**< kalman gain for fusing position model and measurement estimates */
    double _tau_estvel = 0.045;     /**< kalman gain for fusing velocity model and measurement estimates */
    double _tau_estacc = 0.750;     /**< kalman gain for fusing acc model and measurement estimates */
    double _tau_estrot = 0.001;     /**< kalman gain for fusing euler angle model and measurement estimates */
    double _tau_estomg = 0.001;     /**< kalman gain for fusing body rate model and measurement estimates */

    bool _bdebugprint = true;       /**< true to enable some extra debug printing */
    ros::Time _tend;                /**< ROS time to perform debug run-time calculations */

    // Performance Monitor
    PerfCounterBase* _perf_intvl;   /**< performance monitor for estimator */
    PerfCounterBase* _perf_elpsed;  /**< performance monitor for estimator */

    /* Methods */

    /** Callback function takes marker data and publishes full state estimate.
     *
     * This runs the main estimator pipeline. This includes extracting markers,
     * matching markers to each vehicle, post-processing the estimates, and
     * publishing the estimates (to be at the same frequency as the marker updates)
     *
     * The frame-by-frame position measurements from marker matching are used to
     * calculate the velocities and accelerations. Additional smoothening may be employed.
     * At the same time, a new estimate is generated using the previous estimate
     * and a vehicle model. These model (prior) estimates and measurements are fused
     * using a Kalman filter (although, it seems more like just an exponential weighting
     * tradeoff)
     *
     * @param msg vicon marker message data
     */
    void _cb_update(const vicon_bridge::Markers& msg);

    /** Extract relevant Vicon markers, all data is in meters
     *
     * @param msg vicon marker message data
     * @param markers extracted markers
     */
    void _extract_markers(const vicon_bridge::Markers& msg, V3vec& markers);

    /** Run the autogrid initialization procedure.
     *
     * The markers are assigned onto an appropriate grid point, see cluster.h
     * This relies on the correct number of clusters in the x and y directions
     * (they do not need to be evenly spaced), but there must be an exact number of
     * markers and they must be uniquely assignable to a grid point.
     * If success, enough good frames with the same matching must pass in order
     * to complete the initialization.
     *
     * Currently doesn't support multiple markers per drone
     *
     * @param markers extracted vicon markers
     */
    void _autogrid_init(const V3vec& markers);

    /** Match markers to vehicles based on tolerance to latest positions.
     *
     * Supports multiple markers per drone
     *
     * @param markers extracted vicon markers
     */
    void _assign_tolerance(const V3vec& markers);

    /** Helper function to marker matching, computes the tolerance.
     *
     * The minimum pairwise distance squared between the latest vehicle positions
     * is computed and then the smaller of this distance squared (quartered) and
     * a predefined tolerance is returned.
     * This tolerance is meant to be tight but not too tight, to ensure that
     * markers can be matched reliably but without two vehicles matched to the same marker.
     *
     * @return the tolerance as a distance squared
     */
    double _computetolerancesq();

    /** Use multi-markers to determine pose measurement
     *
     */
    void _multimarker2pose();

    /** Detect and handle outliers in marker positions
     *
     */
    void _outliermarkers();

    /** Compute prior updates based on the double integrator model
     *
     * Assumes constant acceleration.
     *
     * Updates only the prior values
     */
    void _update_prior();

    /** Numerical differentiation and signal smoothening.
     *
     * Updates the current measurement's smoothed values only
     *
     * Two options are possible for smoothing based on ViconMapper::_algsmooth
     *  - (0) none
     *  - (1) exponential smoothing of current and previous data
     *
     * Derivatives are based on the current and most previous data only.
     */
    void _process_meas();

    /** Fuse prior update with the smoothed measurements using Kalman gains.
     *
     */
    void _update_estimate();

    /** Publish the swarm state (all in standard units).
     *
     * Uses the same time stamp as from the vicon markers.
     *
     * @param msg vicon marker message data (only need the time specifically)
     */
    void _publish_states(const vicon_bridge::Markers& msg);
};

#endif //PROJECT_VICON_MAPPING_H
