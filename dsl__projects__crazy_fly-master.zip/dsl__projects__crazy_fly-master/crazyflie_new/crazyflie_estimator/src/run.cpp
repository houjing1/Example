/*
 * run.cpp
 *
 *  Created On : Apr 02, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#include "crazyflie_estimator/vicon_mapping.h"

/** Runs a ROS node to run the crazyflie swarm estimator.
 *
 * @param argc Not used
 * @param argv Not used
 * @return 0
 */
int main(int argc, char **argv){
    ros::init(argc, argv, "crazyflie_estimator");
    ros::NodeHandle nh;
    ViconMapper mapper(&nh);
    ros::spin();

    return 0;
}
