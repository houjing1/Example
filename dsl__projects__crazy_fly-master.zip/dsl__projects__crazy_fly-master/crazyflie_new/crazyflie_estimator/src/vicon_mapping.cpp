/*
 * vicon_mapping.cpp
 *
 *  Created On : Apr 02, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#include <math.h>
#include <iostream>
#include <algorithm>

#include "nodelet/nodelet.h"
#include "pluginlib/class_list_macros.h"

#include "crazyflie_estimator/vicon_mapping.h"
#include "crazyflie_estimator/cluster.h"

// marker to vehicle tolerance distance squared (m^2)
static const double tolsq = 0.01;  // 10 cm tolerance

// max boundaries of Vicon room, in meters
static const double room_max_x = 4.0;
static const double room_max_y = 4.0;
static const double room_max_z = 3.0;
static const double room_min_x = -4.0;
static const double room_min_y = -4.0;
static const double room_min_z = -0.1;


ViconMapper::ViconMapper(ros::NodeHandle* nh):
        _nh(nh)
{
    _nh->getParam("vehicles/num", _nveh);  // check it is updated!

    // Initialize vehicle positions
    _initpos.assign(_nveh, V3::Zero());

    _nh->getParam("estimator/tau_estpos", _tau_estpos);
    _nh->getParam("estimator/tau_estvel", _tau_estvel);
    _nh->getParam("estimator/tau_estacc", _tau_estacc);

    _nh->getParam("estimator/smoothen", _algsmooth);
    _nh->getParam("estimator/init_autogrid", _init_autogrid);

    if (_init_autogrid && _multim)
        std::cout << "Quit, multimarker autoinit is not supported yet!\n";

    //std::cout << "Autogrid " << _init_autogrid << '\n';
    if (!_init_autogrid) {
        // Upload the initial positions
        XmlRpc::XmlRpcValue init_pos;
        _nh->getParam("vehicles/init_pos", init_pos);  // check it is updated
        ROS_ASSERT(init_pos.getType() == XmlRpc::XmlRpcValue::TypeArray);
        if (_nveh > init_pos.size())
            std::cout << "Not enough specified initial positions!\n";

        for (int i = 0; i < _nveh; ++i) {
            XmlRpc::XmlRpcValue data = init_pos[i];
            ROS_ASSERT(data.getType() == XmlRpc::XmlRpcValue::TypeArray);
            if (data.size() != 2)
                std::cout << "Too many coordinates!\n";
            ROS_ASSERT(data[0].getType() == XmlRpc::XmlRpcValue::TypeDouble);
            ROS_ASSERT(data[1].getType() == XmlRpc::XmlRpcValue::TypeDouble);

            // Update x,y coordinates only since on the ground
            _initpos[i][0] = static_cast<double>(data[0]);
            _initpos[i][1] = static_cast<double>(data[1]);
        }
        _init_ready = true;
    }
    else {
        _nh->getParam("estimator/init_ncols", _init_ncols);  // assumes at least 1
        _nh->getParam("estimator/init_nrows", _init_nrows);
        // std::cout << "Params " << _nveh << " " << _init_ncols << " " << _init_nrows << '\n';
        if (_nveh > _init_ncols * _init_nrows || _nveh < _init_ncols || _nveh < _init_nrows)
            std::cout << "Inadequate row-col set-up... abort!\n";

        // Upload the specified drone index order
        bool bcustomorder;
        _nh->getParam("estimator/init_customorder", bcustomorder);
        if (bcustomorder) {
            XmlRpc::XmlRpcValue init_order;
            _nh->getParam("estimator/init_order", init_order);  // check it is updated
            ROS_ASSERT(init_order.getType() == XmlRpc::XmlRpcValue::TypeArray);
            if (init_order.size() != _nveh)
                std::cout << "Bad index order size\n";
            for (int i = 0; i < _nveh; ++i)
                _init_order.push_back(static_cast<int>(init_order[i]) - 1);  // 0-based indexing
        }
        else  // use default order
        {
            for (int i = 0; i < _nveh; ++i)
                _init_order.push_back(i);
        }
    }
    _nframesbad.assign(_nveh, 0);
    _nframesout.assign(_nveh, 0);
    _geo.assign(_nveh, Geo3M());

    // Publish swarm state
    _pub_swarmstates = _nh->advertise<crazyflie_estimator::SwarmStates>("full_state", 30);
    _pub_swarmstates_meas = _nh->advertise<crazyflie_estimator::SwarmStatesRaw>("full_state_meas", 30);
    
    // Add PerfCounter to PerfMonitor
    _perf_elpsed = PerfMonitor::addPerf(Elapsed, "ViconMap_map");
    _perf_intvl = PerfMonitor::addPerf(Interval, "ViconMap_markers");

    // Subscribe to vicon marker updates, must be done after publisher to avoid crashes
    _sub_markerupdate = _nh->subscribe("vicon/markers", 30, &ViconMapper::_cb_update, this);
    ROS_INFO_STREAM("Finished Estimator Initialization");
}

void ViconMapper::_cb_update(const vicon_bridge::Markers& msg)
{
    _perf_intvl->count();
    _perf_elpsed->begin();

    ros::Time tstart = ros::Time::now();

    // Calculate time step, since last frame was given
    double t = msg.header.stamp.toSec();  // time stamp
    double dt = 0.0;
    if (_measqueue.size())  // check if there is a previous measurement
    {
        dt = t - _measqueue.front().t;
        // Detect negative or impossibly small time steps
        // this should not happen, so do not publish if this occurs
        if (dt < 0.001)
        {
            std::cout << "Vicon data time step too small or negative!\n";
            return;
        }
    }

    V3vec markers;
    _extract_markers(msg, markers);

    if (!_init_ready)
    {
        _autogrid_init(markers);
        return;  // cannot publish yet
    }

    // Create new measurement object on queue, remove oldest
    int npts = _multim ? 3 : 1;
    MeasData measnew(_nveh, npts, t, msg.header.stamp.toNSec());
    _measqueue.push_front(measnew);
    if (_measqueue.size() > _qsize)
        _measqueue.pop_back();

    // Run the marker assignment
    _assign_tolerance(markers);

    if (_measqueue.size() > 1) {
        _multimarker2pose();

        // Process markers for outliers
        _outliermarkers();

        // Estimate the remaining states, update the queues
        _process_meas();

        // Update estimated states using prior
        _update_prior();
    }

    // Update the estimated state, fusing prior and measurements
    _update_estimate();

    _publish_states(msg);

    // Time tests
    double dt_delay = tstart.toSec() - _tend.toSec();
    _tend = ros::Time::now();  // overwrite
    double dt_cur = _tend.toSec() - tstart.toSec();
    if (dt_cur > 0.005)
        std::cout << "Estimator computation not sufficient for 200Hz\n";

    if (_bdebugprint && false) {
        std::cout << "Estimator process time = " << dt_cur << '\n';
        std::cout << "Meas process delay = ";
        std::cout << tstart.toSec() - _measqueue.front().t << '\n';
        std::cout << "Callback delay = " << dt_delay << '\n';
    }

    _perf_elpsed->end();
    // _perf_intvl->print_info();
    ros::spinOnce();
}

void ViconMapper::_extract_markers(const vicon_bridge::Markers& msg,
                                   V3vec& markers)
{
    // Make a copy of only unlabelled markers
    std::vector<vicon_bridge::Marker>::const_iterator it;
    for (it = msg.markers.begin(); it != msg.markers.end(); ++it)
    {
        if (it->marker_name.empty())  // unlabelled marker
        {
            // Markers from vicon are in mm, so convert to m
            double x = it->translation.x / 1000.0;
            double y = it->translation.y / 1000.0;
            double z = it->translation.z / 1000.0;

            // Check if within Vicon room
            if (x < room_max_x && x > room_min_x &&
                    y < room_max_y && y > room_min_y &&
                    z < room_max_z && z > room_min_z)
                markers.emplace_back(Eigen::Vector3d(x, y, z));
        }
    }
    if (_bdebugprint && false) {
        for (int i = 0; i < markers.size(); ++i)
            std::cout << "Marker " << i << ": " << markers[i] << '\n';
    }
}

void ViconMapper::_autogrid_init(const V3vec& markers)
{
    _init_nframestry++;
    if (_init_nframestry >= 100 || _multim)
    {
        std::cout << "Failed to autogrid initialize... abort\n";
        return;
    }

    // Determine which markers are on ground and extract x, y
    std::vector<double> xdat;
    std::vector<double> ydat;
    std::vector<double> zdat;
    for (int im = 0; im < markers.size(); ++im)
    {
        // height less than 10 cm should qualify as on the ground
        if (markers[im][2] < 0.1)
        {
            xdat.push_back(markers[im][0]);
            ydat.push_back(markers[im][1]);
            zdat.push_back(markers[im][2]);
        }
    }
    if (xdat.size() != _nveh) {
        _init_nframesgood = 0;  // reset
        std::cout << "Unexpected number of markers, trying again...\n";
        return;  // abort this frame, marker size not compatible
    }

    // Run clustering algorithm
    std::vector<int> finalorder;
    gridcluster(xdat, _init_ncols, ydat, _init_nrows, finalorder);
    if (!finalorder.size()) {
        _init_nframesgood = 0;  // reset
        return;
    }

    if (_init_nframesgood == 0)
    {
        // Set the data as first estimate in the determined order
        for (int i = 0; i < _nveh; ++i) {
            int idx = finalorder[i];
            _initpos[_init_order[i]] << xdat[idx], ydat[idx], zdat[idx];
        }
        _init_nframesgood++;
    }
    else
    {
        // Compare the data to the previous estimate
        bool bclose = true;
        for (int i = 0; i < _nveh; ++i) {
            int idx = finalorder[i];
            int idx2 = _init_order[i];
            V3 pt(xdat[idx], ydat[idx], zdat[idx]);
            double dsq = (pt - _initpos[idx2]).squaredNorm();
            _initpos[idx2] = pt;  // overwrite, in case earlier was off
            if (dsq > tolsq)  // since not moving, can have tight tolerance
            {
                bclose = false;
                break;
            }
        }
        if (bclose)
            _init_nframesgood++;
        else {
            _init_nframesgood = 0;
            std::cout << "Mismatch from previous frame, reset...\n";
        }
    }

    // Initialization is complete if enough good frames have passed
    if (_init_nframesgood >= 10) {
        _init_ready = true;
        std::cout << "Estimator auto-initialization complete!\n";
        for (int i = 0; i < _nveh; ++i)
        {
            std::cout << "Est. pos " << i << ": ";
            std::cout << _initpos[i][0] << ", " << _initpos[i][1] << '\n';
        }
    }

}

void ViconMapper::_assign_tolerance(const V3vec& markers)
{
    // Updates pos and posvalid fields in MeasData
    int n_unassigned = 0;

    // Compute new tolerance (squared)
    double tsq = _computetolerancesq();

    for (int i = 0; i < _nveh; ++i) {
        VehData& vn = _measqueue[0].dat[i];
        // Scan the area around each vehicle for markers
        int nmarker = 0;
        Idx3 midx = {{-1, -1, -1}};

        // Extract the correct reference point
        V3* prevpos = &_initpos[i];
        if (_measqueue.size() > 1)
            prevpos = &_measqueue[1].dat[i].pos_f;

        for (int im = 0; im < markers.size(); ++im) {
            double dsq = (markers[im] - *prevpos).squaredNorm();
            if (dsq < tsq) {
                midx[nmarker] = im;
                nmarker++;
                if (false)
                    std::cout << sqrt(dsq) << "; matched v " << i << " with m " << im << '\n';

                if ((!_multim && nmarker > 1) || (_multim && nmarker > 3))
                    break;  // quit, too many markers assigned to current drone
            }
        }

        // Store the markers
        bool bpass = false;
        if (!_multim) {
            // Only updates if there is a unique marker
            // With new tolerance, the same marker cannot be matched to more than one vehicle
            if (nmarker == 1) {
                vn.mstatus[0] = 1;  // confirm this vehicle is matched to the single marker
                vn.m1 = markers[midx[0]];  // record raw marker
                bpass = true;
            }
        }
        else {
            // Must use geometry to identify the markers
            if (_measqueue.size() == 1 && nmarker == 3)
            {
                // Set the geometry, should be approximately zero yaw on the ground
                double dsq01 = (markers[midx[0]] - markers[midx[1]]).squaredNorm();
                double dsq12 = (markers[midx[1]] - markers[midx[2]]).squaredNorm();
                double dsq20 = (markers[midx[2]] - markers[midx[0]]).squaredNorm();
                Idx3 o3 = {{-1, -1, -1}};
                if (dsq01 < dsq12 && dsq01 < dsq20)
                {
                    o3[0] = 0;
                    o3[1] = 1;
                    o3[2] = 2;
                    if (markers[midx[1]][0] > markers[midx[2]][0])
                    {
                        o3[1] = 2;
                        o3[2] = 1;
                    }
                }
                else if (dsq12 < dsq01 && dsq12 < dsq20)
                {
                    o3[0] = 1;
                    o3[1] = 0;
                    o3[2] = 2;
                    if (markers[midx[0]][0] > markers[midx[2]][0])
                    {
                        o3[1] = 2;
                        o3[2] = 0;
                    }
                }
                else if (dsq20 < dsq01 && dsq20 < dsq12)
                {
                    o3[0] = 2;
                    o3[1] = 0;
                    o3[2] = 1;
                    if (markers[midx[0]][0] > markers[midx[1]][0])
                    {
                        o3[1] = 1;
                        o3[2] = 0;
                    }
                }
                else
                {
                    std::cout << "Bad initial geometry\n";
                }

                if (o3[0] != -1)
                {
                    //record raw markers and compute geometry
                    vn.m1 = markers[midx[o3[0]]];
                    vn.m2 = markers[midx[o3[1]]];
                    vn.m3 = markers[midx[o3[2]]];
                    V3 p21 = vn.m1 - vn.m2;
                    V3 p23 = vn.m3 - vn.m2;
                    V3 p13 = vn.m3 - vn.m1;
                    V3 prj = p23 * (p23.dot(p21) / p23.dot(p23));
                    V3 prp = p21 - prj;
                    V3 aprj = p23 - prj;

                    _geo[i].dsq12 = p21.dot(p21);
                    _geo[i].dsq23 = p23.dot(p23);
                    _geo[i].dsq13 = p13.dot(p13);
                    _geo[i].d1 = prp.norm();
                    _geo[i].d2 = prj.norm();
                    _geo[i].d3 = aprj.norm();

                    for (int k = 0; k < 3; ++k)
                        vn.mstatus[k] = 1;

                    bpass = true;
                }

            }
            else if (_measqueue.size() > 1 && nmarker == 3) {
                // Only updates if there are up to three markers
                // Matches each to closest marker from previous iteration
                // (using previous pose) and validates the geometry

                Idx3 o3 = {{0, 0, 0}};
                VehData& vp = _measqueue[1].dat[i];
                std::vector<V3*> pmrk = {&vp.m1, &vp.m2, &vp.m3};

                for (int i1 = 0; i1 < 3; ++i1)
                {
                    double mindsq = (markers[midx[i1]] - *pmrk[0]).squaredNorm();
                    for (int i2 = 1; i2 < 3; ++i2)
                    {
                        double dsq = (markers[midx[i1]] - *pmrk[i2]).squaredNorm();
                        if (dsq < mindsq)
                        {
                            mindsq = dsq;
                            o3[i1] = i2;
                        }
                    }
                }
                // TO DO: Can check o3 is a permutation of 0,1,2

                //record raw markers and compute geometry
                vn.m1 = markers[midx[o3[0]]];
                vn.m2 = markers[midx[o3[1]]];
                vn.m3 = markers[midx[o3[2]]];

                // TO DO: Can validate geometry

                for (int k = 0; k < 3; ++k)
                    vn.mstatus[k] = 1;

                bpass = true;
            }
        }

        if (bpass)
            _nframesbad[i] = 0;  // reset
        else
        {
            n_unassigned++;
            _nframesbad[i]++;
        }
    }

    if (_bdebugprint && false)
    {
        // Print which vehicles have no update
        if (n_unassigned > 0)
        {
            std::cout << "Vehicle indices with no markers assigned: ";
            for (int i = 0; i < _nveh; ++i)
            {
                if (_nframesbad[i])
                    std::cout << i << ", ";
            }
            std::cout << '\n';
        }
    }
}

double ViconMapper::_computetolerancesq()
{
    if (_nveh == 1)
        return tolsq;

    // Compute minimum pairwise distance sq. between current vehicle positions
    // Use initial positions or previous measurements
    double mdsq = 0;
    if (_measqueue.size() == 1)
    {
        mdsq = (_initpos[0] - _initpos[1]).squaredNorm();
        for (int i = 0; i < _nveh-1; ++i)
        {
            for (int j = i+1; j < _nveh; ++j)
            {
                double dsq = (_initpos[i] - _initpos[j]).squaredNorm();
                if (dsq < mdsq)
                    mdsq = dsq;
            }
        }
    }
    else {
        mdsq = (_measqueue[1].dat[0].pos_f - _measqueue[1].dat[1].pos_f).squaredNorm();
        for (int i = 0; i < _nveh-1; ++i)
        {
            for (int j = i+1; j < _nveh; ++j)
            {
                double dsq = (_measqueue[1].dat[i].pos_f
                              - _measqueue[1].dat[j].pos_f).squaredNorm();
                if (dsq < mdsq)
                    mdsq = dsq;
            }
        }
    }

    // Take half of min distance (for bare min. safety), then half of that
    // (robustness), and then square this to get the desired tolerance squared
    // Take the smaller of the hard coded tolerance and the desired
    // Then take the larger of this value and the geometry (for multi-marker)
    return std::max(std::min(mdsq / 16.0, tolsq), _geo[0].d1);
}

void ViconMapper::_outliermarkers()
{
    double dt = _measqueue[0].t - _measqueue[1].t;

    if (_multim)
        return;

    // Parameters, set these elsewhere later
    // Outlier rejection currently disabled; performance did not look better and
    // in some cases even worse (position gets sidetracked by prior until reset)
    bool baction = false;
    bool breject = false;

    for (int i = 0; i < _nveh; ++i)
    {
        VehData& vn = _measqueue[0].dat[i];  // new
        const VehData& vp = _measqueue[1].dat[i];  // previous

        if (vn.mstatus[0] == 1)
        {
            // Raw position is the matched marker
            vn.pos_r = vn.m1;

            bool boutlier = false;

            // Test accelerations exceeding 2g per component
            V3 a = (vn.pos_r - vp.pos_f - dt * vp.vel_f) / (dt * dt);
            for (int j = 0; j < 3; ++j) {
                if (fabs(a[j]) > 2.0 * 9.81) {
                    if (baction)
                        boutlier = true;
                    vn.moutlier[j] = 1;  // record the outlier
                    // std::cout << "Exceed " << j << " " << a[j] << '\n';
                }
            }

            if (boutlier) {
                if (_nframesout[i] > 2)
                {
                    // std::cout << i << " Too many frames as outlier, reset\n";
                    _nframesout[i] = 0;
                }
                else {
                    _nframesout[i]++;
                    if (breject)
                        vn.mstatus[0] = 0;
                }
            }
            else {
                _nframesout[i] = 0;  // reset
            }
        }
    }
}

void ViconMapper::_multimarker2pose()
{
    if (!_multim)
        return;

    for (int i = 0; i < _nveh; ++i)
    {
        VehData& vn = _measqueue[0].dat[i];

        V3 p23 = vn.m3 - vn.m2;
        V3 p21 = vn.m1 - vn.m2;
        V3 prj = p23 * (p23.dot(p21) / p23.dot(p23));
        V3 prp = p21 - prj;

        // Store raw position of COM in world frame
        vn.pos_r = vn.m2 + prj;

        // Create columns for rotation matrix, takes coords from body to world
        V3 r1 = p23 / p23.norm();
        V3 r2 = prp / prp.norm();
        V3 r3 = r1.cross(r2);
        Eigen::Matrix3d R;
        R.col(0) = r1;
        R.col(1) = r2;
        R.col(2) = r3;

        // Can do sanity checks, the reconstructed marker points should be close
        double er1 = (_geo[i].d1 * r2 + vn.pos_r - vn.m1).squaredNorm();
        double er2 = (-_geo[i].d2 * r1 + vn.pos_r - vn.m2).squaredNorm();
        double er3 = (_geo[i].d3 * r1 + vn.pos_r - vn.m3).squaredNorm();
        std::cout << "Marker remap errors: ,";
        std::cout << er1 << ", " << er2 << ", " << er3 << std::endl;

        // Extract euler angles ZXY (yaw, roll, pitch) and store the raw values
        vn.yrp_r << asin(r2[2]), -atan(r2[0]/r2[1]), -atan(r1[2]/r3[2]);

        // Check we recover the matrix, build from principal axis rotations
        Eigen::Matrix3d My;
        My << cos(vn.yrp_r[0]), -sin(vn.yrp_r[0]), 0,
                sin(vn.yrp_r[0]), cos(vn.yrp_r[0]), 0,
                0, 0, 1;
        Eigen::Matrix3d Mr;
        Mr << 1, 0, 0,
              0, cos(vn.yrp_r[1]), -sin(vn.yrp_r[1]),
              0, sin(vn.yrp_r[1]), cos(vn.yrp_r[1]);
        Eigen::Matrix3d Mp;
        Mp << cos(vn.yrp_r[2]), 0, sin(vn.yrp_r[2]),
              0, 1, 0,
              -sin(vn.yrp_r[2]), 0, cos(vn.yrp_r[2]);
        std::cout << "rot error: " << (R - My*Mr*Mp).squaredNorm() << std::endl;

    }
}

void ViconMapper::_process_meas()
{
    double dt = _measqueue[0].t - _measqueue[1].t;

    for (int i = 0; i < _nveh; ++i)
    {
        VehData& vn = _measqueue[0].dat[i];  // new
        const VehData& vp = _measqueue[1].dat[i];  // previous

        // Check that the raw measurement is valid, for multimarker we currently need all 3
        int status = 0;
        for (int j = 0; j < 3; ++j)
            status += vn.mstatus[j];
        if ((_multim && status < 3) || (!_multim && status < 1))
            continue;

        // Smoothen position using raw position measurements
        if (_algsmooth == 0)  // None
        {
            vn.pos_s = vn.pos_r;
        }
        else  // exp smoothening
        {
            // Uses the previous fused values since they are guaranteed to be defined
            double a = 1 - exp(-dt / _expsm_pos);
            vn.pos_s = a * vn.pos_r + (1 - a) * vp.pos_f;
        }

        // Finite difference using just current and previous positions
        vn.vel_r = (vn.pos_s - vp.pos_f) / dt;

        // Smoothen velocity
        if (_algsmooth == 0)  // None
        {
            vn.vel_s = vn.vel_r;
        }
        else  // exp smoothening
        {
            // Uses the previous fused values since they are guaranteed to be defined
            double a = 1 - exp(-dt / _expsm_vel);
            vn.vel_s = a * vn.vel_r + (1 - a) * vp.vel_f;
        }

        // Finite difference using just current and previous velocities
        vn.acc_r = (vn.vel_s - vp.vel_f) / dt;

        // Smoothen acceleration
        if (_algsmooth == 0)  // None
        {
            vn.acc_s = vn.acc_r;
        }
        else  // exp smoothening
        {
            // Uses the previous fused values since they are guaranteed to be defined
            double a = 1 - exp(-dt / _expsm_acc);
            vn.acc_s = a * vn.acc_r + (1 - a) * vp.acc_f;
        }

        // TO DO Smoothen angles, get body rates, smoothen body rates
    }
}

void ViconMapper::_update_prior()
{
    double dt = _measqueue[0].t - _measqueue[1].t;
    for (int i = 0; i < _nveh; ++i)
    {
        VehData& vn = _measqueue[0].dat[i];  // new
        const VehData& vp = _measqueue[1].dat[i];  // previous
        vn.pos_p = vp.pos_f + dt * vp.vel_f + 0.5 * dt * dt * vp.acc_f;
        vn.vel_p = vp.vel_f + dt * vp.acc_f;
        vn.acc_p = vp.acc_f;

        // TO DO: ROTATION
    }
}

void ViconMapper::_update_estimate()
{
    if (_measqueue.size() == 1)
    {
        // Use first measurement as is; it is not an outlier, and its velocities,
        // accelerations, angles, and body rates are zero
        for (int i = 0; i < _nveh; ++i)
        {
            VehData& vn = _measqueue[0].dat[i];
            vn.pos_r = _initpos[i];
            vn.pos_s = _initpos[i];
            vn.pos_f = _initpos[i];
        }
    }
    else
    {
        // Calculate current Kalman filter gains
        double dt = _measqueue[0].t - _measqueue[1].t;
        double c1 = exp(-dt / _tau_estpos);
        double c2 = exp(-dt / _tau_estvel);
        double c3 = exp(-dt / _tau_estacc);
        double d1 = exp(-dt / _tau_estrot);
        double d2 = exp(-dt / _tau_estomg);

        for (int i = 0; i < _nveh; ++i)
        {
            VehData& vn = _measqueue[0].dat[i];
            // Fuse measurement and prior estimate, otherwise just rely on prior
            // Check that the raw measurement is valid, for multimarker we currently need all 3
            int status = 0;
            for (int j = 0; j < 3; ++j)
                status += vn.mstatus[j];
            if ((_multim && status < 3) || (!_multim && status < 1))
            {
                vn.pos_f = vn.pos_p;
                vn.vel_f = vn.vel_p;
                vn.acc_f = vn.acc_p;
                vn.yrp_f = vn.yrp_p;
                vn.omg_f = vn.omg_p;
            }
            else
            {
                double c1a = c1;
                if (_nframesout[i] > 0)  // adapt the gain to use more of the prior
                    c1a = exp(-1.0);  // can set this value elsewhere

                vn.pos_f = (1.0-c1a) * vn.pos_s + c1a * vn.pos_p;
                vn.vel_f = (1.0-c2) * vn.vel_s + c2 * vn.vel_p;
                vn.acc_f = (1.0-c3) * vn.acc_s + c3 * vn.acc_p;

                // Is this appropriate?
                vn.yrp_f = (1.0-d1) * vn.yrp_s + d1 * vn.yrp_p;
                vn.omg_f = (1.0-d2) * vn.omg_s + d2 * vn.omg_p;
            }
        }
    }
}

void ViconMapper::_publish_states(const vicon_bridge::Markers& msg)
{
    // Package the swarm state
    crazyflie_estimator::SwarmStates swarm_msg;
    for (int i = 0; i < _nveh; i++)
    {
        const VehData& vn = _measqueue[0].dat[i];
        crazyflie_estimator::FullState state;

        for (int j = 0; j < 3; ++j)
        {
            state.pos[j] = vn.pos_f[j];
            state.vel[j] = vn.vel_f[j];
            state.acc[j] = vn.acc_f[j];
            state.yrp[j] = vn.yrp_f[j];
            state.omega[j] = vn.omg_f[j];
        }

        // Do not trust state if too many bad frames passed
        if (_nframesbad[i] < 10)
            state.bfeasible = 1;
        else
            state.bfeasible = 0;

        swarm_msg.fullstate.push_back(state);
    }
    swarm_msg.header = msg.header;
    _pub_swarmstates.publish(swarm_msg);

    // Package the swarm state raw
    crazyflie_estimator::SwarmStatesRaw swarm_meas_msg;

    for (int i=0; i<_nveh; ++i) {
        const VehData& vn = _measqueue[0].dat[i];
        crazyflie_estimator::FullStateRaw state_meas;

        for (int j = 0; j < 3; ++j)
        {
            state_meas.boutlier[j] = vn.moutlier[j];
            state_meas.mrawp1[j] = (float)vn.m1[j];
            state_meas.mrawp2[j] = (float)vn.m2[j];
            state_meas.mrawp3[j] = (float)vn.m3[j];

            state_meas.pos_r[j] = (float)vn.pos_r[j];
            state_meas.vel_r[j] = (float)vn.vel_r[j];
            state_meas.acc_r[j] = (float)vn.acc_r[j];

            state_meas.pos_s[j] = (float)vn.pos_s[j];
            state_meas.vel_s[j] = (float)vn.vel_s[j];
            state_meas.acc_s[j] = (float)vn.acc_s[j];

            state_meas.pos_p[j] = (float)vn.pos_p[j];
            state_meas.vel_p[j] = (float)vn.vel_p[j];
            state_meas.acc_p[j] = (float)vn.acc_p[j];

            state_meas.pos_f[j] = (float)vn.pos_f[j];
            state_meas.vel_f[j] = (float)vn.vel_f[j];
            state_meas.acc_f[j] = (float)vn.acc_f[j];

            // Add debug rotation info later...
        }

        int status = 0;
        for (int j = 0; j < 3; ++j)
            status += vn.mstatus[j];
        if ((_multim && status < 3) || (!_multim && status < 1))
            state_meas.valid = 0;
        else
            state_meas.valid = 1;

        if (_nframesbad.at(i) < 10)
            state_meas.bfeasible = 1;
        else
            state_meas.bfeasible = 0;

        swarm_meas_msg.fullstateraw.push_back(state_meas);

    }
    swarm_meas_msg.header = msg.header;
    _pub_swarmstates_meas.publish(swarm_meas_msg);

}

/** Class to run the estimator with ROS nodelets.
 *
 */
class ViconMapNodelet : public nodelet::Nodelet{
public:
    ViconMapNodelet() {};

    ~ViconMapNodelet(){delete mapper;};

private:
    virtual void onInit(){
        ROS_INFO_STREAM("Strarting ViconMapperNodelet");
        nh = &getNodeHandle();
        ViconMapper* mapper = new ViconMapper(nh);
    }
    ViconMapper* mapper;
    ros::NodeHandle* nh;
};

PLUGINLIB_EXPORT_CLASS(ViconMapNodelet, nodelet::Nodelet)