/*
 * cluster.cpp
 *
 *  Created On : May 13, 2018
 *      Author : Mario Vukosavljev
 *      Email  : mario.vukosavljev@robotics.utias.utoronto.ca
 */

#include <utility>
#include <iostream>
#include <algorithm>

#include "crazyflie_estimator/cluster.h"

/** Comparison function to sort a vector of <int,int> pairs based on the first int value.
 *
 * @param a the first argument
 * @param b the second argument
 * @return true if a.first < b.first, else false
 */
bool comparefirst(std::pair<int, int>& a, std::pair<int, int>& b)
{
    return (a.first < b.first);
}

/** Comparison function to sort a vector of <double,int> pairs based on the double value.
 *
 * @param a the first argument
 * @param b the second argument
 * @return true if a.first < b.first, else false
 */
bool comparefirst_double(std::pair<double, int>& a, std::pair<double, int>& b)
{
    return (a.first < b.first);
}

/** Perform 1D clustering using a custom algorithm.
 *
  * The output result is a vector of indices (0, ... K-1) ordering the data from
 * smallest to largest values
 *
 * The algorithm first sorts the data from smallest to largest, and then computes
 * the differences between the sorted points. The K-1 largest differences give the
 * K clusters.
 *
 * @param dat input data, vector of 1D data
 * @param clusteridx output result
 * @param K the number of clusters
 * @return true on success, false on failure
 */
bool clusters1D(const std::vector<double>& dat,
                std::vector<int>& clusteridx, int K)
{
    int N = dat.size();
    if (N < K)
        return false;

    // Initialize all data in first cluster
    for (int i = 0; i < N; ++i)
        clusteridx.push_back(0);

    if (K == 1) {
        return true;  // nothing to do
    }

    // Created ordered data, keep track of original index
    std::vector< std::pair<double, int> > odat;
    for (int i = 0; i < N; ++i)
        odat.push_back(std::make_pair(dat.at(i), i));
    std::sort(odat.begin(), odat.end(), comparefirst_double);

    if (false) {
        std::cout << "odat\n";
        for (int i = 0; i < N; ++i)
            std::cout << "(" << odat.at(i).first << ", " << odat.at(i).second << "), ";
        std::cout << '\n';
    }

    // Compute differences and sort
    std::vector< std::pair<double, int> > odiff;
    for (int i = 1; i < N; ++i) {
        double diff = odat.at(i).first - odat.at(i - 1).first;
        odiff.push_back(std::make_pair(diff, i));
    }
    std::sort(odiff.begin(), odiff.end(), comparefirst_double);

    if (false) {
        std::cout << "odiff\n";
        for (int i = 0; i < N - 1; ++i)
            std::cout << "(" << odiff.at(i).first << ", " << odiff.at(i).second << "), ";
        std::cout << '\n';
    }

    // Determine the partitioning, sort the gaps
    std::vector<int> ogaps;
    int i = N-2;
    for (int k = 0; k < K-1; ++k)
    {
        ogaps.push_back(odiff.at(i).second);
        --i;
    }
    std::sort(ogaps.begin(), ogaps.end());

    if (false) {
        std::cout << "ogaps\n";
        for (int i = 0; i < K - 1; ++i)
            std::cout << ogaps.at(i) << ", ";
        std::cout << '\n';
    }

    // Assign each datum the cluster
    int k = 0;
    for (int i = 0; i < N; ++i)
    {
        clusteridx.at(odat.at(i).second) = k;
        if (k < K-1 && i == ogaps.at(k)-1)
            ++k;
    }

    if (false) {
        std::cout << "Clusters: ";
        for (int i = 0; i < clusteridx.size(); i++) {
            std::cout << clusteridx.at(i) << ", ";
        }
        std::cout << '\n';
    }

    // Optional: check that within each cluster, the max distance
    // of a point to the mean is not too close to neighbouring cluster means

    // First compute cluster means
    std::vector<double> means(K, 0);
    std::vector<int> num_per_cluster(K, 0);
    for (int i = 0; i < N; ++i)
    {
        means.at(clusteridx.at(i)) += dat.at(i);
        num_per_cluster.at(clusteridx.at(i))++;
    }
    for (int k = 0; k < K; ++k)
        means.at(k) /= num_per_cluster.at(k);

    if (false) {
        std::cout << "Clusters means: ";
        for (int k = 0; k < K; k++) {
            std::cout << means.at(k) << ", ";
        }
        std::cout << '\n';
    }

    // Compute min distances between neighbouring clusters
    // reduce by factor of four for robustness
    std::vector<double> mindists;
    double dist = means.at(1) - means.at(0);
    mindists.push_back(dist / 4);
    for (int k = 1; k < K-1; ++k)
    {
        double distnext = means.at(k+1) - means.at(k);
        mindists.push_back(std::min(dist, distnext) / 4);
        dist = distnext;
    }
    mindists.push_back(dist / 4);

    if (false) {
        std::cout << "Clusters dists: ";
        for (int k = 0; k < K; k++) {
            std::cout << mindists.at(k) << ", ";
        }
        std::cout << '\n';
    }

    for (int i = 0; i < N; ++i)
    {
        if (fabs(dat.at(i) - means.at(clusteridx.at(i))) >
                mindists.at(clusteridx.at(i)))
            return false;  // not close enough to mean
    }

    return true;

}

void gridcluster(const std::vector<double>& xdat, int Kx,
                 const std::vector<double>& ydat, int Ky,
                 std::vector<int>& finalorder)
{
    int N = xdat.size();  // same as ydat.size()
    // Perform Kmeans clustering on x and y independently
    std::vector<int> xclusters;
    std::vector<int> yclusters;
    bool xpass = clusters1D(xdat, xclusters, Kx);
    bool ypass = clusters1D(ydat, yclusters, Ky);
    // bool xpass = Kmeans_clusters1D(xdat, xclusters, Kx, 0.1);
    // bool ypass = Kmeans_clusters1D(ydat, yclusters, Ky, 0.1);
    if (!xpass || !ypass)
    {
        std::cout << "Failed clustering\n";
        return;
    }

    // Sort by dictionary order, and check for uniqueness
    std::vector< std::pair<int, int> > orderidx;
    for (int i = 0; i < N; ++i) {
        int idx = xclusters.at(i) + Kx * yclusters.at(i);
        orderidx.push_back(std::make_pair(idx, i));
        // std::cout << idx << " " << xclusters.at(i) << " " << yclusters.at(i) << '\n';
    }

    std::sort(orderidx.begin(), orderidx.end(), comparefirst);
    for (int i = 1; i < N; ++i) {
        if (orderidx.at(i).first == orderidx.at(i-1).first) {
            std::cout << "Two data matched to same grid point...\n";
            return;  // abort, two data at same grid point
        }
    }

    // Success, populate the return result
    for (int i = 0; i < N; ++i)
        finalorder.push_back(orderidx.at(i).second);

    return;
}