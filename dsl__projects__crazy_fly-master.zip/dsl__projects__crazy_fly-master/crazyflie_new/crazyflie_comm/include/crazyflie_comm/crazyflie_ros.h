/*
 * crazyflie_ros.h
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_CRAZYFLIE_ROS_H
#define PROJECT_CRAZYFLIE_ROS_H

#include <shared_mutex>

#include "ros/ros.h"
#include "crazyflie_cpp/Crazyflie.h"

#include "std_srvs/Empty.h"
#include "crazyflie_comm/GenericLogData.h"
#include "crazyflie_comm/LogBlock.h"
#include "crazyflie_comm/UpdateParams.h"

class CrazyflieROS{
public:
    CrazyflieROS(const std::string& link_uri,
                 const std::string& frame_id,
                 std::map<std::string, std::vector<crazyflie_comm::GenericLogData>> * log_data):
                      _cf(link_uri),
                      _uri(link_uri),
                      _logdata(log_data),
                      _isEmergency(false),
                      _frame_id(frame_id),
                      _flags() {};

    std::string _uri;
    /* Ping Crazyflie and bring back log data
     *
     */
    void ping();

    /* Trigger Emergency Mode and stop Sending Cmds
     *
     */
    void stop();

    /* Reboot Crazyflie
     */
    void reboot();

    /* Wake up Crazyflie from Sleep
     */
    void syson();

    /* Put Crazyflie to Sleep
     */
    void sysoff();

    /* Get onboard Log and Param TOC
     */
    void init();

    /* update on board parameters
     *      args:
     *            params: map from param name to desired value
     */
    bool update_params(std::map<std::string, float> params);

    /* Get prepared for flight
     *      1) register log blocks
     *      2) get latest param from Crazyflie
     *
     */
    void preflight_prep(std::vector<crazyflie_comm::LogBlock>& logdata_info);
private:
    Crazyflie _cf;                     // Hardware Abstraction Layer of Crazyflie
    std::string _frame_id;            // frame_id
    bool _isEmergency;                 // true if in emergency

    std::map<std::string,
             std::vector<crazyflie_comm::GenericLogData>>* _logdata;
                                        // log container at CrazyflieGroup
    std::map<std::string, float> _params;// current params


    struct Flags{
        Flags() :
                enableLogging(true),
                enableParameters(true),
                enable_logging_battery(true),
                enable_logging_imu(true),
                enable_logging_magnetic_field(false),
                enable_logging_temperature(false),
                enable_logging_pressure(false),
                use_ros_time(true) {};

        bool enableLogging;
        bool enableParameters;
        bool use_ros_time;
        bool enable_logging_imu;
        bool enable_logging_temperature;
        bool enable_logging_magnetic_field;
        bool enable_logging_pressure;
        bool enable_logging_battery;
    }_flags;

    struct logImu {
        float acc_x;
        float acc_y;
        float acc_z;
        float gyro_x;
        float gyro_y;
        float gyro_z;
    } __attribute__((packed));

    struct log2 {
        float mag_x;
        float mag_y;
        float mag_z;
        float baro_temp;
        float baro_pressure;
        float pm_vbat;
    } __attribute__((packed));

    std::unique_ptr<LogBlock<logImu> > logBlockImu;
    std::unique_ptr<LogBlock<log2> > logBlock2;
    std::vector<std::unique_ptr<LogBlockGeneric>> logBlocksGeneric;

    template<class T, class U>
    void update_param(uint8_t id, const std::string& ros_param);

    /* Log call backs */
    void onImuData(uint32_t time_in_ms, logImu* data);
    void onLog2Data(uint32_t time_in_ms, log2* data);
    void onLogCustom(uint32_t time_in_ms, std::vector<double>* values, std::string topic_name, void* userData);
    void onEmptyAck(const crtpPlatformRSSIAck* data);
    void onLinkQuality(float linkQuality);

    /*  */
    void writeLogData(std::string name, crazyflie_comm::GenericLogData data);
};

#endif //PROJECT_CRAZYFLIE_ROS_H
