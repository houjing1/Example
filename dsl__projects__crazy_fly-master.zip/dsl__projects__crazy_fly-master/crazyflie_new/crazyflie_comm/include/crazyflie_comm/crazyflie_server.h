/*
 * crazyflie_server.h
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_CRAZYFLIE_SERVER_H
#define PROJECT_CRAZYFLIE_SERVER_H

#include <future>
#include <map>
#include <thread>
#include <vector>
#include <mutex>
#include <condition_variable>

#include "ros/ros.h"
#include "crazyflie_cpp/crtp.h"
#include "crazyflie_comm/crazyflie_group.h"
#include "crazyflie_comm/cmd_packet_type.h"

#include "crazyflie_central/Cmd.h"
#include "crazyflie_estimator/FullState.h"
#include "crazyflie_estimator/SwarmStates.h"
#include "crazyflie_comm/GenericLogData.h"
#include "crazyflie_comm/LogBlock.h"
#include "crazyflie_comm/SwarmLogs.h"

static std::mutex g_bc_mutex;
static std::condition_variable g_cv;
static int g_vicon_msg_count;

class CrazyflieServer{
public:
    CrazyflieServer(ros::NodeHandle* nh):
            _nh(nh),
            stop_signal_fast(false),
            stop_signal_slow(false) {g_vicon_msg_count=0;};

    bool stop_signal_fast;
    bool stop_signal_slow;
    /* Update _curr_setpoints with the latest data
     * Only drones assigned to a control group would need new data to be broadcasted
     *
     *      args:
     *          cmds: a map from drone_ID to cmd
     *
     */
    void update_cmds(std::map<int, crazyflie_central::Cmd>& cmds);

    /* Update _curr_states with the latest data
     * Only drones assigned to a control group would need new data to be broadcasted
     *
     *      args:
     *          cmds: a map from drone_ID to cmd
     *
     */
    void update_states(const crazyflie_estimator::SwarmStates msg);
    /* Main loop that
     *      1) command CrazyflieGroup to broadcast in parallel
     *      2) trigger slow timer for CrazyflieGroup::run_slow()
     */
    void run();

    /* Slow loop that
     *      1) command CrazyflieGroup to log back onboard data
     */
    void run_slow();

    /* Ask each CrazyflieGroup to add CrazyflieROS by drone_ID
     *
     * If ID was added, we assume that this is a new drone and overwrite previous one's record.
     * Even if it is exactly the same drone, CrazyflieGroup would guard against this bad move since it will refuse
     * to add drone with the same radio_ID.
     */
    void add_crazyflie(std::vector<int> drone_ID);

    /* Init
     */
    void init();

    /* Try waking up crazyflies and setup log and params
     */
    void wakeup_drones(std::vector<int> drone_ID, std::vector<crazyflie_comm::LogBlock> logdata_info);

    /* Try waking up crazyflies for specific controllers
     */
    void wakeup_drones(std::vector<std::string> controllers_name);


private:
    int _drone_num;                                         // the total number of drones
    float _drone_mass;                                      // mass of the drones
    ros::NodeHandle* _nh;
    ros::Subscriber _sub_states;                            // subscriber of states
    std::map<std::string, ros::Publisher> _log_pubs;        // publishers of log data

    std::map<int, CrazyflieGroup*> _groups;                 // a map from channel to CrazyflieGroup*
    std::vector<int> _channels;                             // channel of each drone
    std::vector<std::string> _radio_IDs;                    // radio ID of each drone
    std::vector<uint8_t> _pck_IDs;                          // crtp radio packets ID for each drone
    std::vector<setpointBringup> _curr_setpoints;           // current setpoint for all drones
    std::vector<stateExternalBringup> _curr_states;         // current states for all drones
    std::vector<bool> _connected;                           // connection indicator

    PerfCounterBase* _perf_vicon;                             /**< Performance monitor: track the interval between two consequtive topics */

    /* Update _radio_IDs, inital position params
     *
     */
    void _update_param();

    /* Normalize commands came from Safepilot in order to fit radio packet based on command's CommandGroup type
     *
     *          args:
     *                  cmds: commands for drones from safepilot (Could be of AltHold or PosSet Type)
     *                  packet: a single struct to store values for radio packets
     *                  CommandGroupName: the name of CommandGroup enum as defined in crazyflie_central/automaton.h
     *
     *          NOTE:
     *                  Command of different type needs to be packed differently to fit the radio package size
     *                  e.g. If we were to send thrust, we need different normalization factor than sending position
     *                  for instance.
     */
    void _pack_cmd(const std::vector<float>& cmds, setpointBringup& packet, std::string CommandGroupName);

};

#endif //PROJECT_CRAZYFLIE_SERVER_H
