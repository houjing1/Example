/*
 * crazyflie_group.h
 *
 *  Created On : Mar 30, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_CMD_PACKET_TYPE_H
#define PROJECT_CMD_PACKET_TYPE_H

#include <map>

#include "crazyflie_central/status_group_struct.h"

std::map<std::string, uint8_t> CmdPacketTypeMap {{CommandGroupName[PosSet], 7}, {CommandGroupName[AltHold], 8}};

#endif //PROJECT_CMD_PACKET_TYPE_H
