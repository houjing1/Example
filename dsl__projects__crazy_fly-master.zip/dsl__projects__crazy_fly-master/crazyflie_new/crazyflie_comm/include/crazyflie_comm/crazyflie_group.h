/*
 * crazyflie_group.h
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_CRAZYFLIE_GROUP_H
#define PROJECT_CRAZYFLIE_GROUP_H

#include <vector>
#include <shared_mutex>

#include "ros/callback_queue.h"
#include "crazyflie_cpp/Crazyflie.h"
#include "crazyflie_comm/crazyflie_info.h"
#include "crazyflie_comm/crazyflie_ros.h"
#include "crazyflie_utility/perf_monitor.h"

#include "crazyflie_comm/GenericLogData.h"
#include "crazyflie_logger/DebugArray.h"

static std::shared_timed_mutex g_statesExt_mutex;
static std::shared_timed_mutex g_setpoints_mutex;


class CrazyflieGroup{
public:
    CrazyflieGroup(int radio, int channel,
                   std::vector<setpointBringup>* const setpoints_pool,
                   std::vector<stateExternalBringup>* const states_pool):
            _cfs(),
            _cfbc("radio://" + std::to_string(radio) + "/" + std::to_string(channel) + "/2M/FFE7E7E7E7"),
            _setpoints_pool(setpoints_pool),
            _states_pool(states_pool),
            _channel(channel),
            _radio(radio),
            logdata(),
            _pf_interval{PerfMonitor::addPerf(Interval, "CFGroup" + std::to_string(channel) + "_bc")},
            _pf_elapsed{PerfMonitor::addPerf(Elapsed, "CFGroup" + std::to_string(channel) + "_log")} {
        _pub_ref = nh.advertise<crazyflie_logger::DebugArray>("debug_array", 30);
    };

    ~CrazyflieGroup()
    {
        for(auto cf : _cfs) {
            delete cf;
        }
    };

    std::map<std::string, std::vector<crazyflie_comm::GenericLogData>> logdata;
                                                            // log container for all CrazyflieROS member

    /* Fast loop for broadcast
     */
    void run_fast();
    /* Slow loop for logging
     */
    void run_slow();

    /* Create and add CrazyflieRos to _cfs
     *
     * Create new CrazyflieROS iff drones have different radio_ID than previous ones
     * Overwrite previous CrazyflieROS if drones have the same drone_ID but different radio_ID
     *      args:
     *          states_pool : states for all drones in CrazyflieServer (indexed by drone_ID)
     *          cmds_pool   : cmds for all drones in CrazyflieServer (indexed by drone_ID)
     */
    void add_drones(std::vector<CrazyflieInfo>& info,
                      std::vector<bool>* res);
    /* Wake up drones and register logblocks on board and update necessary params for flight
     * Should only be called by CrazyflieServer
     *      args:
     *          drone_IDs : ID of drones to be connected
     */
    void wakeup_drones(std::vector<int> drone_IDs,
                         std::vector<crazyflie_comm::LogBlock>& logdata_info,
                         std::vector<bool>* conn_res);
    /* Update onboard parameters.
     *
     *      args:
     *          params: map from drone ID to a map from param name to desired value
     *                  param name's format "group/name"
     *
     */
    bool update_params(std::map<int, std::map<std::string, float>> &params);
//    bool reconnect(std::string uri, std::string frame_id);
//    CrazyflieROS* getCrazyflie(std::string uri);
//    void removeCrazyflie(std::string uri);
//    void emergency();


private:
    int _channel;                                      // radio channel the group is on
    int _radio;                                        // radio device ID
    CrazyflieBroadcaster _cfbc;                        // low-level comm class that supports broadcast feature

    std::vector<CrazyflieROS*> _cfs;                   // CrazyflieRos ordered by the time at which it's added
    std::map<int, int> _index_map;                     // a map from drone_ID to index used by CrazyflieGroup
                                                        // to access cf related members (e.g. _cfs_info, _states...)
    std::vector<CrazyflieInfo> _cfs_info;              // Crazfylie's info
    std::vector<bool> _isEmergency;                    // emergency indicator
    std::vector<bool> _resetEKF;                       // EKF reset indicator
    std::vector<bool> _awake;                          // true if cf is not in sleep
    std::vector<stateExternalBringup*> _states;        // address of state data for each drone
    std::vector<setpointBringup*> _setpoints;          // address of setpoint data for each drone

    std::vector<stateExternalBringup>* _states_pool;   // states container at CrazyflieServer
    std::vector<setpointBringup>* _setpoints_pool;     // setpoints container at CrazyflieServer

    ros::CallbackQueue _slowQueue;                     // for group callback
    ros::CallbackQueue _slowestQueue;                  // for cf callback

    ros::NodeHandle nh;
    ros::Publisher _pub_ref;

    PerfCounterBase* _pf_interval;                      // monitor broadcast frequency
    PerfCounterBase* _pf_elapsed;                       // monitor log time

    /* Helper function: search CrazyflieROS by radio_ID
     *
     *      args: index of target CrazyflieROS if found
     *
     *      return: true iff target CF is found
     *
     */
    bool _search_cf(std::string radio_ID, int* index);

};

#endif //PROJECT_CRAZYFLIE_GROUP_H
