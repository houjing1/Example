/*
 * crazyflie_info.h
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_CRAZYFLIE_INFO_H
#define PROJECT_CRAZYFLIE_INFO_H

#include <string>

struct CrazyflieInfo{
    std::string radio_ID;
    int drone_ID;
};

#endif //PROJECT_CRAZYFLIE_INFO_H
