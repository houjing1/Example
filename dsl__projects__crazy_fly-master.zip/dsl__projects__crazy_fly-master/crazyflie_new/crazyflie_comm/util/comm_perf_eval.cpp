/*
 * comm_perf_eval.cpp
 *
 *  Created On : Mar 20, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

/* Evaluate CrazyflieServer broadcast and log efficiency
 *      metrics:
 *              communication packet loss = Packets Received / Packets sent
 *              ground station broadcast frequency (Hz)
 *              onboard received frequency (Hz)
 *              average log time (s/packet)
 */

#include "ros/ros.h"

#include "crazyflie_comm/crazyflie_server.h"
// For all vehicles, [counts, avg, max, min]
static std::vector<std::array<float, 5>> g_bc_stats_p;
static std::vector<std::array<float, 5>> g_bc_stats_c;

void cb_log_counts(const crazyflie_comm::SwarmLogs msg){
    for(std::vector<crazyflie_comm::GenericLogData>::const_iterator it=msg.logdata.begin(); it!=msg.logdata.end(); ++it){
        int length = it->header.frame_id.size();
        int id = atoi(it->header.frame_id.substr(5, length - 5).c_str());

        g_bc_stats_p.at(id)[0] = it->values[0];
        g_bc_stats_c.at(id)[0] = it->values[1];
    }
}

void cb_log_avg(const crazyflie_comm::SwarmLogs msg){
    for(std::vector<crazyflie_comm::GenericLogData>::const_iterator it=msg.logdata.begin(); it!=msg.logdata.end(); ++it){
        int length = it->header.frame_id.size();
        int id = atoi(it->header.frame_id.substr(5, length - 5).c_str());

        g_bc_stats_p.at(id)[1] = it->values[0];
        g_bc_stats_c.at(id)[1] = it->values[1];
    }
}

void cb_log_max(const crazyflie_comm::SwarmLogs msg){
    for(std::vector<crazyflie_comm::GenericLogData>::const_iterator it=msg.logdata.begin(); it!=msg.logdata.end(); ++it){
        int length = it->header.frame_id.size();
        int id = atoi(it->header.frame_id.substr(5, length - 5).c_str());

        g_bc_stats_p.at(id)[2] = it->values[0];
        g_bc_stats_c.at(id)[2] = it->values[1];
    }
}

void cb_log_min(const crazyflie_comm::SwarmLogs msg){
    for(std::vector<crazyflie_comm::GenericLogData>::const_iterator it=msg.logdata.begin(); it!=msg.logdata.end(); ++it){
        int length = it->header.frame_id.size();
        int id = atoi(it->header.frame_id.substr(5, length - 5).c_str());

        g_bc_stats_p.at(id)[3] = it->values[0];
        g_bc_stats_c.at(id)[3] = it->values[1];
    }
}

void cb_log_std(const crazyflie_comm::SwarmLogs msg){
    for(std::vector<crazyflie_comm::GenericLogData>::const_iterator it=msg.logdata.begin(); it!=msg.logdata.end(); ++it){
        int length = it->header.frame_id.size();
        int id = atoi(it->header.frame_id.substr(5, length - 5).c_str());

        g_bc_stats_p.at(id)[4] = it->values[0];
        g_bc_stats_c.at(id)[4] = it->values[1];
    }
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "comm_perf_eval");
    ros::NodeHandle n;

    // initialize CrazyflieServer
    CrazyflieServer server(&n);
    server.init();

    int drone_num;
    n.getParam("vehicles/num", drone_num);

    std::vector<std::string> radio_IDs;
    n.getParam("vehicles/uri", radio_IDs);

    radio_IDs.erase(radio_IDs.begin() + drone_num, radio_IDs.end());

    // prepare dummy states and cmds
    std::map<int, crazyflie_central::Cmd> cmds;
    crazyflie_estimator::SwarmStates states;

    crazyflie_central::Cmd cmd_temp{};
    cmd_temp.type = "PosSet";
    cmd_temp.values.push_back(0.0f);
    cmd_temp.values.push_back(0.0f);
    cmd_temp.values.push_back(0.0f);
    cmd_temp.values.push_back(0.0f);

    crazyflie_estimator::FullState states_temp{};
    states_temp.pos[0] = 1.0f;
    states_temp.pos[1] = 2.0f;
    states_temp.pos[2] = 3.0f;

    for(int i=0; i<drone_num; i++){
        cmds[i] = cmd_temp;
        states.fullstate.push_back(states_temp);
    }

    // Get prepared to wake up drones
    std::vector<int> drone_IDs;
    std::vector<crazyflie_comm::LogBlock> logdata_info;

    for(int i=0; i<drone_num; ++i){
        drone_IDs.push_back(i);
    }

    // register log blocks
    // P stands for position external bringup (i.e. states)
    // C stands for commands (i.e. setpoints)
    crazyflie_comm::LogBlock log;
    log.frequency = 10;
    log.topic_name = "counts_packets_rx";
    log.variables = {"broadcast_test.RP", "broadcast_test.RC"};
    logdata_info.push_back(log);
    ros::Subscriber sub_log_counts = n.subscribe("log/"+log.topic_name, 10, cb_log_counts);
//
//    log.frequency = 5;
//    log.topic_name = "avg_pck_rx_freq";
//    log.variables = {"broadcast_test.aRFP","broadcast_test.aRFC"};
//    logdata_info.push_back(log);
//    ros::Subscriber sub_log_avg = n.subscribe("log/"+log.topic_name, 10, cb_log_avg);
//
//
    log.frequency = 5;
    log.topic_name = "max_pck_rx_freq";
    log.variables = {"broadcast_test.mxRFP","broadcast_test.mxRFC"};
    logdata_info.push_back(log);
    ros::Subscriber sub_log_max = n.subscribe("log/"+log.topic_name, 10, cb_log_max);

//    log.frequency = 5;
//    log.topic_name = "min_pck_rx_freq";
//    log.variables = {"broadcast_test.mnRFP","broadcast_test.mnRFC"};
//    logdata_info.push_back(log);
//    ros::Subscriber sub_log_min = n.subscribe("log/"+log.topic_name, 10, cb_log_min);
//
//    log.frequency = 5;
//    log.topic_name = "std_pck_rx_freq";
//    log.variables = {"broadcast_test.sRFP","broadcast_test.sRFC"};
//    logdata_info.push_back(log);
//    ros::Subscriber sub_log_std = n.subscribe("log/"+log.topic_name, 10, cb_log_std);

    server.wakeup_drones(drone_IDs, logdata_info);

    // Fake Safepilot
    std::array<float, 5> stats_temp{0};
    g_bc_stats_p.assign(drone_num, stats_temp);
    g_bc_stats_c.assign(drone_num, stats_temp);


    std::cout << "------ Start Test (10s) ------"<< std::endl;
    ros::Rate r(0.1);
    std::thread  thread_server = std::thread{&CrazyflieServer::run, &server};
    server.update_cmds(cmds);
    server.update_states(static_cast<crazyflie_estimator::SwarmStates>(states));
    ros::spinOnce();

    r.sleep();
    // stop sending cmds
    server.stop_signal_fast = true;

    // wait for onboard log data to be sent back
    std::cout << "------ Test Finished. Wait for log data (15s) ------"<< std::endl;
    sleep(15);

    // collect and print results
    ros::spinOnce();
    std::cout << "--------------------------------------" << std::endl;
    std::cout << "----------   Offboard Stats   --------" << std::endl;
    std::cout << "--------------------------------------" << std::endl;
    PerfMonitor::printInfo();


    std::cout << "--------------------------------------" << std::endl;
    std::cout << "----------   Onboard Stats   --------" << std::endl;
    std::cout << "--------------------------------------" << std::endl;
    std::cout << "Drone_ID" << ' ' << "Type" << ' ' << "Events Count" <<' ';
    std::cout << "Average" << ' ' << "Max" << ' ' << "Min" << std::endl;
    std::cout << "--------------------------------------" << std::endl;
    for(int i=0; i<drone_num; ++i){
        std::cout << i << ' ' << "pos" << ' ';
        for(int j=0; j<5; ++j)
            std::cout << g_bc_stats_p[i][j] << ' ';
        std::cout<<"\n";
    }

    for(int i=0; i<drone_num; ++i){
        std::cout << i << ' ' << "cmd" << ' ';
        for(int j=0; j<5; ++j)
            std::cout << g_bc_stats_c[i][j] << ' ';
        std::cout<<'\n';
    }

    ros::spin();
    thread_server.join();

}