/*
 * test.cpp
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */
#include "crazyflie_comm/crazyflie_server.h"


int main(int argc, char **argv) {
    ros::init(argc, argv, "comm_test");
    ros::NodeHandle n;

    CrazyflieServer server(&n);
    server.init();

    server.run();

    return 0;

}