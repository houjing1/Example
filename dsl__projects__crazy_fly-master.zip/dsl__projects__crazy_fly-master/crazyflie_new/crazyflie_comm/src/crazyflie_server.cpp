/*
 * crazyflie_server.cpp
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "crazyflie_comm/crazyflie_server.h"

void CrazyflieServer::init(){
    ROS_INFO("Initializing CrazyflieServer");
    _sub_states = _nh->subscribe("full_state", 1, &CrazyflieServer::update_states, this);

    _update_param();

    std::vector<int> drone_ID;
    for(int i=0; i<_drone_num; ++i)
        drone_ID.push_back(i);
    _channels.assign(_drone_num, 0);
    _pck_IDs.assign(_drone_num, (uint8_t) 0);

    setpointBringup empty_setpoint{};
    _curr_setpoints.assign(_drone_num, empty_setpoint);

    stateExternalBringup empty_state{};
    _curr_states.assign(_drone_num, empty_state);
    add_crazyflie(drone_ID);

    _perf_vicon = PerfMonitor::addPerf(Interval, "CommProt_Est_RX");
}

void CrazyflieServer::update_cmds(std::map<int, crazyflie_central::Cmd>& cmds){
    std::map<int, crazyflie_central::Cmd>::iterator it_cmds;
    int id_temp;
    std::vector<float> values;

    g_setpoints_mutex.lock();
    for(it_cmds=cmds.begin(); it_cmds!=cmds.end(); ++it_cmds){
        id_temp = it_cmds->first;
        values = it_cmds->second.values;
        _curr_setpoints.at(id_temp).id = _pck_IDs.at(id_temp);
        if(CmdPacketTypeMap.find(it_cmds->second.type) != CmdPacketTypeMap.end())
            _curr_setpoints.at(id_temp).type = CmdPacketTypeMap.at(it_cmds->second.type);
        else{
            ROS_WARN_STREAM("[Crazyflie Server]: Invalid command type " << it_cmds->second.type << " for Drone" << id_temp+1);
            continue;
        }

        _pack_cmd(values, _curr_setpoints.at(id_temp), it_cmds->second.type);
        values.clear();
    }
    g_setpoints_mutex.unlock();

}

void CrazyflieServer::update_states(const crazyflie_estimator::SwarmStates msg){
    _perf_vicon->count();
    int drone_num = msg.fullstate.size();
    std::vector<stateExternalBringup> new_states;

    if(drone_num != _drone_num){
        ROS_WARN_STREAM("CrazyflieServer: full_state estimate is ignored. It doesn't have info for all drones");
        return;
    }else{
        for(int i=0; i<drone_num; ++i){
            stateExternalBringup temp{};
            temp.id = _pck_IDs[i];
            temp.x = msg.fullstate[i].pos[0];
            temp.y = msg.fullstate[i].pos[1];
            temp.z = msg.fullstate[i].pos[2];

            new_states.push_back(temp);
        }
    }
    g_statesExt_mutex.lock();
    _curr_states = new_states;
    g_statesExt_mutex.unlock();

    std::lock_guard<std::mutex> lk(g_bc_mutex);
    g_vicon_msg_count = (g_vicon_msg_count + 1);
    g_cv.notify_one();
//    ROS_INFO_STREAM("update_states");

}

void CrazyflieServer::run(){
    ros::Rate r(200);

//    std::thread thread_slow{&CrazyflieServer::run_slow, this};

    std::vector<std::future<void>> handles;

    while(ros::ok() && !stop_signal_fast){

        {
            std::unique_lock<std::mutex> lk(g_bc_mutex);

            g_cv.wait(lk, [] { return g_vicon_msg_count > 1; });
            if(g_vicon_msg_count > 2)
                ROS_WARN_STREAM("[Crazyflie Server]: BC can not keep up the speed");
            g_vicon_msg_count = 0;
        }
        auto startIteration = std::chrono::high_resolution_clock::now();
//        ROS_INFO_STREAM("bc" << g_vicon_msg_count);
        for(std::map<int, CrazyflieGroup*>::iterator it=_groups.begin(); it!=_groups.end(); ++it){
            auto handle = std::async(std::launch::async, &CrazyflieGroup::run_fast, it->second);
            handles.push_back(std::move(handle));
        }

        for(auto& handle : handles)
            handle.wait();

        auto endIteration = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = endIteration - startIteration;
        double elapsedSeconds = elapsed.count();
        if (elapsedSeconds > 0.009) {
            ROS_WARN("Latency too high! Is %f s.", elapsedSeconds);
        }
//        r.sleep();
        handles.clear();

    }
//    if(thread_slow.joinable())
//        thread_slow.join();
}

void CrazyflieServer::run_slow(){
    ros::Rate r(20);
    std::vector<std::future<void>> handles;

    while(ros::ok() && !stop_signal_slow){
        // Get log data
        for(std::map<int, CrazyflieGroup*>::iterator it=_groups.begin(); it!=_groups.end(); ++it){
            auto handle = std::async(std::launch::async, &CrazyflieGroup::run_slow, it->second);
            handles.push_back(std::move(handle));
        }

        for (auto& handle : handles) {
            handle.wait();
        }

        // get logdata from CrazyflieGroup
        std::map<std::string, crazyflie_comm::SwarmLogs> log_msgs;
        for(std::map<int, CrazyflieGroup*>::iterator it=_groups.begin(); it!=_groups.end(); ++it){
            std::map<std::string, std::vector<crazyflie_comm::GenericLogData>>::iterator itb =it->second->logdata.begin();

            for(itb; itb!=it->second->logdata.end(); ++itb){
                log_msgs[itb->first].logdata.insert(log_msgs[itb->first].logdata.end(), itb->second.begin(), itb->second.end());
                itb->second.clear();
            }
        }

        // publish log by logblock
        for(std::map<std::string, crazyflie_comm::SwarmLogs>::iterator it=log_msgs.begin(); it!=log_msgs.end(); ++it){
            if(it->second.logdata.size() > 0){
                it->second.header.stamp = ros::Time::now();
                if(_log_pubs.find(it->first)==_log_pubs.end()){
                    _log_pubs[it->first] = _nh->advertise<crazyflie_comm::SwarmLogs>("log/"+it->first, 2);
                }
                _log_pubs[it->first].publish(it->second);
            }
        }


        r.sleep();
        handles.clear();
    }
}

void CrazyflieServer::add_crazyflie(std::vector<int> drone_ID) {
    // temprary variables
    int channel;                // radio channel
    uint8_t pck_id;             // radio packet id
    uint64_t rID_temp;          // radio id
    bool success;
    CrazyflieInfo info_temp;
    std::map <int, std::vector<CrazyflieInfo>> info_map;

    // collect crazyflie info
    for(std::vector<int>::iterator it=drone_ID.begin(); it!=drone_ID.end(); ++it){
        std::string radio_ID = _radio_IDs[*it];
        success = std::sscanf(radio_ID.c_str(), "%lx", &rID_temp);
        if(success){
            channel = ((rID_temp & 0xF00) >> 8) * 10;
            pck_id = rID_temp & 0xFF;
            // allow overwrite
            _channels[*it] = channel;
            _pck_IDs[*it] = pck_id;

            // add CrazyflieGroup if not exists
            if(_groups.find(channel) == _groups.end()){
                _groups[channel] = new CrazyflieGroup(_groups.size(), channel, &_curr_setpoints,
                                                                               &_curr_states);
                ROS_INFO_STREAM("New crazyflie group at channel " << channel);
            }


            // prepare crazyflie info
            // TODO: read from ros params
            info_temp.radio_ID = radio_ID;
            info_temp.drone_ID = *it;

            info_map[channel].push_back(info_temp);
        }
        else{
            ROS_WARN_STREAM("radio ID " << radio_ID << " invalid");
        }
    }

    // add crazyflie to each radio group
    std::map<int, std::vector<CrazyflieInfo>>::iterator it;
    std::map<int, std::vector<bool>> res_map;
    for(it=info_map.begin(); it!=info_map.end(); ++it){
        _groups[it->first]->add_drones(info_map[it->first], &res_map[it->first]);
    }
}

void CrazyflieServer::wakeup_drones(std::vector<int> drone_ID, std::vector<crazyflie_comm::LogBlock> logdata_info) {
    std::map<int, std::vector<int>> ID_map;
    std::map<int, std::vector<bool>> wakeup_rest_map;

    for(std::vector<int>::iterator it=drone_ID.begin(); it!=drone_ID.end(); ++it)
        ID_map[_channels[*it]].push_back(*it);

    for(std::map<int, std::vector<int>>::iterator it=ID_map.begin(); it!=ID_map.end(); ++it)
        _groups[it->first]->wakeup_drones(it->second, logdata_info, &wakeup_rest_map[it->first]);

}


void CrazyflieServer::wakeup_drones(std::vector<std::string> controllers_name) {
    XmlRpc::XmlRpcValue param;
    std::vector<crazyflie_comm::LogBlock> logdata_info;
    crazyflie_comm::LogBlock logblock_temp;
    std::map<int, std::vector<int>> dronesID_map;
    std::map<int, std::vector<bool>> ret_map;

    // wakeup drones by controller
    for(std::vector<std::string>::iterator it=controllers_name.begin(); it!=controllers_name.end(); ++it){
        _nh->getParam("controller/" + *it, param);
        // add log block
        if(param.hasMember("logdata_block")){
            for(XmlRpc::XmlRpcValue::iterator it_log=param["logdata_block"].begin(); it_log!=param["logdata_block"].end(); ++it_log){
                logblock_temp.topic_name = it_log->first;

                if(!it_log->second.hasMember("variables")){
                    ROS_WARN_STREAM("Please spcify variables for " << it_log->first << " in Controller " << *it);
                    continue;
                }

                if(!it_log->second.hasMember("log_freq")){
                    ROS_WARN_STREAM("Please spcify log_freq for " << it_log->first << " in Controller " << *it);
                    continue;
                }

                for(int i=0; i<it_log->second["variables"].size(); ++i)
                    logblock_temp.variables.push_back(it_log->second["variables"][i]);
                logblock_temp.frequency = (int) (it_log->second["log_freq"]);
                logdata_info.push_back(logblock_temp);
                logblock_temp.variables.clear();
            }
        }

        // wakeup crazyflies by group
        int drone_ID;
        for(int i=0; i< (int) param["drone_num"]; ++i){
            drone_ID = (int) param["drone_ID"][i] - 1;
            dronesID_map[_channels[drone_ID]].push_back(drone_ID);
        }

        for(std::map<int, std::vector<int>>::iterator it=dronesID_map.begin(); it!=dronesID_map.end(); ++it){
            _groups[it->first]->wakeup_drones(it->second, logdata_info, &ret_map[it->first]);
        }

        logdata_info.clear();
        dronesID_map.clear();
        ret_map.clear();
    }
}

void CrazyflieServer::_update_param(){
    _nh->getParam("vehicles/uri", _radio_IDs);

    _nh->getParam("vehicles/num", _drone_num);
    _nh->getParam("vehicles/mass", _drone_mass);

    _radio_IDs.erase(_radio_IDs.begin()+_drone_num, _radio_IDs.end());

}

void CrazyflieServer::_pack_cmd(const std::vector<float> &cmds, setpointBringup &packet,
                                std::string command_group_name) {
    if(command_group_name == CommandGroupName[PosSet]){
        packet.x = cmds[0];                          // x-pos(m)
        packet.y = cmds[1];                          // y-pos(m)
        packet.z = std::max<float>(cmds[2], 0.0f);   // z-pos(m)
        packet.yaw = cmds[3]/ 180.0f * 3.1415926f;  // yaw-angle(rad)
    }

    else if(command_group_name == CommandGroupName[AltHold]){
        packet.x = cmds[0];                                         // roll: rad
        packet.y = cmds[1];                                         // pitch: rad

        // transfer from thrust to pwm value
//        float pwm = -0.001227f * cmds[2] * cmds[2] + 0.0743f * cmds[2] + 0.0209f;
        float thrust = cmds[2] * _drone_mass;
        float pwm = -1.1264 * thrust * thrust+ 2.2541 * thrust + 0.0209f;
        packet.z = std::min(std::max<float>(pwm, 0.0f), 1.0f);      // pwm: %
        packet.yaw = cmds[3]/ 180.0f * 3.1415926f;                  // yaw: rads
    }
}
