/*
 * crazyflie_ros.cpp
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "ros/callback_queue.h"
#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/Temperature.h"
#include "sensor_msgs/MagneticField.h"
#include "std_msgs/Float32.h"
#include "crazyflie_comm/crazyflie_ros.h"

constexpr double pi() { return 3.141592653589793238462643383279502884; }

double degToRad(double deg) {
    return deg / 180.0 * pi();
}

double radToDeg(double rad) {
    return rad * 180.0 / pi();
}


void CrazyflieROS::ping() {
    _cf.sendPing();
}

void CrazyflieROS::stop()
{
    _isEmergency = true;
}

void CrazyflieROS::reboot(){
    _cf.reboot();
}

void CrazyflieROS::sysoff() {
    _cf.sysoff();
}

void CrazyflieROS::syson(){
    _cf.syson();
}


void CrazyflieROS::preflight_prep(std::vector<crazyflie_comm::LogBlock>& logdata_info){
//    syson();
    if (_flags.enableParameters) {
        // get param
        for (auto iter = _cf.paramsBegin(); iter != _cf.paramsEnd(); ++iter) {
            auto entry = *iter;
            std::string paramName = entry.group + "/" + entry.name;
            switch (entry.type) {
                case Crazyflie::ParamTypeUint8:
                    _params[paramName] = _cf.getParam<uint8_t>(entry.id);
                    break;
                case Crazyflie::ParamTypeInt8:
                    _params[paramName] = _cf.getParam<int8_t>(entry.id);
                    break;
                case Crazyflie::ParamTypeUint16:
                    _params[paramName] = _cf.getParam<uint16_t>(entry.id);
                    break;
                case Crazyflie::ParamTypeInt16:
                    _params[paramName] = _cf.getParam<int16_t>(entry.id);
                    break;
                case Crazyflie::ParamTypeUint32:
                    _params[paramName] = (int)_cf.getParam<uint32_t>(entry.id);
                    break;
                case Crazyflie::ParamTypeInt32:
                    _params[paramName] = _cf.getParam<int32_t>(entry.id);
                    break;
                // TODO: consider to support float param
                case Crazyflie::ParamTypeFloat:
                    _params[paramName] = (int) _cf.getParam<float>(entry.id);
                    break;
            }
        }
    }


    if (_flags.enableLogging) {
//
//            std::function < void(const crtpPlatformRSSIAck*)> cb_ack = std::bind(&CrazyflieROS::onEmptyAck, this, std::placeholders::_1);
//            _cf.setEmptyAckCallback(cb_ack);

        if (_flags.enable_logging_imu) {
            std::function<void(uint32_t, logImu * )> cb = std::bind(&CrazyflieROS::onImuData, this,
                                                                    std::placeholders::_1, std::placeholders::_2);

            logBlockImu.reset(new LogBlock<logImu>(
                    &_cf, {
                            {"acc",  "x"},
                            {"acc",  "y"},
                            {"acc",  "z"},
                            {"gyro", "x"},
                            {"gyro", "y"},
                            {"gyro", "z"},
                    }, cb));
            logBlockImu->start(10); // 10Hz
        }

        if (_flags.enable_logging_temperature
            || _flags.enable_logging_magnetic_field
            || _flags.enable_logging_pressure
            || _flags.enable_logging_battery) {
            std::function<void(uint32_t, log2 *)> cb2 = std::bind(&CrazyflieROS::onLog2Data, this,
                                                                  std::placeholders::_1, std::placeholders::_2);

            logBlock2.reset(new LogBlock<log2>(
                    &_cf, {
                            {"mag",  "x"},
                            {"mag",  "y"},
                            {"mag",  "z"},
                            {"baro", "temp"},
                            {"baro", "pressure"},
                            {"pm",   "vbat"},
                    }, cb2));
            logBlock2->start(20); // 5Hz
        }

        // custom log blocks
        size_t i = 0;
        logBlocksGeneric.resize(logdata_info.size());
        for (auto &logBlock : logdata_info) {
            ROS_INFO_STREAM("Logging " << logBlock.topic_name);
            std::function<void(uint32_t, std::vector < double > *, std::string, void * userData)> cb =
                    std::bind(
                            &CrazyflieROS::onLogCustom,
                            this,
                            std::placeholders::_1,
                            std::placeholders::_2,
                            std::placeholders::_3,
                            std::placeholders::_4);

            logBlocksGeneric[i].reset(new LogBlockGeneric(&_cf,
                                                          logBlock.variables,
                                                          logBlock.topic_name,
                                                          (void *) nullptr,
                                                          cb));
            logBlocksGeneric[i]->start(100.f / (float) logBlock.frequency);
            ++i;
        }
    }
}

void CrazyflieROS::init()
{

    // _cf.reboot();
    _cf.logReset();

    ROS_INFO("[%s] Requesting logging variables...", _frame_id.c_str());
    _cf.requestLogToc();
    ROS_INFO("Requesting parameters for %s", _frame_id.c_str());
    _cf.requestParamToc();

    // TODO: check onboard sensor test
    std::function<void(float)> cb_lq = std::bind(&CrazyflieROS::onLinkQuality, this, std::placeholders::_1);
    _cf.setLinkQualityCallback(cb_lq);

    // Send 0 thrust initially for thrust-lock
    // ToDo: Move to broadcaster
        for (int i = 0; i < 100; ++i) {
            _cf.sendSetpoint(0, 0, 0, 0);
        }

//    sysoff();
//    syson();
}

bool CrazyflieROS::update_params(std::map<std::string, float> params)
{
    ROS_INFO("[%s] Update parameters", _frame_id.c_str());
    for (auto&& p : params) {
        std::string p_name = p.first;
        _params[p_name] = p.second;
        size_t pos = p_name.find("/");
        std::string group(p_name.begin(), p_name.begin() + pos);
        std::string name(p_name.begin() + pos + 1, p_name.end());
        auto entry = _cf.getParamTocEntry(group, name);
        if (entry)
        {
            switch (entry->type) {
                case Crazyflie::ParamTypeUint8:
                    update_param<uint8_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeInt8:
                    update_param<int8_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeUint16:
                    update_param<uint16_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeInt16:
                    update_param<int16_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeUint32:
                    update_param<uint32_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeInt32:
                    update_param<int32_t, int>(entry->id, p_name);
                    break;
                case Crazyflie::ParamTypeFloat:
                    update_param<float, float>(entry->id, p_name);
                    break;
            }
        }
        else {
            ROS_ERROR("Could not find param %s/%s", group.c_str(), name.c_str());
        }
    }
    return true;
}

template<class T, class U>
void CrazyflieROS::update_param(uint8_t id, const std::string& name) {
    U value = _params.at(name);
    _cf.setParam<T>(id, (T)value);
}


void CrazyflieROS::onImuData(uint32_t time_in_ms, logImu* data) {
    if (_flags.enable_logging_imu) {
        crazyflie_comm::GenericLogData msg;
        if (_flags.use_ros_time) {
            msg.header.stamp = ros::Time::now();
        } else {
            msg.header.stamp = ros::Time(time_in_ms / 1000.0);
        }
        msg.header.frame_id = _frame_id;

        // measured in deg/s; need to convert to rad/s
        msg.values.push_back(degToRad(data->gyro_x));
        msg.values.push_back(degToRad(data->gyro_y));
        msg.values.push_back(degToRad(data->gyro_z));

        // measured in mG; need to convert to m/s^2
        msg.values.push_back(data->acc_x * 9.81);
        msg.values.push_back(data->acc_y * 9.81);
        msg.values.push_back(data->acc_z * 9.81);

        writeLogData("imu", msg);

    }
}

void CrazyflieROS::onLog2Data(uint32_t time_in_ms, log2* data) {

    if (_flags.enable_logging_temperature) {
        crazyflie_comm::GenericLogData msg;

        if (_flags.use_ros_time) {
            msg.header.stamp = ros::Time::now();
        } else {
            msg.header.stamp = ros::Time(time_in_ms / 1000.0);
        }
        msg.header.frame_id = _frame_id;
        // measured in degC
        msg.values.push_back(data->baro_temp);
        writeLogData("temp", msg);
    }

    if (_flags.enable_logging_magnetic_field) {
        crazyflie_comm::GenericLogData msg;
        if (_flags.use_ros_time) {
            msg.header.stamp = ros::Time::now();
        } else {
            msg.header.stamp = ros::Time(time_in_ms / 1000.0);
        }
        msg.header.frame_id = _frame_id;

        // measured in Tesla
        msg.values.push_back(data->mag_x);
        msg.values.push_back(data->mag_y);
        msg.values.push_back(data->mag_z);

        writeLogData("mag", msg);
    }

    if (_flags.enable_logging_pressure) {
        crazyflie_comm::GenericLogData msg;
        if (_flags.use_ros_time) {
            msg.header.stamp = ros::Time::now();
        } else {
            msg.header.stamp = ros::Time(time_in_ms / 1000.0);
        }

        // hPa (=mbar)
        msg.values.push_back(data->baro_pressure);

        writeLogData("pressure", msg);
    }

    if (_flags.enable_logging_battery) {
        crazyflie_comm::GenericLogData msg;
        if (_flags.use_ros_time) {
            msg.header.stamp = ros::Time::now();
        } else {
            msg.header.stamp = ros::Time(time_in_ms / 1000.0);
        }

        msg.header.frame_id = _frame_id;
        // V
        msg.values.push_back(data->pm_vbat);

        writeLogData("battery", msg);
    }
}

void CrazyflieROS::onLogCustom(uint32_t time_in_ms, std::vector<double>* values,
                               std::string topic_name, void* userData) {

    crazyflie_comm::GenericLogData msg;
    if (_flags.use_ros_time) {
        msg.header.stamp = ros::Time::now();
    } else {
        msg.header.stamp = ros::Time(time_in_ms / 1000.0);
    }
    msg.header.frame_id = _frame_id;
    msg.values = *values;
    if(!topic_name.compare("counts_packets_rx")){
        ROS_INFO_STREAM(_frame_id <<' '<< msg.values[0]<<' '<< msg.values[1]);
    }

    writeLogData(topic_name, msg);
}

void CrazyflieROS::onEmptyAck(const crtpPlatformRSSIAck* data) {
    std_msgs::Float32 msg;
    // dB
    msg.data = data->rssi;
}

void CrazyflieROS::onLinkQuality(float linkQuality) {
    if (linkQuality < 0.7) {
        //ROS_WARN("Link Quality low (%f)", linkQuality);
    }
}

void CrazyflieROS::writeLogData(std::string name, crazyflie_comm::GenericLogData data){
    // write into logdata owned by crazyflie_server
    (*_logdata)[name].push_back(data);
}