/*
 * crazyflie_group.cpp
 *
 *  Created On : Mar 13, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "crazyflie_comm/crazyflie_group.h"

void CrazyflieGroup::add_drones(std::vector<CrazyflieInfo>& cfs_info,
                                  std::vector<bool>* res) {

    for(std::vector<CrazyflieInfo>::iterator it=cfs_info.begin(); it!=cfs_info.end(); ++it){
        CrazyflieROS* cf;
        CrazyflieInfo info = *it;
        int index;

        // Check if cf has been added
        if(_search_cf(info.radio_ID, &index)){
            res->push_back(false);
            ROS_WARN_STREAM("radio_ID " << info.radio_ID <<" has been added to group.");
            continue;
        }

        // Create CrazyflieROS
        std::string uri = "radio://" + std::to_string(_radio) + '/' + std::to_string(_channel) + "/2M/E7E7E7E" + info.radio_ID;
        try{
            cf = new CrazyflieROS(uri,
                                  "Drone" + std::to_string(info.drone_ID),
                                  &logdata);                                 // log data container
        }
        catch(std::runtime_error){
            std::string frame_id = "Drone" + std::to_string(info.drone_ID);
            delete cf;
            ROS_FATAL("Unable to create %s", frame_id.c_str());
            res->push_back(false);
            continue;
        }

        // Add CrazyflieROS
        // if drone_ID was not added
        if(_index_map.find(info.drone_ID) == _index_map.end()){
            _index_map[info.drone_ID] = _cfs.size();
            _cfs.push_back(cf);
            _cfs_info.push_back(info);
            _states.push_back(&_states_pool->at(info.drone_ID));          // the address from which to get state data
            _setpoints.push_back(&_setpoints_pool->at(info.drone_ID));    // the address from which to get setpoint data
            _isEmergency.push_back(false);
            _resetEKF.push_back(false);
            _awake.push_back(false);
            ROS_INFO_STREAM("Drone " << info.drone_ID+1 << " with radio ID " << info.radio_ID << " added to group " << _channel);

        }
        // if drone_ID was added, overwrite previous cf
        else{
            int index = _index_map[info.drone_ID];
            ROS_INFO_STREAM("Drone " << info.drone_ID+1 << " with radio ID " << _cfs_info[index].radio_ID << " removed from group " << _channel);
            _index_map[info.drone_ID] = index;
            delete _cfs[index];
            _cfs[index] = cf;
            _cfs_info[index] = info;
            _isEmergency[index] = false;
            _resetEKF[index] = false;
            _awake.push_back(false);
            ROS_INFO_STREAM("Drone " << info.drone_ID+1 << " with radio ID " << info.radio_ID << " added to group " << _channel);
        }

        // Get Log and Param TOC (Table of Content)
        // TODO: check onboard sensor test results and return true only when the test is passed
        cf->init();

        // Successfully connected to crazyflie
        // Assuming cf pass the onboard sensor test
        res->push_back(true);
    }
}

bool CrazyflieGroup::_search_cf(std::string radio_ID, int* index){
    int i = 0;

    for(std::vector<CrazyflieInfo>::iterator it=_cfs_info.begin(); it!=_cfs_info.end(); ++it){
        if(!it->radio_ID.compare(radio_ID)){
            *index = i;
            return true;
        }
        ++i;
    }

    return false;
}

void CrazyflieGroup::run_fast() {
    _pf_interval->count();
    std::vector<stateExternalBringup> states;
    std::vector<setpointBringup> setpoints;

    for(int i=0; i<_cfs.size(); ++i){
        g_setpoints_mutex.lock_shared();
        if(!_isEmergency[i] && _awake[i]){
            setpoints.push_back(*_setpoints[i]);
        }
        g_setpoints_mutex.unlock_shared();

        g_statesExt_mutex.lock_shared();
        if(_resetEKF[i] && _awake[i])
            states.push_back(*_states[i]);
        g_statesExt_mutex.unlock_shared();
    }

//    ROS_INFO_STREAM("group " <<_channel << " Sending" << states.size() << setpoints.size());
    crazyflie_logger::DebugArray log_state;

    crazyflie_logger::DebugLog log;
    log.name = "Drone" + std::to_string(1) + "_pos";
    log.stamp = ros::Time::now();
    log.values.push_back(_states[0]->x);
    log.values.push_back(_states[0]->y);
    log.values.push_back(_states[0]->z);

    log_state.log.push_back(log);

    _pub_ref.publish(log_state);

    _cfbc.sendPositionExternalBringup(states);
    _cfbc.sendSetpoint(setpoints);

}

void CrazyflieGroup::run_slow(){
    // Ping is a two way communication
    // Log will be sent back to ground station as an ack packet
    for(int i=0; i<_cfs.size(); ++i){
        if(_awake[i]){
            _pf_elapsed->begin();
            _cfs[i]->ping();
            _pf_elapsed->end();
        }
    }
};

void CrazyflieGroup::wakeup_drones(std::vector<int> drone_IDs, std::vector<crazyflie_comm::LogBlock>& logdata_info, std::vector<bool>* conn_res) {
    float mass=0.029;
    nh.getParam("vehicles/mass", mass);

    float ring_effect=0;
    nh.getParam("vehicles/ring_effect", ring_effect);

    for(std::vector<int>::iterator it=drone_IDs.begin(); it!=drone_IDs.end(); ++it){
        // TODO: only give CrazyflieROS finite time to try making connection
        ROS_INFO_STREAM("Waking up drone " << *it);
        _cfs[_index_map[*it]]->preflight_prep(logdata_info);
        conn_res->push_back(true);
        _cfs[_index_map[*it]]->update_params({{"kalman/resetEstimation", 1}, {"usdlog/start", 1}, {"ring/effect", ring_effect}, {"ctrlMel/mass", mass}});
        _awake[_index_map[*it]] = true;
        _resetEKF[_index_map[*it]] = true;
    }
}

bool CrazyflieGroup::update_params(std::map<int, std::map<std::string, float>> &params)
{
    bool ret = true;

    for(std::map<int, std::map<std::string, float>>::iterator it=params.begin(); it!=params.end(); ++it){
        bool result = _cfs[_index_map[it->first]]->update_params(it->second);
        ret &= result;
    }

    return ret;
}
