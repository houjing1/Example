/*
 * baseController.h
 *
 *  Created On : 23/07/18
 *      Author : Jingyuan Hou
 *      Email  : jingyuan.hou@mail.utoronto.ca
 */

#ifndef NEW_SIMULATOR_BASECONTROLLER_H
#define NEW_SIMULATOR_BASECONTROLLER_H

#include <Eigen/Dense>
#include <vector>

//! The BaseController class.
/*!
 * The BaseController class is a abstract class that provide a common interface for other user implemented controllers.
 * Eigen library is used to store and pass vectors and matrices as its Matrix object.
 */
class BaseController{

public:
    /** constructor & destructor **/

    //! Default constructor
    BaseController() = default;

    //! Default destructor
    virtual ~BaseController() = default;

    /** Accessor functions **/

    /*!
     * \brief retrieve output attribute
     *
     * Get the output private data member. Other derived classes will have access to this member function
     * \return the output signal
     */
    const Eigen::Vector3d& get_output() const {return output;}

    /** Utility functions **/

    /*!
     * \brief perform overall update
     *
     * Perform overall update on the controller and return output vector.
     * Input is a list of required input vectors to controller.
     * All derived classes have to override this function to perform their unique update
     *
     * \param input_list list of required input vectors to controller
     * \return the output signal
     */
    virtual const Eigen::Vector3d& update_overall(const std::vector<Eigen::VectorXd>& input_list) = 0;

    /*!
     * \brief rest controller
     *
     * Reset controller internal states.
     * All derived classes have to override this function to perform their unique reset option.
     */
    virtual void reset_controller() = 0;

protected:
    // all derived classes will have access to this member
    Eigen::Vector3d output = Eigen::Vector3d::Zero();       /*!< output from controller as 3 by 1 vector */

};

#endif //NEW_SIMULATOR_BASECONTROLLER_H
