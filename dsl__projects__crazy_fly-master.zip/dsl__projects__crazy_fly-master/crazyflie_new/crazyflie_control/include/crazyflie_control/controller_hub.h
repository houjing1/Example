/*
 * controller_hub.h
 *
 *  Created on : Feb 10, 2018
 *       Author: Xintong Du
 */

#ifndef PROJECT_CONTROLLER_HUB_H
#define PROJECT_CONTROLLER_HUB_H

#include <string>

#include "ros/ros.h"
#include "crazyflie_control/controller_base.h"

#include "crazyflie_control/ControllerHubStatus.h"

class ControllerHub{
public:
    /* Controller Hub: manage all custom controllers
     * */
    ControllerHub(ros::NodeHandle* nh);
    ~ControllerHub();
    /* Add controller to _controllers
     *
     * args:
     *          info: controller related info
     *          cmds_pool: destination to which the controller writes
     *          states_pool: src from which the controller reads
     *
     * */
    template<typename controllerClass, typename cmdType, typename stateType>
    int add_controller(ControllerInfo* info, cmdType* const cmds_pool, stateType* const states_pool);
    /* Start controller
     *
     * args:
     *          name: name of the controller
     * */
    int start_controller(std::string name);

    /* Stop controller
     *
     * args:
     *          name: name of the controller
     * */
    int stop_controller(std::string name);

    /* Pause controllerR
     *
     * args:
     *          name: name of the controller
     *
     * TODO: Find a reasonable way to pause a controller. Currently, it's the same as stop
     * */
    int pause_controller(std::string name);

    /* Report status of all member
     *
     * */
    void broadcast_status();
    /* Get controller info
     *
     *      arg: the name of the queried controller
     */
    ControllerInfo* query(std::string controller_name);

    /* Helper function: search for a particular controller
     *
     * */
    bool search_member(std::string name);

private:
    std::map<std::string, AbstractControllerBase*> _controllers;    /* controller container */
    ros::NodeHandle* _nh;
    ros::Publisher _pub_status;

};

template<typename controllerClass, typename cmdType, typename stateType>
int ControllerHub::add_controller(ControllerInfo* info, cmdType* const cmds_pool, stateType* const states_pool){
    std::vector<cmdType*> cmds_addr{};
    std::vector<stateType*> states_addr{};

    bool exist = search_member(info->name);
    if(exist){
        ROS_WARN("[Controller Hub]: Ignored. %s was already added.", info->name.c_str());
        return -1;
    }
    else{
        for(int i=0; i<info->drone_num;i++){
            unsigned int id = info->drone_ID[i];
            cmds_addr.push_back(&cmds_pool[id]);
            states_addr.push_back(&states_pool[id]);
        }
        assert(cmds_addr.size() == info->drone_num);
        assert(states_addr.size() == info->drone_num);
        _controllers[info->name] = new controllerClass(info, cmds_addr, states_addr, _nh);

        return 0;
    }
}

#endif //PROJECT_CONTROLLER_HUB_H
