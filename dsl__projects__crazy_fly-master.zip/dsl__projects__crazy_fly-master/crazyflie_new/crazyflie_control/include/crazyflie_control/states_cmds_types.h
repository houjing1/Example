/*
 * states_cmds_types.h
 *
 *  Created On : Feb 23, 2018
 *      Author : Xintong Du
 */

#ifndef PROJECT_STATES_CMDS_TYPES_H
#define PROJECT_STATES_CMDS_TYPES_H

#include "ros/ros.h"

struct PosSetCmd {
    PosSetCmd() : data{}, time_stamp() {};
    union{
        float data[4];
        struct {float x,        /* position x (m) */
                      y,        /* position y (m) */
                      z,        /* position z (m) */
                      yaw;      /* yaw angle  (rad) */
                };
    };
    ros::Time time_stamp;       /* time stamp */
};

struct AltHoldCmd{
    AltHoldCmd() : data{}, time_stamp() {};
    union{
        float data[4];
        struct {float roll,     /* roll angle     (rad)   */
                      pitch,    /* pitch angle    (rad)   */
                      thrust,     /* thrust         (m/s/s) */
                      yaw;      /* yaw angle      (rad)   */
                };
    };
    ros::Time time_stamp;       /* time stamp */
};

struct FullState{
    FullState() : data{}, time_stamp() {};
    union{
        float data[3][3];
        struct {float x,        /* position x     (m) */
                      y,        /* position y     (m) */
                      z,        /* position a     (m) */
                      vx,       /* velocity x     (m/s) */
                      vy,       /* velocity y     (m/s) */
                      vz,       /* velocity z     (m/s) */
                      ax,       /* acceleration x (m/s/s) */
                      ay,       /* acceleration y (m/s/s) */
                      az;       /* acceleration z (m/s/s) */
                };
    };
    ros::Time time_stamp;       /* time stamp */
};

#endif //PROJECT_STATES_CMDS_TYPES_H