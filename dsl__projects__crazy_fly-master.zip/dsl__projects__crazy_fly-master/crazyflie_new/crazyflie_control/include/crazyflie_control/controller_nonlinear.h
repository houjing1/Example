/*
 * controller_nonlinear.h
 *
 *  Created On : Apr 14, 2018
 *      Author : Xintong Du
 *
 *      cite: Mellinger (2011)
 */

#ifndef PROJECT_CONTROLLER_NONLINEAR_H
#define PROJECT_CONTROLLER_NONLINEAR_H

#include <cmath>
#include <Eigen/Dense>
#include <iostream>

#include "ros/ros.h"
#include "crazyflie_control/pid.hpp"

/** @class NonLinPosController
 *
 *  A nonlinear position controller based on (Mellinger, 2011).
 *
 *  \b Overview
 *
 *  This is an alternative position controller to the on-board cascaded pid position controller.
 *  It is based on (Mellinger, 2011) but includes integral term of position error in addition to P,D terms to compensate
 *  for system modeling error. Specifically, this controller takes in position reference @f$\mathbf{r_T}@f$, velocity
 *  reference @f$\mathbf{v_T}@f$, feed forward acceleration @f$\mathbf{a_{ff}}@f$, yaw reference @f$\psi@f$ and position
 *  estimation @f$\mathbf{r}@f$. It first computes desired normalized thrust vector@f$\mathbf{a}@f$. Then, the normalized thrust @f$\mathbf{a}@f$
 *  is converted to roll@f$\phi@f$, pitch@f$\theta@f$ and thrust scalar value @f$t@f$ based on differential flatness.
 *
 * @f$\mathbf{a}(t)= \mathbf{K_p} (\mathbf{r_T} - \mathbf{r})+ \mathbf{K_d} (\mathbf{v_T} - \mathbf{\dot{r}}) +
 * \mathbf{K_i} \int_{0}^{t} (\mathbf{r_T} - \mathbf{r})dt + \mathbf{a_{ff}} + \mathbf{g} @f$
 *
 *
 */

class NonLinPosController{
public:

    NonLinPosController(const std::vector<PIDParam>& param):
        _params(param) {
        _K <<_params[0].kp, _params[0].kd, _params[0].ki,
             _params[1].kp, _params[1].kd, _params[1].ki,
             _params[2].kp, _params[2].kd, _params[2].ki;

    };
    NonLinPosController() {};

    /** Update controller with new setpoint and measurement and compute next command.
     *
     *
     *   @param     dt: time interval (s)
     *   @param     pos_t: target position (m) @f$\mathbf{r_T} = [x,y,z] @f$
     *   @param     vel_t: target velocity (m/s) @f$\mathbf{v_T} = [v_x,v_y,v_z] @f$
     *   @param     yaw_t: target yaw angle (rad) @f$\psi@f$
     *   @param     acc_ff: acceleration feed forward (m/s/s) @f$\mathbf{a_{ff}} = \mathbf{\ddot{r_t}} + [0, 0, 9.8] @f$
     *   @param     pos_s: current position (m) @f$\mathbf{r} = [x,y,z] @f$
     *   @param     vel_s: current velocity (m/s)@f$\mathbf{\dot{r}} = [x,y,z] @f$
     *   @param     rpy:   control input roll, pitch, yaw (rad) @f$[\phi,\theta,\psi] @f$
     *   @param     thrust: control input thrust (m/s/s) @f$t = \sqrt{\mathbf{r_T}^{T}\mathbf{r_T}}@f$
     */
    void update(float dt, float const* pos_t, float const *vel_t, float const yaw_t, float const* acc_ff,
                float const* pos_s, float const* vel_s, float* const rpy, float* const thrust);
    /** Reset controller.
     *
     * Set integral to zero.
     *
     */
    void reset();

    /** Set controller parameters.
     *
     * @param param a vector of PIDParam for x,y,z direction
     */
    void setParams(const std::vector<PIDParam>& param){
        _params = param;
        _K <<_params[0].kp, _params[0].kd, _params[0].ki,
                _params[1].kp, _params[1].kd, _params[1].ki,
                _params[2].kp, _params[2].kd, _params[2].ki;
    };

private:
    std::vector<PIDParam> _params;      /**< Controller parameters. */
    Eigen::Array33f _K;                 /**< Gain matrix. @f$[\mathbf{Kp^T}, \mathbf{Kd^T}, \mathbf{Ki^T}]@f$*/
    Eigen::Array3f _i_err;              /**< Position Error inetgral. */

};


#endif //PROJECT_CONTROLLER_NONLINEAR_H
