/*
 * controller_example.h
 *
 *  Created On : Feb 10, 2018
 *      Author : Xintong Du
 */
#ifndef PROJECT_CONTROLLER_EXAMPLE_H
#define PROJECT_CONTROLLER_EXAMPLE_H

#include "crazyflie_control/controller_base.h"
#include "crazyflie_control/controller_nonlinear.h"
#include "crazyflie_logger/DebugArray.h"

/** @class CircleController
 *
 *  Circle trajectory.
 *
 *  \b Overview
 *
 *  This controller commands a group of equally spaced vehicles to traverse a circle. It computes time reference position
 *  setpoints and rely on on-board position controller to control position.
 *
 *  \b Usage
 *  -# Press start button on GUI to start the circle trajectory
 *  -# After controller finished and vehicles go back to Hover mode, you can press start for another round.
 *
 */
class CircleController : public ControllerBase<PosSetCmd, FullState>{
public:
    CircleController(ControllerInfo* info,
                     std::vector<PosSetCmd*> cmd_addr,
                     std::vector<FullState*> state_addr,
                     ros::NodeHandle* nh):
           ControllerBase<PosSetCmd, FullState>(info,
                                                cmd_addr,
                                                state_addr,
                                                nh),
           _omega(0.1),
           _r(3.0),
           _t(0),
           _round(2) { _load_parameters();};

    /** Compute next commands.
     *
     * @param cmds next commands
     * @param states current states
     * @return -1 if vehicles have finished #_round of circles; otherwize, 0.
     */
    int control(PosSetCmd* const cmds, FullState const *states);
private:
    float _omega;                /**< angular velocity of the circular trajectory */
    float _r;                    /**< radius of the circular trajectory*/
    float _t;                    /**< time elapsed */
    float _height;               /**< height of the cricle trajectory*/
    int _round;                  /**< the number of full circles */


    void _load_parameters();     /**< load ROS parameters */
};

/** @class CircleControllerNonlinear
 *
 *  Circle trajectory with nonlinear position controller.
 *
 *  \b Overview
 *
 *  Similar to CircleController, this planner also generates position trajectory for a group of vehicle equally spaced
 *  on a circle. Difference is that this planner use NonLinPosController to control position instead of the on-board
 *  position controller. Consequently, this controller allows vehicles to traverse the circle at higher
 *  angular velocity.
 *
 */
class CircleControllerNonlinear : public ControllerBase<AltHoldCmd, FullState>{
public:
    CircleControllerNonlinear(ControllerInfo* info,
                     std::vector<AltHoldCmd*> cmd_addr,
                     std::vector<FullState*> state_addr,
                     ros::NodeHandle* nh):
            ControllerBase<AltHoldCmd, FullState>(info,
                                                 cmd_addr,
                                                 state_addr,
                                                 nh),
            _omega(0.1),
            _r(3.0),
            _t(0),
            _round(2) { _load_parameters();
                        _pos_controller.setParams(_params); };
    /** Compute control inputs.
     *
     *      -# Generate vehicles' position setpoint for the next time step
     *      -# Feed setpoints into nonlinear controller and compute control inputs
     *
     * @param cmds array head pointer of AltHoldCmd cmds.
     * @param states array head pointer of FullState state estimates.
     * @return -1 if controller finished; otherwise, 0.
     */
    int control(AltHoldCmd* const cmds, FullState const *states);
private:
    float _omega;                           /**< angular velocity of the circular trajectory */
    float _r;                               /**< radius of the circular trajectory */
    float _t;                               /**< time elapsed */
    float _height;                          /**< height of circle trajectory */
    int _round;                             /**< the number of full circles */
    bool _use_vel;                          /**< flag for using @f$\mathbf{v_T} = \mathbf{\dot{r_T}}@f$
                                             *   as opposed to @f$\mathbf{v_T} = \mathbf{0}@f$  */
    bool _use_ff;                           /**< flag for using @f$\mathbf{a_{ff}} = \mathbf{\ddot{r_T}} + \mathbf{g}@f$
                                             *   as opposed to @f$\mathbf{a_{ff}} = \mathbf{g}@f$ */

    NonLinPosController _pos_controller;     /**< nonlinear position controller */
    std::vector<PIDParam> _params;          /**< nonlinear controller paramemters for x,y,z direction*/

    void _load_parameters();                /**< load ROS parameters */

};


class WaveController : public ControllerBase<AltHoldCmd, FullState>{
public:
    WaveController(ControllerInfo* info,
                  std::vector<AltHoldCmd*> cmd_addr,
                  std::vector<FullState*> state_addr,
                  ros::NodeHandle* nh):
            ControllerBase<AltHoldCmd, FullState>(info,
                                                  cmd_addr,
                                                  state_addr,
                                                  nh),
            _acc_ff(3,0),
            _rpy_t(3,0),
            _yaw_t(0),
            _step(0.0),
            _step_index(-1),
            _round(1),
            _locked_position(false),
            _stepped(false),
            _wave_ref_ID(0),
            _wave_speed(0.5)
    {
        // load ROS parameters
        _load_parameters();
        NonLinPosController controller_temp;
        std::vector<float> pos_temp{0,0,0};
        _controllers.assign(_drone_num, controller_temp);

        for(int i=0; i<_drone_num; ++i) {
            _controllers[i].setParams(_params);
            _vel_t.push_back(pos_temp);
            _init_pos.push_back(pos_temp);
        }

        _acc_ff[2] = 9.8f;
        _pub_ref = nh->advertise<crazyflie_logger::DebugArray>("debug_array", 5);
        _current_position = Eigen::Array3Xf::Zero(3,_drone_num);
    };

    /** Compute control inputs.
     *
     *  -# output the next step signal if controller was stopped and commanded to start again
     *  -# feed the current input signal to #_controller and compute next command
     *  -# map thrust @f$t@f$ to pwm value @f$ pwm = k_{t^2}*t^2 + k_t * t + k_c@f$
     *
     * @param cmds next commands
     * @param states current states
     * @return 0
     */

    int control(AltHoldCmd* const cmds, FullState const *states);
private:
    void _load_parameters();                /**< load ROS parameters */
    std::vector<PIDParam> _params;          /**< controller parameters x,y,z direction*/
    std::vector<std::vector<float>> _init_pos;
    std::vector<std::vector<float>> _pos_t; /**< target position (m) @f$\mathbf{r_T} = [x,y,z] @f$ */
    std::vector<std::vector<float>> _vel_t; /**< target velocity (m/s) @f$\mathbf{v_T} = [v_x,v_y,v_z] @f$*/
    std::vector<float> _acc_ff;             /**< acceleration feed forward (m/s/s) @f$\mathbf{a_{ff}} = \mathbf{\ddot{r_t}} + [0, 0, 9.8] @f$*/
    std::vector<float> _rpy_t;              /**< control input roll, pitch, yaw (rad) @f$[\phi,\theta,\psi] @f$*/
    float _yaw_t;                           /**< target yaw angle(rad) @f$\psi@f$*/

    std::vector<NonLinPosController> _controllers;
    Eigen::Array3Xf _current_position;

    std::vector<int> _step_flags;
    std::vector<float> _step_sizes;

    float _t;                               /**< time elapsed since last start */
    std::string _ref_type;
    int _step_index;
    bool _locked_position;                  /**< flag for if step signal has been sent since the latest constroller's start*/
    int _drone_num;
    int _round;

    float _step;                            /**< Step size of step reference signal */
    int   _stepped;
    float _amp;                             /**< Amplitude of sinusoidal trajectory */
    float _omega;                           /**< Angular frequency of sinusoidal trajectory */

    int _wave_ref_ID;
    float _wave_speed;

    ros::Publisher _pub_ref;

    Eigen::Array<float, 3, 3> _wave(int drone_ID);
};

/** @class TuneNonLinear
 *
 *  This is a helper function for tuning NonLinPosController.
 *
 *  \b Overview
 *
 *  This function generates square waves in either x,y,z direction but only outputs the next step signal upon requests. It also supports testing
 *  thrust-pwm mapping which serves all controllers with AltHoldCmd command type.
 *
 *  \b Usage
 *  -# Generate square waves
 *     - Upon pressing start button on GUI, a square wave is generated.
 *     - After the vehicle finished its step response, one needs to press stop button to terminate the controller before pressing
 *       start for another step signal
 *  -# Test thrust-pwm mapping
 *     - Before testing, comment out thrust-pwm mapping at CrazyflieServer::_pack_cmd if flying with real vehicles and/or
 *       comment out the mapping in DroneSim::update_drone_cmd
 *
 */

class TuneNonLinear : public ControllerBase<AltHoldCmd, FullState>{
public:
    TuneNonLinear(ControllerInfo* info,
                  std::vector<AltHoldCmd*> cmd_addr,
                  std::vector<FullState*> state_addr,
                  ros::NodeHandle* nh):
            ControllerBase<AltHoldCmd, FullState>(info,
                                                  cmd_addr,
                                                  state_addr,
                                                  nh),
            _pos_t(3,0),
            _vel_t(3,0),
            _acc_ff(3,0),
            _rpy_t(3,0),
            _yaw_t(0),
            _step(0.0),
            _stepped(false)
    {
        // load ROS parameters
        _load_parameters();
        // set position controller's parameters
        _controller.setParams(_params);

        _acc_ff[2] = 9.8f;
    };

    /** Compute control inputs.
     *
     *  -# output the next step signal if controller was stopped and commanded to start again
     *  -# feed the current input signal to #_controller and compute next command
     *  -# map thrust @f$t@f$ to pwm value @f$ pwm = k_{t^2}*t^2 + k_t * t + k_c@f$
     *
     * @param cmds next commands
     * @param states current states
     * @return 0
     */

    int control(AltHoldCmd* const cmds, FullState const *states);
private:
    void _load_parameters();                /**< load ROS parameters */
    std::vector<PIDParam> _params;          /**< controller parameters x,y,z direction*/
    std::vector<float> _pos_t;              /**< target position (m) @f$\mathbf{r_T} = [x,y,z] @f$ */
    std::vector<float> _vel_t;              /**< target velocity (m/s) @f$\mathbf{v_T} = [v_x,v_y,v_z] @f$*/
    std::vector<float> _acc_ff;             /**< acceleration feed forward (m/s/s) @f$\mathbf{a_{ff}} = \mathbf{\ddot{r_t}} + [0, 0, 9.8] @f$*/
    std::vector<float> _rpy_t;              /**< control input roll, pitch, yaw (rad) @f$[\phi,\theta,\psi] @f$*/
    float _yaw_t;                           /**< target yaw angle(rad) @f$\psi@f$*/

    NonLinPosController _controller;        /**< nonlinear controller */

    float _k_t2;                            /**< thrust-pwm mapping coefficient @f$k_{t^2}@f$ */
    float _k_t;                             /**< thrust-pwm mapping coefficient @f$k_t@f$ */
    float _k_c;                             /**< thrust-pwm mapping coefficient @f$k_c@f$ */

    float _t;                               /**< time elapsed since last start */

    float _step;                            /**< next step signal. Sign indicates step direction*/
    bool _stepped;                          /**< flag for if step signal has been sent since the latest constroller's start*/
    int _step_index;                        /**< space dimension index for step signal. x: 0, y: 1, z: 2 */
    int _drone_num;
};

class TuneMelCtrl : public ControllerBase<PosSetCmd, FullState>{
public:
    TuneMelCtrl(ControllerInfo* info,
                  std::vector<PosSetCmd*> cmd_addr,
                  std::vector<FullState*> state_addr,
                  ros::NodeHandle* nh):
            ControllerBase<PosSetCmd, FullState>(info,
                                                  cmd_addr,
                                                  state_addr,
                                                  nh),
            _drone_num(info->drone_num),
            _stepped(false),
            _t(0),
            _step_size(3,0),
            _amp(0),
            _omega(0),
            _sin_index(-1)
    {
        // load ROS parameters
        _load_parameters();

    };

    /** Compute control inputs.
     *
     *  -# output the next step signal if controller was stopped and commanded to start again
     *  -# feed the current input signal to #_controller and compute next command
     *  -# map thrust @f$t@f$ to pwm value @f$ pwm = k_{t^2}*t^2 + k_t * t + k_c@f$
     *
     * @param cmds next commands
     * @param states current states
     * @return 0
     */

    int control(PosSetCmd* const cmds, FullState const *states);
private:
    void _load_parameters();                /**< load ROS parameters */
    std::vector<std::vector<float>> _pos_t; /**< target position (m) @f$\mathbf{r_T} = [x,y,z] @f$ */
    std::vector<std::vector<float>> _init_pos; /**< target position (m) @f$\mathbf{r_T} = [x,y,z] @f$ */

    float _t;                               /**< time elapsed since last start */

    std::string _ref_type;                  /**< reference type: sine, step */
    std::vector<float> _step_size;          /**< step size in x,y,z direction */
    bool _stepped;                          /**< flag for if step signal has been sent since the latest constroller's start*/

    float _amp;
    float _omega;
    int _sin_index;

    int _drone_num;
};

#endif //PROJECT_CONTROLLER_EXAMPLE_H
