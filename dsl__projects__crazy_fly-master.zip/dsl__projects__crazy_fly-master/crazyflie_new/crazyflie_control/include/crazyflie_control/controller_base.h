/*
 * controller_base.h
 *
 *  Created on : Feb 10, 2018
 *       Author: Xintong Du
 */

#ifndef PROJECT_CONTROLLER_BASE_H
#define PROJECT_CONTROLLER_BASE_H

#include <chrono>
#include <queue>
#include <shared_mutex>
#include <thread>
#include <vector>

#include "ros/ros.h"
#include "crazyflie_control/controller_info.h"
#include "crazyflie_control/states_cmds_types.h"
#include "crazyflie_utility/perf_count.h"

static std::shared_timed_mutex g_states_mutex;                /* Mutex for guarding _curr_custom_cmds being updated by
                                                               * custom controllers and read  by safepilot*/
static std::shared_timed_mutex g_cmds_mutex;                  /* Mutex for guarding curr_states being updated by estimates
                                                               * cb function and safepilot and read by custom controllers*/
static std::shared_timed_mutex g_cmds_low_prio_mutex;

static std::shared_timed_mutex g_states_low_prio_mutex;

class AbstractControllerBase{
public:
    AbstractControllerBase(){status = OFF;}
    virtual ~AbstractControllerBase(){};
    ControllerStatus status;

    virtual int start() =0;
    virtual int pause() =0;
    virtual int stop()  =0;
    virtual int init()  =0;

    virtual int update_cmds() =0;
    virtual ControllerInfo* get_info()=0;
};

template<typename cmdType, typename stateType>
class ControllerBase: public AbstractControllerBase {
public:

    ControllerBase(ControllerInfo* controller_info,
                   const std::vector<cmdType*> cmd_addr,
                   const std::vector<stateType*> state_addr,
                   ros::NodeHandle* nh):
            AbstractControllerBase(),
            control_freq(controller_info->control_freq),
            drone_num(controller_info->drone_num),
            info(*controller_info),
            curr_cmds(cmd_addr),
            curr_states(state_addr),
            main_thread(),
            control_signal(),
            pf_count{info.name + "_ctrl"},
            nh(nh){
                    for(int i=0; i<50; i++)
                        states_latency.push(0);
            };

    virtual ~ControllerBase();
    /* Start the controller only if controller has been initialized
     *
     *      return: 0 if succeed
     *              -1 if failed
     */
    int start();

    //TODO: find a better way pause controller
    /* Pause the controller only if it's ON(For now, it's the same as stop)
     *
     *      return: 0 if succeed
     *              -1 if failed
     */
    int pause();

    /* Stop the controller if it's ON/INIT/PAUSED (i.e. not off)
     *
     *      return: 0 if succeed
     *              -1 if failed
     */
    int stop();

    /* Initialize the controller:
     *      Check:
     *          1) if drones are close to initial position
     *
     *      return: 0 if all checks passed
     *              -1 if any check failed or controller is already ON
     */
    int init();

    /* Compute statistics on controller performance
     *  supported statistics include
     *      1) avg_ctrl_freq: the average of control frequency over the past 50 control loop. If this number is lower than
     *         the control_freq specified in controller info, CustomController::control takes longer than
     *         expected to compute.
     *
     *      2) avg_est_latency: the average of estimation latency over the past 50 control loop. The higher ths
     *         number is, the longer time it takes for state estimation to travel from estimator to safepilot.
     *
     *  return: a map from stats name to stats number
     *
     *
     */
    ControllerInfo* get_info();

protected:
    int control_freq;
    unsigned int drone_num;
    ControllerInfo info;
    std::vector<cmdType*> curr_cmds;
    std::vector<stateType*> curr_states;
    std::thread main_thread;
    std::mutex control_signal;
    std::mutex read_info_signal;

    std::chrono::high_resolution_clock::time_point control_start_time ; /* save initial time of the controller */
    ros::NodeHandle* nh;

    std::map<std::string, float> stats;
    std::queue<float> states_latency;
    PerfCounterInterval pf_count;


    /* A wrapper function of _control that safely handles read and write
     *      1) read current states from safepilot _curr_states
     *      2) feed current states to _control
     *      3) write cmds to safepilot _curr_custom_cmds
     *      4) shared mutex guarantees that reading and writing is safe and efficient
     *
     * */
    virtual int update_cmds();

    /* Helpper function for safe write and read
     *
     * */
    void read_curr_states(stateType* const states);
    void write_cmds(cmdType const *cmds);

    float get_time_elapsed();

    /* Get cmds for all vehicles controlled by this controller.
     *
     * For C++ controller class
     *      one should implement controller that update cmds vector
     * For python controller in a separate node
     *      a generic function would be implemented that read cmds from ROS topic and update cmds vector
     *
     * */
    virtual int control(cmdType* const cmds, stateType const *states)=0;
};

template<typename cmdType, typename stateType>
ControllerBase<cmdType, stateType>::~ControllerBase(){
    stop();
};

template<typename cmdType, typename stateType>
int ControllerBase<cmdType, stateType>::init(){
    //TODO: check if controller is ready, e.g. current state satisfy specified init state
    if(status == INIT || status== OFF || status == PAUSED){
        status = INIT;
        ROS_INFO_STREAM("[Controller Hub]: Successfully initialized Controller "+ info.name);
        return 0;

        // if initilization failed
        //ROS_WARN_STREAM("[Controller Hub]: Failed to initialize Controller "+ info.name);
        // return -1;
    }
    else {
        ROS_WARN_STREAM("[Controller Hub]: Ignore " << info.name <<" initialization. It has been started.");
        return -1;
    }

};


template<typename cmdType, typename stateType>
int ControllerBase<cmdType, stateType>::start(){

    if(status == INIT){
        control_signal.unlock();
        if(main_thread.joinable())
            main_thread.join();
        control_start_time = std::chrono::high_resolution_clock::now();
        main_thread = std::thread(&ControllerBase::update_cmds, this);
        status = ON;
        ROS_INFO_STREAM("[Controller Hub]: Successfully turned on Controller " << info.name);
        info.ck_pt.push_back(ros::Time::now());

        return 0;
    }
    else{
        ROS_WARN_STREAM("[Controller Hub]: Failed to start Controller "<< info.name << ". It is currently " + ControllerStatusName[status]);
        return -1;
    }
}

template<typename cmdType, typename stateType>
int ControllerBase<cmdType, stateType>::pause() {
    if (status == ON) {
        control_signal.lock();
        main_thread.join();
        status = PAUSED;
        ROS_INFO_STREAM("[Controller Hub]: Successfully paused Controller" << info.name << '.');
        return 0;
    } else {
        ROS_WARN_STREAM("[Controller Hub]: Failed to pause Controller " << info.name
                        << ". Controller is currently " << ControllerStatusName[status]);
        return -1;
    }
}

template<typename cmdType, typename stateType>
int ControllerBase<cmdType, stateType>::stop(){
    if(status != OFF){
        control_signal.lock();
        main_thread.join();
        status = OFF;
        ROS_INFO_STREAM("[Controller Hub]: Successfully turned off Controller " << info.name);
        control_signal.unlock();
        info.ck_pt.push_back(ros::Time::now());
        return 0;
    }
    else{
        ROS_WARN_STREAM("[Controller Hub]: Failed to turn off Controller " << info.name
                  << ". Controller is currently " << ControllerStatusName[status]);
        return -1;
    }
}

template <typename cmdType, typename stateType>
int ControllerBase<cmdType, stateType>::update_cmds() {
    ros::Rate r(control_freq);
    int control_ret=0;
    while(control_signal.try_lock()){
        control_signal.unlock();

        stateType curr_states[drone_num]{};
        cmdType cmds[drone_num]{};

        read_curr_states(curr_states);
        control_ret = control(cmds, curr_states);

        if(!control_ret){
            // TODO: should require control set time_stamp
            for(int i=0; i<drone_num; ++i)
                cmds[i].time_stamp = ros::Time::now();
            write_cmds(cmds);
            r.sleep();
        }
        else
            break;
        pf_count.count();
    }

    if(!control_ret){
        ROS_INFO_STREAM("[Controller Hub]: Controller "<< info.name << " is killed.");
        return -1;
    }
    else{
        ROS_INFO_STREAM("[Controller Hub]: Controller "<< info.name <<  " finished!");
        status = OFF;
        return 0;
    }

}

template <typename cmdType, typename stateType>
void ControllerBase<cmdType, stateType>::read_curr_states(stateType* const states) {
    g_states_low_prio_mutex.lock_shared();
    g_states_mutex.lock_shared();
    for(int i=0; i<drone_num; ++i){
        memcpy(&states[i], curr_states.at(i), sizeof(*curr_states.at(i)));
    }
    g_states_mutex.unlock_shared();
    g_states_low_prio_mutex.unlock_shared();

    float latency = float(ros::Time::now().toSec() - states[0].time_stamp.toSec());
    states_latency.push(latency);
    states_latency.pop();
}

template <typename cmdType, typename stateType>
void ControllerBase<cmdType, stateType>::write_cmds(cmdType const *cmds) {
    //TODO: Add shared mutex

    g_cmds_low_prio_mutex.lock_shared();
    g_cmds_mutex.lock_shared();
    for(int i=0; i<drone_num; ++i){
        memcpy(curr_cmds.at(i), &cmds[i], sizeof(cmds[i]));
    }
    g_cmds_low_prio_mutex.unlock_shared();
    g_cmds_mutex.unlock_shared();
}

template <typename cmdType, typename stateType>
ControllerInfo* ControllerBase<cmdType, stateType>::get_info(){
    read_info_signal.lock();
    std::queue<float> lat = states_latency;
    ControllerStatus status_temp = status;
    read_info_signal.unlock();

    float sum_lat=0;
    float sum_freq=0;
    for(int i=0; i<50; ++i){
        sum_lat += lat.front();
        lat.pop();
    }

    stats["avg_ctrl_freq"] = 1 / pf_count.get_info().avg;
    stats["avg_est_latency"] = sum_lat / 50.0f;
    info.stats = stats;
    info.status = status_temp;

    return &info;
};

template <typename cmdType, typename stateType>
float ControllerBase<cmdType, stateType>::get_time_elapsed(){
    using namespace std::chrono;
    high_resolution_clock::time_point now = high_resolution_clock::now();
    high_resolution_clock::duration time_span = duration_cast<high_resolution_clock::duration>(now - control_start_time);
    return ((float) time_span.count())/1e9;
};


#endif //PROJECT_CONTROLLER_BASE_H
