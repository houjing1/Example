/*
 * controller_info.h
 *
 *  Created On : Mar 06, 2018
 *      Author : Xintong Du
 */
#ifndef PROJECT_CONTROLLER_INFO_H
#define PROJECT_CONTROLLER_INFO_H

#include <map>
#include <string>
#include <vector>


enum ControllerStatus {OFF, INIT, ON, PAUSED};
static std::string ControllerStatusName[4] = {"OFF", "INIT", "ON", "PAUSED"};
struct ControllerInfo{
    ControllerInfo() : status(OFF) {};
    std::string name;                           /* Controller's name */
    std::pair<std::string, std::string> group;  /* <CommandGroup, StateGroup> pair */
    std::vector<ros::Time> ck_pt;               /* time check points */
    int drone_num;                              /* The total number of drones required by the controller */
    std::vector<int> drone_ID;                  /* The IDs of drones allocated to the controller */
    int control_freq;                           /* The control frequency */
    ControllerStatus status;                    /* Current status of controller */
    std::map<std::string, float> stats;         /* Statistics on controller performance */
};

#endif