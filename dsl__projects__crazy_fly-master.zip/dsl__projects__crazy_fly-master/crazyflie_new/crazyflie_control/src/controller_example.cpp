/*
 * custom_controller_example.cpp
 *
 *  Created On : Feb 10, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "ros/ros.h"
#include "crazyflie_control/controller_example.h"
#include "crazyflie_utility/container_stream.h"

#define  pi 3.14159265358979323846264338

int CircleController::control(PosSetCmd* const cmd, FullState const *state){
    _t = get_time_elapsed();

    /* Check if reached the desired number of rounds */
    if(_omega*_t > 2*pi*_round)
        return -1;


    /* Init check will guarantee that N drones are at their initial position (i.e. equally
     * spaced on the circle of radius 'r' at certain altitude) */

    for(int i=0; i<drone_num; i++){
        float phi = i*2*pi/drone_num;                // phase of the i-th drone
        cmd[i].x = _r* (float) cos(_omega*_t + phi); // x component of circle
        cmd[i].y = _r* (float) sin(_omega*_t + phi); // Y component of circle
        cmd[i].z = _height;                              // keep same altitude throughout trajectory
        cmd[i].yaw = 0.f;
    }

    return 0;
};

void CircleController::_load_parameters() {
    nh->getParam("controller/" + info.name + "/omega", _omega);
    nh->getParam("controller/" + info.name + "/r", _r);
    nh->getParam("controller/" + info.name + "/round_num", _round);
    nh->getParam("controller/" + info.name + "/height", _height);
}

int CircleControllerNonlinear::control(AltHoldCmd* const cmd, FullState const *state){
    _t = get_time_elapsed();

    /* Check if reached the desired number of rounds */
    _t = _t > 2.f*pi*_round/_omega ? 2.f*pi*_round/_omega : _t;

    /* Init check will guarantee that N drones are at their initial position (i.e. equally
     * spaced on the circle of radius 'r' at certain altitude) */
    float pos_t[3]{0,0,0};
    float vel_t[3]{0,0,0};
    float acc_ff[3]{0,0,0};
    float rpy[3]{0,0,0};
    float thrust;
    for(int i=0; i<drone_num; i++){
        float phi = i*2*pi/drone_num;                // phase of the i-th drone
        float cs = (float) cos(_omega*_t + phi);
        float s  = (float) sin(_omega*_t + phi);

        // position
        pos_t[0]= _r* cs;
        pos_t[1]= _r* s;
        pos_t[2]= _height;

        // tangent velocity
        if(_use_vel){
            vel_t[0] = _r * s;
            vel_t[1] = -_r * cs;
            vel_t[2] = 0.f;
        }
        else{
            vel_t[0] = 0;
            vel_t[1] = 0;
            vel_t[2] = 0;
        }


        // acc_ff = tangent acc + centripetal acc + gravity
        if(_use_ff){
            acc_ff[0] = - _r* _omega * _omega * cs;
            acc_ff[1] = - _r* _omega * _omega * s;
            acc_ff[2] = 9.8f;
        }
        else{
            acc_ff[0] = 0.f;
            acc_ff[1] = 0.f;
            acc_ff[2] = 9.8f;
        }

        _pos_controller.update( 1.f / (float) info.control_freq, pos_t, vel_t, 0, acc_ff,
                                state[i].data[0], state[i].data[1], rpy, &thrust);

        cmd[i].roll = rpy[0];
        cmd[i].pitch = rpy[1];
        cmd[i].yaw = rpy[2];
//        cmd[i].thrust = -0.001227f * thrust * thrust + 0.0743f * thrust + 0.0209f;
        cmd[i].thrust = thrust;
    }

    if(_omega*get_time_elapsed() > 2.f*pi*(_round + 1.0f))
        return -1;

    return 0;
};

void CircleControllerNonlinear::_load_parameters() {
    nh->getParam("controller/" + info.name + "/omega", _omega);
    nh->getParam("controller/" + info.name + "/r", _r);
    nh->getParam("controller/" + info.name + "/round_num", _round);
    nh->getParam("controller/" + info.name + "/height", _height);

    // Load controller parameter
    PIDParam _pidparam;
    nh->getParam("controller/" + info.name + "/PID/X/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/X/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/X/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/X/iLimit", _pidparam.iLimit);

    _params.push_back(_pidparam);
    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/PID/Z/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/Z/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/Z/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/Z/iLimit", _pidparam.iLimit);
    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/use_ff", _use_ff);
    nh->getParam("controller/" + info.name + "/use_vel", _use_vel);


}

int WaveController::control(AltHoldCmd* const cmd, FullState const *state){
    _t = get_time_elapsed();

    if(_t < 0.03f && !_locked_position){
        for(int i=0; i<_drone_num; ++i){
            _controllers[i].reset();

            _init_pos.at(i)[0] = _pos_t.at(i)[0];
            _init_pos.at(i)[1] = _pos_t.at(i)[1];
            _init_pos.at(i)[2] = _pos_t.at(i)[2];

        }

        _locked_position = true;
        _stepped = false;
    }
    else if(_t > 0.03f){
        _locked_position = false;



        for(int i=0; i<_drone_num; ++i)
            for(int j=0; j<3; ++j)
                _current_position(j,i) = state[i].data[0][j];

        // Sinusoidal Trajectory
        if(_ref_type == "sin"){
            float sin_wave = _amp * sin(_omega * _t - 3.14f/2);
            float vel = cos(_omega * _t - 3.14f/2) *  _amp * _omega;


            for(int i=0; i<_drone_num; ++i)
                for(int j=0; j<3; ++j){
                    if(j== _step_index){
                        _pos_t[i][j] = _init_pos[i][j] +_amp + sin_wave;
                        _vel_t[i][j] = vel;
                    }
                }

        }

        // Wave
        if(_ref_type == "wave" ){
            if(_t > 15.0f){
                if(info.ck_pt.size() == 1)
                    info.ck_pt.push_back(ros::Time::now());
                _t -= 15.0f;

                Eigen::Array<float, 3, 3> reference;

                for(int i=0; i<_drone_num; ++i){
                    reference = _wave(i);
                    for(int j=0; j<3; ++j){
                        _pos_t[i][j] = reference(0,j);
                        _vel_t[i][j] = reference(1,j);
                    }
                }
            }
            if (_t > 25.f)
                ROS_INFO_STREAM_ONCE("[WaveController]: Ready to be terminated");

        }


        // Step Setpoint
        if(_ref_type == "step" && !_stepped){
            for(int i=0; i<_drone_num; ++i) {
                for(int j=0; j<3; ++j)
                    if (_step_flags[j] == 1)
                        _pos_t.at(i)[j] += _step_sizes[j];
            }
            _step = -_step;
            for(int j=0; j<3; ++j)
                if (_step_flags[j] == 1)
                    _step_sizes[j] = -_step_sizes[j];
            _stepped = true;
        }

    }

    // Position Control
    for(int i=0; i<_drone_num; ++i){
        float acc_z;
        float dt = 1.f / (float) info.control_freq;
        std::vector<float> rpy_t{0,0,0};
        _controllers[i].update(dt, _pos_t[i].data(), _vel_t[i].data(), _yaw_t, _acc_ff.data(), state[i].data[0], state[i].data[1], rpy_t.data(), &acc_z);

        cmd[i].roll = rpy_t[0];
        cmd[i].pitch = rpy_t[1];
        cmd[i].yaw = rpy_t[2];

        cmd[i].thrust = acc_z;          // thrust
    }

    // Publish reference value
    crazyflie_logger::DebugArray _ref;
    for(int i=0; i<_drone_num; ++i){
        crazyflie_logger::DebugLog log;
        log.name = "Drone" + std::to_string(i+1) + "_pos_t";
        log.stamp = ros::Time::now();
        log.values.push_back(_pos_t[i][0]);
        log.values.push_back(_pos_t[i][1]);
        log.values.push_back(_pos_t[i][2]);

        _ref.log.push_back(log);
    }

    for(int i=0; i<_drone_num; ++i){
        crazyflie_logger::DebugLog log;
        log.name = "Drone" + std::to_string(i+1) + "_vel_t";
        log.stamp = ros::Time::now();
        log.values.push_back(_vel_t[i][0]);
        log.values.push_back(_vel_t[i][1]);
        log.values.push_back(_vel_t[i][2]);

        _ref.log.push_back(log);
    }

    _ref.controller_name = info.name;

    _pub_ref.publish(_ref);

    return 0;
}



void WaveController::_load_parameters() {
    PIDParam _pidparam;
    nh->getParam("controller/" + info.name + "/PID/X/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/X/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/X/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/X/iLimit", _pidparam.iLimit);

    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/PID/Y/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/Y/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/Y/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/Y/iLimit", _pidparam.iLimit);
    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/PID/Z/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/Z/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/Z/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/Z/iLimit", _pidparam.iLimit);
    _params.push_back(_pidparam);


    nh->getParam("controller/" + info.name + "/step_index", _step_index);
    nh->getParam("controller/" + info.name + "/step_size", _step);
    nh->getParam("controller/" + info.name + "/drone_num", _drone_num);
    nh->getParam("controller/" + info.name + "/ref_type", _ref_type);

    int flag_temp;
    float size_temp;

    nh->getParam("controller/" + info.name + "/step/X/flag", flag_temp);
    nh->getParam("controller/" + info.name + "/step/X/size", size_temp);
    _step_flags.push_back(flag_temp);
    _step_sizes.push_back(size_temp);

    nh->getParam("controller/" + info.name + "/step/Y/flag", flag_temp);
    nh->getParam("controller/" + info.name + "/step/Y/size", size_temp);
    _step_flags.push_back(flag_temp);
    _step_sizes.push_back(size_temp);

    nh->getParam("controller/" + info.name + "/step/Z/flag", flag_temp);
    nh->getParam("controller/" + info.name + "/step/Z/size", size_temp);
    _step_flags.push_back(flag_temp);
    _step_sizes.push_back(size_temp);

    ROS_INFO_STREAM(_step_flags[0] << _step_flags[1]);
    Vec2Stream(_step_flags);
    Vec2Stream(_step_sizes);

    nh->getParam("controller/" + info.name + "/drone_num", _drone_num);
    nh->getParam("controller/" + info.name + "/ref_type", _ref_type);

    nh->getParam("controller/" + info.name + "/amp", _amp);
    nh->getParam("controller/" + info.name + "/omega", _omega);
    nh->getParam("controller/" + info.name + "/wave_speed", _wave_speed);
    nh->getParam("controller/" + info.name + "/wave_ref_ID", _wave_ref_ID);


    XmlRpc::XmlRpcValue init_pos;
    nh->getParam("controller/" + info.name + "/init_pos", init_pos);  // check it is updated
    ROS_ASSERT(init_pos.getType() == XmlRpc::XmlRpcValue::TypeArray);


    for(int i=0; i<_drone_num; ++i){
        for(int j=0; j<3; ++j)
            ROS_ASSERT(init_pos[i][j].getType() == XmlRpc::XmlRpcValue::TypeDouble);

        _pos_t.push_back({{(float) static_cast<double>(init_pos[i][0]),
                           (float) static_cast<double>(init_pos[i][1]),
                           (float) static_cast<double>(init_pos[i][2])}});

    }

}

Eigen::Array<float, 3, 3> WaveController::_wave(int drone_ID){
    Eigen::Array<float, 3, 3> new_target;
    new_target << _init_pos[drone_ID][0], _init_pos[drone_ID][1],_init_pos[drone_ID][2] + _amp,
            0.f, 0.f, 0.f,
            0.f, 0.f, 0.f;

    if(drone_ID == _wave_ref_ID){
        new_target(0,2) += _amp * sin(_omega * _t - 3.14f/2);
        new_target(1,2) = _amp * _omega * cos(_omega * _t - 3.14/2);
    }
    else{
        Eigen::Vector2f ref_pos, pos;
        ref_pos << _init_pos[_wave_ref_ID][0],_init_pos[_wave_ref_ID][1];
        pos << _init_pos[drone_ID][0],_init_pos[drone_ID][1];

        float dist = (ref_pos - pos).norm();
        float shifted_time = _t - dist/_wave_speed;
        float wave = shifted_time < 0.f ? -_amp: _amp * sin(_omega * shifted_time - 3.14f/2);
        float vel = shifted_time < 0.f ? 0.f: _amp * _omega * cos(_omega * shifted_time - 3.14f/2);
        new_target(0, 2) += wave;
        new_target(1, 2) = vel;
    }

    return new_target;
}


