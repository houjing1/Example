/*
 * controller_nonlinear.cpp
 *
 *  Created On : Apr 14, 2018
 *      Author : Xintong Du
 *
 *      cite: Minimum Snap Trajectory Generation and Control for Quadrotors (Daniel Mellinger and Vijay Kumar)
 */


#include "crazyflie_control/controller_nonlinear.h"


void NonLinPosController::update(float dt, float const* pos_t, float const *vel_t,
                                 float const yaw_t, float const* acc_ff,
                                 float const* pos_s, float const* vel_s, float* const rpy, float* const thrust){

    Eigen::Array33f err_pid;

    if(dt < 1e-3f)
        dt = 1e-3f;
    else if(dt > 0.05f)
        dt = 0.05f;

    // compute P I D terms
    for(int i=0; i<3; ++i) {
        err_pid(i, 0) = pos_t[i] - pos_s[i];
        err_pid(i, 1) = vel_t[i] - vel_s[i];
        _i_err[i] += err_pid(i, 0) * dt;

        if(_i_err[i] > _params[i].iLimit){
            ROS_WARN_STREAM_ONCE("error integral" << i <<" hit ceiling");
            _i_err[i] = _params[i].iLimit;
        }

        else if (_i_err[i] < -_params[i].iLimit){
            ROS_WARN_STREAM_ONCE("error integral" << i <<" hit floor");
            _i_err[i] = -_params[i].iLimit;
        }

        err_pid(i, 2) = _i_err[i];
    }

    // Acc feed forward term
    Eigen::Vector3f acc_f{acc_ff[0], acc_ff[1],acc_ff[2]};

    // Desried normalized thrust vector
    Eigen::Vector3f acc_d = (err_pid * _K).rowwise().sum();
    acc_d += acc_f;

    // Desired thrust scalar value
    *thrust = acc_d.norm() > 1.8f* 9.8f ? 1.8f * 9.8f : acc_d.norm();
    *thrust = *thrust < 0.3f * 9.8f ? 0.3f * 9.8f : *thrust;

    // Desired attitude
    Eigen::Vector3f Z_b= acc_d.normalized();

    Eigen::Vector3f X_c(cos(yaw_t), sin(yaw_t), 0);
    Eigen::Vector3f Y_b = Z_b.cross(X_c).normalized();
    Eigen::Vector3f X_b = Y_b.cross(Z_b);

    // Rotation matrix from world frame to body frame
    Eigen::Matrix3f R_bw;
    R_bw << X_b(0), X_b(1), X_b(2),
            Y_b(0), Y_b(1), Y_b(2),
            Z_b(0), Z_b(1), Z_b(2);
//    ROS_INFO_STREAM("Rotation_bw\n"<<R_bw << "X_b\n" << X_b << "Y_b\n" << Y_b << "Z_b\n" << Z_b);

    // Euler angle, Z-X-Y convention
    Eigen::Vector3f euler;
//    euler[0] = atan2(R_bw(1, 2),  R_bw(2,2));
//    euler[1] = atan2(-R_bw(0, 2), pow(R_bw(0, 1)*R_bw(0, 1) + R_bw(0, 0)*R_bw(0, 0), 0.5));
//    euler[2] = atan2(R_bw(0, 1), R_bw(0, 0));
    euler[0] = asin(R_bw(1,2));
    euler[1] = atan2(-R_bw(0, 2), R_bw(2,2));
    euler[2] = atan2(-R_bw(1, 0), R_bw(1,1));

    // Roll Pitch Yaw
    rpy[0] = euler[0];
    rpy[1] = euler[1];
    rpy[2] = euler[2];
}

void NonLinPosController::reset(){
    _i_err[0] = 0;
    _i_err[1] = 0;
    _i_err[2] = 0;
}