/*
 * controller_hub.cpp
 *
 *  Created on : Feb 10, 2018
 *       Author: Xintong Du
 */
#include "crazyflie_control/controller_hub.h"

#include "ros/ros.h"

ControllerHub::ControllerHub(ros::NodeHandle* nh):
    _controllers(),
    _nh(nh) {
    _pub_status = _nh->advertise<crazyflie_control::ControllerHubStatus>("controller_hub_status", 2);
}


ControllerHub::~ControllerHub(){
    std::map<std::string, AbstractControllerBase*>::iterator it;

    for(it=_controllers.begin(); it!=_controllers.end(); ++it){
        delete it->second;
    }
}

int ControllerHub::start_controller(std::string name){
    if(search_member(name)){
        AbstractControllerBase* controller = _controllers[name];

        if(!controller->init())
            return controller->start();
        else
            return -1;
    }
    else{
        ROS_WARN_STREAM("[Controller Hub]: Failed to start Controller "<< name << ". NOT found in profile.");
        return -1;
    }
}

int ControllerHub::stop_controller(std::string name){

    if(search_member(name))
        return _controllers[name]->stop();

    else{
        ROS_WARN_STREAM("[Controller Hub]: Failed to start Controller "<< name << ". NOT found in profile.");
        return -1;
    }
}

int ControllerHub::pause_controller(std::string name){
    if(search_member(name))
        return _controllers[name]->pause();

    else{
        ROS_WARN_STREAM("[Controller Hub]: Failed to start Controller "<< name << ". NOT found in profile.");
        return -1;
    }
}

void ControllerHub::broadcast_status(){
    crazyflie_control::ControllerHubStatus curr_status;
    ControllerInfo struct_info_temp;

    for(auto _controller : _controllers){
        struct_info_temp = *_controller.second->get_info();
        crazyflie_control::ControllerInfo msg_info_temp;

        msg_info_temp.name = struct_info_temp.name;
        msg_info_temp.group[0] = struct_info_temp.group.first;
        msg_info_temp.group[1] = struct_info_temp.group.second;
        msg_info_temp.drone_num = (signed char) struct_info_temp.drone_num;
        msg_info_temp.status = ControllerStatusName[struct_info_temp.status];
        msg_info_temp.drone_ID = std::vector<signed char>(struct_info_temp.drone_ID.begin(),
                                                          struct_info_temp.drone_ID.end());
        msg_info_temp.control_freq = struct_info_temp.control_freq;
        msg_info_temp.ck_pt = struct_info_temp.ck_pt;

        std::map<std::string, float>::iterator it;
        for(it=struct_info_temp.stats.begin(); it!=struct_info_temp.stats.end(); ++it){
            msg_info_temp.stats_name.push_back(it->first);
            msg_info_temp.stats.push_back(it->second);
        }

        curr_status.controllers_info.push_back(msg_info_temp);
        curr_status.controllers_name.push_back(msg_info_temp.name);
        curr_status.controllers_status.push_back(msg_info_temp.status);
    }

    curr_status.header.stamp = ros::Time::now();
    if(_controllers.size() > 0)
        _pub_status.publish(curr_status);
}

ControllerInfo* ControllerHub::query(std::string name){
    if (search_member(name))
        return _controllers[name]->get_info();
    else{
        ROS_WARN_STREAM("[Controller Hub]: Controller " << name <<" not found");
        return nullptr;
    }
}

bool ControllerHub::search_member(std::string name){

    std::map<std::string, AbstractControllerBase*>::iterator it;
    it = _controllers.find(name);

    return it !=_controllers.end();
}