/*
 * tune_controller_nonlinear.cpp
 *
 *  Created On : Apr 14, 2018
 *      Author : Xintong Du
 *
 *      cite:
 */

#include "crazyflie_control/controller_base.h"
#include "crazyflie_control/controller_example.h"

void TuneNonLinear::_load_parameters(){
    PIDParam _pidparam;
    nh->getParam("controller/" + info.name + "/PID/X/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/X/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/X/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/X/iLimit", _pidparam.iLimit);

    _params.push_back(_pidparam);
    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/PID/Z/kp", _pidparam.kp);
    nh->getParam("controller/" + info.name + "/PID/Z/kd", _pidparam.kd);
    nh->getParam("controller/" + info.name + "/PID/Z/ki", _pidparam.ki);
    nh->getParam("controller/" + info.name + "/PID/Z/iLimit", _pidparam.iLimit);
    _params.push_back(_pidparam);

    nh->getParam("controller/" + info.name + "/ThrustFit/kt2", _k_t2);
    nh->getParam("controller/" + info.name + "/ThrustFit/kt", _k_t);
    nh->getParam("controller/" + info.name + "/ThrustFit/kc", _k_c);

    nh->getParam("controller/" + info.name + "/step_index", _step_index);
    nh->getParam("controller/" + info.name + "/step_size", _step);
    nh->getParam("controller/" + info.name + "/drone_num", _drone_num);

}

int TuneNonLinear::control(AltHoldCmd* const cmd, FullState const *state){

    if(get_time_elapsed() < 0.03f && !_stepped){
        _controller.reset();
        _pos_t[0] = state[0].x;
        _pos_t[1] = state[0].y;
        _pos_t[2] = state[0].z;

        _pos_t[_step_index] += _step;
        _step = - _step;
        _stepped = true;
    }
    else if(get_time_elapsed() > 0.03f){
        _stepped = false;
    }

    float acc_z;
    float dt = 1.f / (float) info.control_freq;

    _controller.update(dt, _pos_t.data(), _vel_t.data(), _yaw_t, _acc_ff.data(), state->data[0], state->data[1], _rpy_t.data(), &acc_z);

    cmd->roll = _rpy_t[0];
    cmd->pitch = _rpy_t[1];
    cmd->yaw = _rpy_t[2];

//    float pwm = _k_t2 * acc_z * acc_z + _k_t * acc_z + _k_c;
    cmd->thrust = acc_z;          // thrust
    return 0;
}

