#include "crazyflie_control/controller_example.h"

void TuneMelCtrl::_load_parameters() {
    nh->getParam("controller/" + info.name + "/ref_type", _ref_type);

    nh->getParam("controller/" + info.name + "/step_size/X", _step_size[0]);
    nh->getParam("controller/" + info.name + "/step_size/Y", _step_size[1]);
    nh->getParam("controller/" + info.name + "/step_size/Z", _step_size[2]);

    nh->getParam("controller/" + info.name + "/sine/amp", _amp);
    nh->getParam("controller/" + info.name + "/sine/omega", _omega);
    nh->getParam("controller/" + info.name + "/sine/index", _sin_index);

    XmlRpc::XmlRpcValue init_pos;
    nh->getParam("controller/" + info.name + "/init_pos", init_pos);  // check it is updated
    ROS_ASSERT(init_pos.getType() == XmlRpc::XmlRpcValue::TypeArray);


    for(int i=0; i<_drone_num; ++i){
        for(int j=0; j<3; ++j)
            ROS_ASSERT(init_pos[i][j].getType() == XmlRpc::XmlRpcValue::TypeDouble);

        _pos_t.push_back({{(float) static_cast<double>(init_pos[i][0]),
                                  (float) static_cast<double>(init_pos[i][1]),
                                  (float) static_cast<double>(init_pos[i][2])}});

    }
    _init_pos = _pos_t;

}

int TuneMelCtrl::control(PosSetCmd* const cmd, FullState const *state){
    _t = get_time_elapsed();

    if(_t > 10.0f){
        _t -= 10.0f;

        // Sinusoidal Trajectory
        if(_ref_type == "sin"){
            float sin_wave = _amp * (sin(_omega * _t - 3.14f/2)+1);

            for(int i=0; i<_drone_num; ++i)
                for(int j=0; j<3; ++j){
                    if(j== _sin_index){
                        _pos_t[i][j] = _init_pos[i][j] + sin_wave;
                    }
                }
        }

        // Step Setpoint
        if(_ref_type == "step" && !_stepped){
            for(int i=0; i<_drone_num; ++i) {
                for(int j=0; j<3; ++j){
                    _pos_t.at(i)[j] = state[i].data[0][j]+_step_size[j];
                    _step_size[j] = -_step_size[j];
                }
            }

            _stepped = true;
        }

    }


    for(int i=0; i<_drone_num; ++i){
        cmd[i].x = _pos_t[i][0];
        cmd[i].y = _pos_t[i][1];
        cmd[i].z = _pos_t[i][2];
        cmd[i].yaw = 0;

    }


    return 0;
}
