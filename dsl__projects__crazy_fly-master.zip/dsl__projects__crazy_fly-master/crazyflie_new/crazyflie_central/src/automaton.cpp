/*
 * automaton.cpp
 *
 *  Created On : Mar 23, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */
#include "ros/ros.h"
#include "crazyflie_central/automaton.h"

void Automaton::run(){

    switch(_curr_status){
        case Init:
            // TODO: Make connected, onboard_test_passed and curr_state_valid available for user to see
            if(_events.connected && _events.onboard_test_passed && _events.curr_state_valid)
                _curr_status = Sleep;

            break;

        case Sleep:
            if(!_events.connected || !_events.onboard_test_passed || !_events.curr_state_valid)
                _curr_status = Init;

            // Move onward only when assigned to a task and allocated to a group (i.e. has safe controllers)
            if(_events.assigned_task)
                _curr_status = Idle;

            break;

        case Idle:

            // If not assigned to any task, go back to sleep mode and wait for new tasks
            if(!_events.assigned_task){
                _curr_status = Sleep;
            }
            // if current state is invalid, go back to Init mode
            else if(!_events.curr_state_valid)
                _curr_status = Init;

            else if(_events.takeoff_requested)
                _curr_status = Takeoff;

            break;

        case Takeoff:


            if(_events.emergency_requested || !_events.curr_state_valid)
                _curr_status = Emergency;

            else if(_events.land_requested)
                _curr_status = Landing;

            else if(_events.hover_requested || _events.reached_takeoff_pos)
                _curr_status = Hover;

            break;

        case Hover:


            if(_events.emergency_requested || !_events.curr_state_valid)
                _curr_status = Emergency;

            else if(_events.land_requested)
                _curr_status = Landing;

            // force vehicle to not transit to CustomControl mode until the first valid cmd has arrived
            else if(_events.custom_control_requested && _events.curr_cmd_valid)
                _curr_status = CustomControl;

            break;

        case CustomControl:

            if(_events.emergency_requested || !_events.curr_state_valid)
                _curr_status = Emergency;

            else if(_events.land_requested)
                _curr_status = Landing;

            else if(_events.hover_requested || !_events.curr_cmd_valid)
                _curr_status = Hover;

            break;

        case Landing:

            if(_events.emergency_requested || !_events.curr_state_valid)
                _curr_status = Emergency;

            else if(_events.hover_requested)
                _curr_status = Hover;

            else if(_events.touched_ground)
                _curr_status = Idle;

            break;

        case Emergency:

            break;
    }

    /* Clear out some of the events */

    // These flags should be set by safepilot at each time step
    _events.curr_cmd_valid = false;
    _events.curr_state_valid = false;
    _events.reached_takeoff_pos = false;
    _events.touched_ground = false;

    /* a) if user requests were true and current status allow them, they must have been addressed. Hence, it's safe to clear.
     * b) if user requests were true but current status doesn't allow them, they should be cleared to prevent surprising
     *    transition after drone reached the valid status.
     */
    _events.takeoff_requested = false;
    _events.hover_requested = false;
    _events.land_requested = false;
    _events.emergency_requested = false;
    _events.custom_control_requested = false;

    // connected and onboard_test_passed should be cleared by safepilot when CrazyflieServer pass back related info


}