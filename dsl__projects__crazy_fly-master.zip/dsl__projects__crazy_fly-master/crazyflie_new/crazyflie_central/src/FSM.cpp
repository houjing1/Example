/*
 * FSM.cpp
 *
 *  Created On : Mar 02, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */
#include "crazyflie_central/FSM.h"

#include <cassert>
#include <iostream>

#include "ros/ros.h"

FSM::FSM(int drone_num, ros::NodeHandle* nh) :
        _nh(nh),
        _drone_num(drone_num),
        events_record(drone_num),
        _status_record(drone_num, Init),
        _group_record(drone_num, NOT_ASSIGNED){

    for(int i=0; i<drone_num; ++i)
        _automata.emplace_back(i, events_record[i], _status_record[i]);


    _pub_vehicle_status = _nh->advertise<crazyflie_central::VehicleStatus>("vehicle_status", 2);
}

void FSM::setFlag(EventEnum event, std::vector<int> drone_IDs, std::vector<bool> flags) {
    if(flags.size() == 1)
        flags.assign(drone_IDs.size(), flags[0]);

    else if(drone_IDs.size() != flags.size()){
        ROS_WARN_STREAM("Ignore event flag for " << EventName[event] << ". Unequal size of ID and flags");
        return;
    }

    for(int i=0; i<drone_IDs.size(); ++i)
        events_record[drone_IDs[i]].flags[event] = flags[i];
}

void FSM::setGroup(GroupMap target_group){

    for(GroupMap::iterator it=target_group.begin(); it!=target_group.end(); ++it){
        for(int i=0; i<it->second.size(); ++i)
            _group_record[it->second[i]] = it->first;

    }
}

const std::vector<VehicleStatus>& FSM::getStatus() {
    return _status_record;
}

void FSM::getActivated(std::vector<int> &drone_ID) {

    for(int i=0; i<_status_record.size(); ++i)
        if(_status_record[i] != Init && _status_record[i] != Sleep)
            drone_ID.push_back(i);
}

void FSM::query(StatusMap* const status){

    for(StatusMap::iterator it=status->begin(); it!=status->end(); ++it)
        it->second.clear();

    for(int i=0; i<_drone_num; i++)
        status->at(_status_record[i]).push_back(i);
}

void FSM::query(VehicleStatus status, std::vector<int>* drone_IDs){

    for(int i=0; i<_drone_num; ++i){
        if(_status_record.at(i) == status)
            drone_IDs->push_back(i);

    }
}

void FSM::query(CmdStatePair group_name, std::vector<int>* const group){
    CmdStatePair temp;

    for(int i=0; i<_drone_num; ++i){
        temp = _group_record[i];
        if(temp.first==group_name.first && temp.second==group_name.second)
            group->push_back(i);
    }
}

int FSM::query(const std::vector<int> query_IDs, std::vector<CmdStatePair>* const group){
    for(int i=0; i<query_IDs.size(); ++i)
        group->push_back(_group_record.at(query_IDs[i]));
}

int FSM::query(const std::vector<int> query_IDs, std::vector<VehicleStatus >* const status){
    for(int i=0; i<query_IDs.size(); ++i)
        status->push_back(_status_record.at(query_IDs[i]));
}

void FSM::query(CmdStatePair group_name, StatusMap* const status){
    std::vector<int> group;
    query(group_name, &group);

    for(StatusMap::iterator it_map=status->begin(); it_map != status->end(); ++it_map)
        it_map->second.clear();

    for(std::vector<int>::iterator it=group.begin(); it!=group.end(); ++it)
        status->at(_status_record.at(*it)).push_back(*it);
}


void FSM::run(){
    for(int i=0; i < _drone_num; ++i)
        _automata[i].run();

}

void FSM::broadcast() {

    /* Broadcast Current Vehicle Status */
    std::vector<signed char> status(_status_record.begin(), _status_record.end());

    crazyflie_central::VehicleStatus msg;
    msg.header.stamp = ros::Time::now();
    msg.header.frame_id = "All";
    for(int i=0; i<_drone_num; ++i){
        msg.status.push_back(VehicleStatusName[_status_record[i]]);
        msg.group.push_back(CommandGroupName[_group_record[i].first] + ", " + StateGroupName[_group_record[i].second]);
    }

    _pub_vehicle_status.publish(msg);

}
