/*
 * safepilot.cpp
 *
 *  Created On : Mar 02, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "nodelet/nodelet.h"
#include "pluginlib/class_list_macros.h"

#include "crazyflie_central/safepilot.h"

Safepilot::Safepilot(int drone_num, ros::NodeHandle *nh) :
    _nh(nh),
    _nh_slow(new ros::NodeHandle),
    _drone_num(drone_num),
    _controller_hub(nh),
    _fsm(drone_num, _nh_slow),
    _spinner(2, &_fast_queue),
    _comm_server(nh),
    _pilot_handbook(*nh),
    _next_cmds(drone_num)
{

    _nh_slow->setCallbackQueue(&_slow_queue);
    _nh->setCallbackQueue(&_fast_queue);

    _sub_FullState = _nh->subscribe("full_state", 1, &Safepilot::_cb_FullState, this);
    _srv_add_controller = _nh_slow->advertiseService("add_controller", &Safepilot::_add_custom_controller, this);
    _srv_safe_conduct = _nh_slow->advertiseService("safe_conduct", &Safepilot::_cb_safe_conduct, this);
    _srv_custom_control = _nh_slow->advertiseService("custom_control", &Safepilot::_cb_custom_control, this);
    _srv_perf_monitor = _nh_slow->advertiseService("perf_monitor", &Safepilot::_cb_perf_monitor, this);
    _slow_queue_timer = _nh->createTimer(ros::Duration(0.1), &Safepilot::_cb_slow_queue_timer, this);
    _get_params();

    _pub_cmds = _nh->advertise<crazyflie_central::SwarmCmds>("SwarmCmds", 2);

    std::vector<bool> connected, onboard_test_passed;

    if(!_simulation){
        // ToDO: server pass back the connection and onboard test results
        _comm_server.init();
        connected.assign(_drone_num, true);
        onboard_test_passed.assign(_drone_num, true);
    }
    else{
        connected.assign(_drone_num, true);
        onboard_test_passed.assign(_drone_num, true);
    }

    std::vector<int> drone_id_temp;
    for(int i=0; i<_drone_num; ++i)
        drone_id_temp.emplace_back(i);
    _fsm.setFlag(Connected, drone_id_temp, connected);
    _fsm.setFlag(OnboardTestPassed, drone_id_temp, onboard_test_passed);

    std::vector<float> init_pos_temp{0,0,2.5};
    _takeoff_endpoint.assign(_drone_num, init_pos_temp);
    _curr_states_feasibility.assign(_drone_num, false);
    _perf_vicon = PerfMonitor::addPerf(Interval, "Safepilot_Est_RX");
    _perf_run = PerfMonitor::addPerf(Interval, "Safepilot_run");

}

Safepilot::~Safepilot(){};

void Safepilot::run(){

    // Open a thread for communication with drones
    std::thread _thread_server;
    if(!_simulation)
        _thread_server = std::thread{&CrazyflieServer::run, &_comm_server};

    std::map<CmdStatePair, PilotHandbookBase*>::iterator it;
    int count = 0;
    ros::Rate r(150);
    _spinner.start();

    while(ros::ok()){
        _perf_run->count();
        // get current custom cmds for drones at Custom Control status
        _read_custom_cmds();

        _auto_safety_check();
        _fsm.run();

        // get safe cmds for drones at Takeoff Hover Idle and Land status
        _pilot_handbook.getCommands(_fsm.getStatus(), _curr_states_FullState, _next_cmds);

        // send cmds to comm prot/simulator
        _send_cmds();


        r.sleep();
        ++count;
    }

    if(!_simulation)
        _thread_server.join();
}

bool Safepilot::_add_custom_controller(crazyflie_central::AddController::Request &req,
                                       crazyflie_central::AddController::Response &res) {
    // TODO: add button to GUI to allow reload params for a specific controller

    /* check if all required controller params are set */
    XmlRpc::XmlRpcValue param;
    bool param_valid = _get_controller_param(req.controller_name, &param);

    if(!param_valid){
        res.success = false;
        return true;
    }

    /* check if controller info is valid */
    ControllerInfo ctrl_info;
    ctrl_info.name = req.controller_name;
    CmdStatePair pair{NA,NAs};

    for(int i=0; i<CMD_GROUP_SIZE; ++i)
        if(CommandGroupName[i] == std::string(param["cmd_type"]))
            pair.first = (CommandGroup) i;
    for(int i=0; i<STATE_GROUP_SIZE;++i)
        if(StateGroupName[i] == std::string(param["state_type"]))
            pair.second = (StateGroup) i;
    ctrl_info.group = std::pair<std::string, std::string>(param["cmd_type"], param["state_type"]);
    ctrl_info.drone_num = int(param["drone_num"]);
    ctrl_info.control_freq = param["ctrl_freq"];

    for(int j=0; j<param["drone_ID"].size(); j++)
        ctrl_info.drone_ID.push_back(int(param["drone_ID"][j])-1);

    bool ctrl_info_valid = true;
    // if there are enough drones
    if(ctrl_info.drone_num > _drone_num){
        ROS_WARN_STREAM("[Safepilot]: Controller info for " << ctrl_info.name << " is invalid. " <<
                        "drone_num exceed the maximum value");
        ctrl_info_valid = false;
    }
    // if there are enough drone_ID
    if(ctrl_info.drone_num > ctrl_info.drone_ID.size()) {
        ROS_WARN_STREAM("[Safepilot]: Controller info for " << ctrl_info.name << " is invalid. " <<
                                                            "Please specify ID for all drones");
        ctrl_info_valid = false;
    }
    // allow drone_num < drone_ID
    else if(ctrl_info.drone_num != ctrl_info.drone_ID.size()){
        ROS_WARN_STREAM("[Safepilot]: There are less drones requested than what provided in drone_ID. ");
        ROS_WARN_STREAM("[Safepilot]: Please be advised that only the first "<< ctrl_info.drone_num << " will be used");
        ctrl_info.drone_ID.erase(ctrl_info.drone_ID.begin()+ctrl_info.drone_num, ctrl_info.drone_ID.end());
    }


    // if drone_ID is invalid
    if(!_check_drone_ID_valid(ctrl_info.drone_ID)){
        ROS_WARN_STREAM("[Safepilot]: Controller info for " << ctrl_info.name << " is invalid. " <<
                                                            "drone_ID has invalid number.");
        ctrl_info_valid = false;
    }

    if(!ctrl_info_valid){
        res.success = false;
        return true;
    }

    /* Load the controller and add it to Controller Hub */
    int add_result = -2;
    switch(pair.second){
        case FullTranslation:
            switch(pair.first){
                case PosSet:
                    if(!strcmp(std::string(param["class_name"]).c_str(), "CircleController")){

                        _init_curr_cmds_states(pair);
                        add_result = _controller_hub.add_controller<CircleController, PosSetCmd, FullState>(&ctrl_info,
                                                                                                            _curr_custom_cmds_PosSet.data(),
                                                                                                            _curr_states_FullState.data());
                    }

                    if(!strcmp(std::string(param["class_name"]).c_str(), "TuneMelCtrl")){

                        _init_curr_cmds_states(pair);
                        add_result = _controller_hub.add_controller<TuneMelCtrl, PosSetCmd, FullState>(&ctrl_info,
                                                                                                            _curr_custom_cmds_PosSet.data(),
                                                                                                            _curr_states_FullState.data());
                    }
                    break;
                case AltHold:
                    if(!strcmp(std::string(param["class_name"]).c_str(), "TuneNonlinear")){

                        _init_curr_cmds_states(pair);
                        add_result = _controller_hub.add_controller<TuneNonLinear, AltHoldCmd, FullState>(&ctrl_info,
                                                                                                          _curr_custom_cmds_AltHold.data(),
                                                                                                          _curr_states_FullState.data());
                    }
                    else if(!strcmp(std::string(param["class_name"]).c_str(), "CircleControllerNonlinear")){

                        _init_curr_cmds_states(pair);
                        add_result = _controller_hub.add_controller<CircleControllerNonlinear, AltHoldCmd, FullState>(&ctrl_info,
                                                                                                                      _curr_custom_cmds_AltHold.data(),
                                                                                                                      _curr_states_FullState.data());
                    }
                    else if(!strcmp(std::string(param["class_name"]).c_str(), "WaveController")){

                        _init_curr_cmds_states(pair);
                        add_result = _controller_hub.add_controller<WaveController, AltHoldCmd, FullState>(&ctrl_info,
                                                                                                           _curr_custom_cmds_AltHold.data(),
                                                                                                           _curr_states_FullState.data());
                    }
                    break;
            }
            break;

        default:
            add_result = -2;
    }


    /* Summarize service response */
    if (add_result == -2){
        ROS_WARN_STREAM("[Safepilot]: Controller " << req.controller_name <<'<'<<CommandGroupName[pair.first]<<", "
                                                                               <<StateGroupName[pair.second]<<'>'
                                                   << " not found.");
        res.success = false;
    }
    else if(add_result == 0){
        ROS_INFO_STREAM("[Safepilot]: Successfully add controller " << req.controller_name);

        // add drones to pilot handbook with default safe controller info
        std::vector<SafeControllerInfo> safe_controller_info;
        for(int i=0; i<ctrl_info.drone_ID.size(); ++i){
            safe_controller_info.emplace_back(ctrl_info.drone_ID[i]);
            for(int j=0; j<3; ++j){
                safe_controller_info[i].takeoff_endpoint[j] = (float) double(param["init_pos"][i][j]);
                _takeoff_endpoint[i][j] = (float) double(param["init_pos"][i][j]);
            }
        }

        _pilot_handbook.addVehicles(safe_controller_info);

        // Set event flag
        _fsm.setFlag(AssignedTask, ctrl_info.drone_ID, {true});

        // wake up crazyflies and get prepared for flight
        // TODO: check how long it takes for radio to connect drones
        if(!_simulation)
            _comm_server.wakeup_drones({req.controller_name});

        res.success = true;

    }

    return true;

}

bool Safepilot::_cb_safe_conduct(crazyflie_central::RequestSafeConduct::Request &req,
                                 crazyflie_central::RequestSafeConduct::Response &res){
    if(req.action_ID == TakeoffRequested || req.action_ID == LandRequested ||
       req.action_ID == EmergencyRequested || req.action_ID == HoverRequested){

        std::vector<int> drone_ID(req.drone_ID.begin(), req.drone_ID.end());
        // drone_ID from User inputs are assumed to start from 1
        // change it to start from 0, which is the convention followed by developers
        for(int i=0; i<drone_ID.size(); ++i)
            drone_ID[i] -= 1;

        if(_check_drone_ID_valid(drone_ID)){
            _fsm.setFlag((EventEnum) req.action_ID, drone_ID, {true});
            ROS_INFO_STREAM("[Safepilot]: Safe conduct " << EventName[req.action_ID] << " accepted.");
        }
        else{
            ROS_WARN_STREAM("[Safepilot]: Safe conduct rejected. drone_ID invalid.");
        }

    }
    else{
        res.success = false;
        ROS_WARN_STREAM("[Safepilot]: Safe conduct rejected. Invalid action " << EventName[req.action_ID]);
    }

    return true;

}

bool Safepilot::_cb_custom_control(crazyflie_central::CustomControl::Request &req,
                                   crazyflie_central::CustomControl::Response &res) {

    /* Get the controller_info from ControllerHub */
    ControllerInfo* controller_info = _controller_hub.query(req.controller_name);

    // not found in ControllerHub
    if(!controller_info){
        res.srv_res = -1;
        return true;
    }

    std::vector<int> drone_ID =  controller_info->drone_ID;
    /* Turn on the controller */
    if(req.target_status_ID == ON){

        // try to start the controller
        int start_res = _controller_hub.start_controller(req.controller_name);

        // successfully start controller
        if(!start_res){
            // Set the custom control flag
            _fsm.setFlag(CustomControlRequested, drone_ID, {true});
            // Set vehicles to the correct CommandGroup and StateGroup
            // FIXME: It's teadious to search for group enum with group name (string)
            ControllerInfo* info = _controller_hub.query(req.controller_name);
            CmdStatePair pair{NA,NAs};
            for(int i=0; i<CMD_GROUP_SIZE; ++i)
                if(CommandGroupName[i] == std::string(info->group.first))
                    pair.first = (CommandGroup) i;
            for(int i=0; i<STATE_GROUP_SIZE;++i)
                if(StateGroupName[i] == std::string(info->group.second))
                    pair.second = (StateGroup) i;

            GroupMap groupMap{{pair, drone_ID}};
            _fsm.setGroup(groupMap);
            res.srv_res =0;
        }

        // Request ignored. Error will be printed in the console by ControllerHub/ControllerBase
        else{
            ROS_WARN_STREAM("[Safepilot]: Failed to start Controller "<< req.controller_name);
            res.srv_res = -1;
        }
    }

    /* Turn off the controller */
    else if(req.target_status_ID == OFF){
        // We force Hover regardless of controller_hub's response
        _fsm.setFlag(HoverRequested, drone_ID, {true});
        res.srv_res = _controller_hub.stop_controller(req.controller_name);
    }

    /* Pause the controller */
    else if(req.target_status_ID == PAUSED){
        // We force Hover regardless of controller_hub's response
        _fsm.setFlag(HoverRequested, drone_ID, {true});
        res.srv_res = _controller_hub.pause_controller(req.controller_name);
    }

    /* Invalid target */
    else{
        res.srv_res = -1;
        ROS_WARN_STREAM("[Safepilot]: Target status " <<
                        VehicleStatusName[req.target_status_ID] << " cannot be changed by user.");
    }

    return true;
}

bool Safepilot::_check_drone_ID_valid(std::vector<int> query_ID) {

    // assume query_ID starts from 0
    for(std::vector<int>::iterator it=query_ID.begin(); it!=query_ID.end(); ++it){
        if(*it >= _drone_num || *it <0){
            return false;
        }
    }

    return true;
}

void Safepilot::_auto_safety_check() {

    /* Set event flags that depend on state estimates */
    if(_curr_states_FullState.size() != 0){
        // Assuming we only have FullState as estimate
        std::vector<FullState> curr_states;
        std::vector<bool> states_feas;

        // Get access to data shared with custom controllers
        g_states_low_prio_mutex.lock_shared();
        g_states_mutex.lock_shared();

        // copy data
        curr_states = _curr_states_FullState;
        states_feas = _curr_states_feasibility;

        // Unlock data for safepilot to overwrite new data
        g_states_mutex.unlock_shared();
        g_states_low_prio_mutex.unlock_shared();

        std::vector<int> drone_id_temp;
        for(int i=0; i<_drone_num; ++i)
            drone_id_temp.emplace_back(i);

        std::vector<bool> states_valid, reached_takeoff_pos,touched_ground;
        states_valid.assign(_drone_num, false);
        reached_takeoff_pos.assign(_drone_num, false);
        touched_ground.assign(_drone_num, false);
        for(int i=0; i<_drone_num; ++i){
            if( (ros::Time::now().toSec() - curr_states[i].time_stamp.toSec()) < ESTIMATES_TIMEOUT)
                if(_curr_states_feasibility.at(i))
                    states_valid[i] = true;

            float diff[3]{curr_states[i].x - _takeoff_endpoint[i][0],
                          curr_states[i].y - _takeoff_endpoint[i][1],
                          curr_states[i].z - _takeoff_endpoint[i][2]};
            float norm = diff[0] * diff[0] + diff[1] * diff[1] + diff[2] * diff[2];
            norm = (double) pow(norm, 0.5);
            if(norm < TAKEOFF_POS_TOLERANCE)
                reached_takeoff_pos[i] = true;

            if(std::abs(curr_states[i].z - 0.f) < LAND_HEIGHT_TOLERANCE)
                touched_ground[i] = true;
        }
        _fsm.setFlag(CurrStateValid, drone_id_temp, states_valid);
        _fsm.setFlag(ReachedTakeoffPOS, drone_id_temp, reached_takeoff_pos);
        _fsm.setFlag(TouchedGround, drone_id_temp, touched_ground);
    }

    /* Set event flags that depend on cmds */
    {
        StatusMap status;
        std::vector<int> temp_id;
        for (int vs=Emergency; vs!=Landing+1; vs++)
            status[static_cast<VehicleStatus>(vs)] = temp_id;

        std::vector<bool> cmd_valid_flag;
//        std::map<CmdStatePair, PilotHandbookBase*>::iterator it;

        // Only activated vehicle needs commands and hence requires validity check
        _fsm.getActivated(temp_id);

        // check if cmd is valid
        // TODO: add more to deem custom cmds valid
        // TODO: change command state group from string to enum

        for(std::vector<int>::iterator it=temp_id.begin(); it!=temp_id.end(); ++it)
            // check if cmd is outdated?
            if((ros::Time::now().toSec() - _next_cmds[*it].header.stamp.toSec()) < COMMANDS_TIMEOUT)
                cmd_valid_flag.emplace_back(true);
            else
                cmd_valid_flag.emplace_back(false);

        _fsm.setFlag(CurrCmdValid, temp_id, cmd_valid_flag);
        cmd_valid_flag.clear();

    }
}

void Safepilot::_read_custom_cmds() {
    std::vector<PosSetCmd> curr_cmds_PosSet;
    std::vector<AltHoldCmd> curr_cmds_AltHold;
    std::vector<int> drone_IDs;
    std::vector<int>::iterator it;
    CmdStatePair group_name;

    // block future custom controller's writing requests
    g_cmds_low_prio_mutex.lock();
    // lock data
    g_cmds_mutex.lock();
    // allow custom controller to request writing
    g_cmds_low_prio_mutex.unlock();
    // copy data
    if(_curr_custom_cmds_PosSet.size()!=0)
        curr_cmds_PosSet = _curr_custom_cmds_PosSet;
    if(_curr_custom_cmds_AltHold.size()!=0)
        curr_cmds_AltHold = _curr_custom_cmds_AltHold;
    // unlock data
    g_cmds_mutex.unlock();

    // copy to _next_cmds_XXX
    group_name = {PosSet, FullTranslation};
    _fsm.query(group_name, &drone_IDs);
    for(it=drone_IDs.begin(); it!=drone_IDs.end(); ++it){
        _next_cmds[*it].header.frame_id = "Drone"+std::to_string(*it+1);
        _next_cmds[*it].header.stamp = curr_cmds_PosSet[*it].time_stamp;
        _next_cmds[*it].type = CommandGroupName[PosSet];
        _next_cmds[*it].values.assign(curr_cmds_PosSet[*it].data, curr_cmds_PosSet[*it].data+4);
    }

    group_name = {AltHold, FullTranslation};
    drone_IDs.clear();
    _fsm.query(group_name, &drone_IDs);
    for(it=drone_IDs.begin(); it!=drone_IDs.end(); ++it){
        _next_cmds[*it].header.frame_id = "Drone"+std::to_string(*it+1);
        _next_cmds[*it].header.stamp = curr_cmds_AltHold[*it].time_stamp;
        _next_cmds[*it].type = CommandGroupName[AltHold];
        _next_cmds[*it].values.assign(curr_cmds_AltHold[*it].data, curr_cmds_AltHold[*it].data+4);
    }

}

void Safepilot::_cb_FullState(const crazyflie_estimator::SwarmStates msg){
    int drone_num = msg.fullstate.size();
    std::vector<FullState> new_est;
    std::vector<bool> new_feas;
    _perf_vicon->count();

    if(drone_num != _drone_num){
        ROS_WARN_STREAM("Safepilot: full_state estimate is ignored. It doesn't have info for all drones");
        return;
    }else{
        for(int i=0; i<drone_num; ++i){
            FullState temp{};
            std::copy(msg.fullstate.at(i).pos.begin(), msg.fullstate.at(i).pos.end(), temp.data[0]);
            std::copy(msg.fullstate.at(i).vel.begin(), msg.fullstate.at(i).vel.end(), temp.data[1]);
            std::copy(msg.fullstate.at(i).acc.begin(), msg.fullstate.at(i).acc.end(), temp.data[2]);

            temp.time_stamp = msg.header.stamp;
            new_est.push_back(temp);
            new_feas.push_back((bool) msg.fullstate.at(i).bfeasible);
        }
    }



    // block future custom controllers' reading requests
    g_states_low_prio_mutex.lock();
    // lock data
    g_states_mutex.lock();
    // allow custom controller to reading writing
    g_states_low_prio_mutex.unlock();
    // copy data
    _curr_states_FullState = new_est;
    _curr_states_feasibility = new_feas;
    // unlock data
    g_states_mutex.unlock();

}

void Safepilot::_send_cmds() {
    std::vector<int> temp_id;
    crazyflie_central::SwarmCmds msg_new;
    std::vector<crazyflie_central::Cmd>::iterator it_cmd;

    // only activated vehicle required command
    _fsm.getActivated(temp_id);

    if(temp_id.size() == 0)
        return;

    for(std::vector<int>::iterator it=temp_id.begin(); it!=temp_id.end(); ++it)
        msg_new.cmds.push_back(_next_cmds[*it]);

    for(it_cmd=msg_new.cmds.begin(); it_cmd!=msg_new.cmds.end(); ++it_cmd)
        msg_new.names.push_back(it_cmd->header.frame_id);
    _pub_cmds.publish(msg_new);

    if(!_simulation) {
        std::map<int, crazyflie_central::Cmd> cmds_map;

        // It's unecessary to use map.
        // TODO: ask CrazyflieServer to derive drone_ID from Cmd.header.frame_id
        for(int i=0; i<temp_id.size(); ++i)
            cmds_map[temp_id.at(i)] = msg_new.cmds.at(i);

        // update the local copy of commands that are sent onboard at fixed frequency
        _comm_server.update_cmds(cmds_map);
    }
}


void Safepilot::_init_curr_cmds_states(CmdStatePair pair) {
    CommandGroup cmd_type = pair.first;
    StateGroup state_type = pair.second;

    switch (cmd_type){
        case PosSet:
            if(_curr_custom_cmds_PosSet.size()==0){
                PosSetCmd empty{};
                _curr_custom_cmds_PosSet.assign(_drone_num, empty);
                ROS_INFO_STREAM("[Safepilot]: Add new CmdType: " << CommandGroupName[cmd_type]);
            }
            break;

        case AltHold:
            if(!_curr_custom_cmds_AltHold.size()){
                AltHoldCmd empty{};
                _curr_custom_cmds_AltHold.assign(_drone_num, empty);
                ROS_INFO_STREAM("[Safepilot]: Add new CmdType: " << CommandGroupName[cmd_type]);
            }
            break;

        default:
            ROS_WARN_STREAM("[Safepilot]: Unrecognized CmdType: " << CommandGroupName[cmd_type]);
            break;
    }

    switch (state_type){
        case FullTranslation:
            if(!_curr_states_FullState.size()){
                FullState empty{};
                _curr_states_FullState.assign(_drone_num, empty);
                ROS_INFO_STREAM("[Safepilot]: Add new StateType: " << StateGroupName[state_type]);
            }
            break;

        default:
            ROS_WARN_STREAM("[Safepilot]: Unrecognized StateType: " << StateGroupName[state_type]);
            break;
    }

}

bool Safepilot::_get_controller_param(std::string controller_name, XmlRpc::XmlRpcValue* param){
    std::string param_name = "controller/" + controller_name;
    _nh->getParam(param_name, *param);

    if(param->begin() == param->end()){
        ROS_WARN_STREAM("[Safepilot]: Did not find params for " << controller_name);
        return false;
    }

    /* Check if all fields are specified */

    // field required for all controllers
    std::vector<std::string> field_names{"cpp", "drone_num",
                                         "ctrl_freq", "init_pos", "cmd_type", "state_type", "drone_ID"};

    bool valid = true;
    for(std::vector<std::string>::iterator it=field_names.begin(); it!=field_names.end(); ++it){
        if(!param->hasMember(*it)){
                valid = false;
                ROS_WARN_STREAM("[Safepilot]: Please specify " << *it << " for " << controller_name);
        }
    }

    // fields specific to c++ controllers and python controllers
    if(param->hasMember("cpp")){
        if((*param)["cpp"]){
            if(!param->hasMember("class_name")){
                ROS_WARN_STREAM("[Safepilot]: Please specify class_name for " << controller_name);
                valid = false;
            }
        }
        else{
            if(!param->hasMember("topic_name")){
                valid = false;
                ROS_WARN_STREAM("[Safepilot]: Please specify topic_name for " << controller_name);
            }
        }
    }

    return valid;
}


void Safepilot::_get_params(){
    bool got_param = false;

    /* Simulation Flag */
    got_param = _nh->getParam("simulator/activate", _simulation);
    if(!got_param) _simulation = false;
}

void Safepilot::_cb_slow_queue_timer(const ros::TimerEvent& event) {
    // Address user requests
    _slow_queue.callAvailable(ros::WallDuration(0.005));

    // Ask FSM to broadcast vehicles' current status and group assignment
    _fsm.broadcast();
    // Ask ControllerHub to broadcast registered Custom Controller Status
    _controller_hub.broadcast_status();
}

bool Safepilot::_cb_perf_monitor(std_srvs::EmptyRequest &req, std_srvs::EmptyResponse &res){
    PerfMonitor::printInfo();

    return true;
};

class SafepilotNodelet : public nodelet::Nodelet{
public:
    SafepilotNodelet()  {};

    ~SafepilotNodelet() {main.join(); delete safepilot;};

private:
    virtual void onInit(){
        ROS_INFO_STREAM("Starting SafepilotNodelet");
        n = &getNodeHandle();
        n->getParam("vehicles/num", drone_num);
        safepilot = new Safepilot(drone_num, n);

        main = std::thread(&Safepilot::run, safepilot);
    }

    std::thread main;
    Safepilot* safepilot;
    ros::NodeHandle* n;
    int drone_num;

};

PLUGINLIB_EXPORT_CLASS(SafepilotNodelet, nodelet::Nodelet)
