/*
 * run.cpp
 *
 *  Created On : Feb 24, 2018
 *      Author : Xintong Du
 */

#include <string>
#include <iostream>
#include <vector>

#include "ros/ros.h"
#include "crazyflie_control/controller_base.h"
#include "crazyflie_control/controller_example.h"
#include "crazyflie_control/controller_hub.h"
#include "crazyflie_central/safepilot.h"


int main(int argc, char **argv) {
    ros::init(argc, argv, "pilot");
    ros::NodeHandle n;
    int drone_num;

    n.getParam("vehicles/num", drone_num);

    Safepilot safe_pilot(drone_num, &n);

    safe_pilot.run();

    return 0;

}
