/*
 * pilot_handbook_dex.cpp
 *
 *  Created On : Mar 27, 2018
 *      Author : Xintong Du
 */

#include "crazyflie_central/pilot_handbook_dec.h"

void PilotHandbookDec::getCommands(const std::vector<VehicleStatus>& status_pool,
                                   const std::vector<FullState> &states_pool,
                                   std::vector<crazyflie_central::Cmd> &cmds_pool) {
    int id_temp;

    for(std::map<int, SafeController*>::iterator it=_controllers.begin(); it!=_controllers.end(); ++it){
        id_temp = it->first;
        PosSetCmd cmd;

        // GetCommand for Takeoff Hover, Landing, Idle
        // Include CustomControl only to update _last_status in SafeController
        if(status_pool[id_temp] == Takeoff || status_pool[id_temp] == Hover || status_pool[id_temp] == Emergency ||
           status_pool[id_temp] == Landing || status_pool[id_temp] == Idle  || status_pool[id_temp] == CustomControl){
            _controllers[id_temp]->getCommand(status_pool[id_temp], states_pool[id_temp], cmd);

            if(status_pool[id_temp] != CustomControl){
                cmds_pool[id_temp].header.stamp = ros::Time::now();
                cmds_pool[id_temp].header.frame_id = "Drone" + std::to_string(id_temp+1);
                cmds_pool[id_temp].type = CommandGroupName[PosSet];

                cmds_pool[id_temp].values.clear();
                cmds_pool[id_temp].values.push_back(cmd.x);
                cmds_pool[id_temp].values.push_back(cmd.y);
                cmds_pool[id_temp].values.push_back(cmd.z);
                cmds_pool[id_temp].values.push_back(cmd.yaw);
            }

        }
        else
            continue;

    }
}

void PilotHandbookDec::addVehicles(const std::vector<SafeControllerInfo> &info) {
    std::vector<int> added;
    std::vector<int> ignored;

    for(std::vector<SafeControllerInfo>::const_iterator it=info.begin(); it!=info.end(); ++it){
        if(_controllers.find(it->ID) == _controllers.end()){
            _controllers[it->ID] = new SafeController(*it);
            added.push_back(it->ID);
        }
        else
            ignored.push_back(it->ID);
    }

    if(added.size() != 0)
        ROS_INFO_STREAM("[Pilot Handbook]: Successfully added Drone " << Vec2Stream::toString(added));
    if(ignored.size() != 0)
        ROS_INFO_STREAM("[Pilot Handbook]: Ignored Drone "  << Vec2Stream::toString(ignored) << " because they have been added before");
}

void PilotHandbookDec::removeVehicles(const std::vector<int> drone_ID) {
    std::vector<int> deleted;
    std::vector<int> ignored;

    for(std::vector<int>::const_iterator it=drone_ID.begin(); it!=drone_ID.end(); ++it){
        if(_controllers.find(*it) == _controllers.end()){
            delete _controllers[*it];
            _controllers.erase(*it);
            deleted.push_back(*it);
        }
        else
            ignored.push_back(*it);
    }

    if(deleted.size() != 0)
        ROS_INFO_STREAM("[Pilot Handbook]: Successfully remove Drone " << Vec2Stream::toString(deleted));
    if(ignored.size() != 0)
        ROS_WARN_STREAM("[Pilot Handbook]: Ignore Drone " << Vec2Stream::toString(ignored)<< "because they are not in profile");
}