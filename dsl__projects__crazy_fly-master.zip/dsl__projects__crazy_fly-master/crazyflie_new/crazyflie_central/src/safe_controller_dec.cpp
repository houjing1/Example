/*
 * safe_controller_dec.cpp
 *
 *  Created On : Mar 27, 2018
 *      Author : Xintong Du
 */

#include <cmath>

#include "crazyflie_central/safe_controller_dec.h"

void SafeController::getCommand(VehicleStatus status, const FullState &curr_state, PosSetCmd& cmd) {
    bool init = (status != _last_status);

    switch(status){
        case Takeoff:
            _takeoff(curr_state, init);
            memcpy(&cmd.data, &_takeoff_sp, sizeof(_takeoff_sp));
            break;

        case Hover:
            _hover(curr_state, init);
            // force setpoint for takeoff
            if(_last_status == Takeoff)
                memcpy(&_hover_sp, &_takeoff_sp, sizeof(_takeoff_sp));

            if(_last_status == Landing)
                memcpy(&_hover_sp, &_land_sp, sizeof(_land_sp));

            memcpy(&cmd.data, &_hover_sp, sizeof(_takeoff_sp));

            break;

        case Landing:
            _land(curr_state, init);
            memcpy(&cmd.data, &_land_sp, sizeof(_land_sp));
            break;

        case Idle:
            _idle(curr_state, init);
            memcpy(&cmd.data, &_idle_sp, sizeof(_idle_sp));
            break;

        case Emergency:
            _emergency(curr_state, init);
            memcpy(&cmd.data, &_emergency_sp, sizeof(_emergency_sp));
            break;

        default:
            break;
    }

    cmd.yaw = 0.0f;
    _last_status = status;
}

void SafeController::_takeoff(const FullState &curr_state, bool init) {
    if(init){
        _takeoff_sp[X] = curr_state.x;
        _takeoff_sp[Y] = curr_state.y;
        _takeoff_sp[Z] = curr_state.z;

        float disp[3] {_info.takeoff_endpoint[X] - _takeoff_sp[X],
                       _info.takeoff_endpoint[Y] - _takeoff_sp[Y],
                       _info.takeoff_endpoint[Z] - _takeoff_sp[Z]};
        float norm = disp[X] * disp[X] + disp[Y] * disp[Y] + disp[Z] * disp[Z];
        norm = (float) pow(norm, 0.5);
        for(int i=0; i<3; ++i)
            disp[i] /= norm;

        memcpy(_takeoff_dir, disp, sizeof(disp));

        return;
    }
    // move setpoint up at constant speed
    _takeoff_sp[X] += _takeoff_dir[X] * _info.takeoff_speed * (1.0f / _info.update_rate);
    _takeoff_sp[Y] += _takeoff_dir[Y] * _info.takeoff_speed * (1.0f / _info.update_rate);
    _takeoff_sp[Z] += _takeoff_dir[Z] * _info.takeoff_speed * (1.0f / _info.update_rate);

    float diff[3];
    for(int i=0; i<3; ++i)
        diff[i] = _info.takeoff_endpoint[i] - _takeoff_sp[i] > 0 ?
                  _info.takeoff_endpoint[i] - _takeoff_sp[i] : _takeoff_sp[i] - _info.takeoff_endpoint[i];
    
    // if setpoint is close to the desired position, fix it at the desired position
    for(int i=0; i<3; ++i)
        _takeoff_sp[i] = diff[i] < 0.02f ? _info.takeoff_endpoint[i] : _takeoff_sp[i];

}

void SafeController::_hover(const FullState &curr_state, bool init) {
    if(init){
        _hover_sp[X] = curr_state.x;
        _hover_sp[Y] = curr_state.y;
        _hover_sp[Z] = curr_state.z;

        return;
    }
}


void SafeController::_land(const FullState &curr_state, bool init) {
    if(init){
        _land_sp[X] = curr_state.x;
        _land_sp[Y] = curr_state.y;
        _land_sp[Z] = curr_state.z;

        return;
    }
    // move setpoint down at constant speed
    _land_sp[Z] -= _info.landing_speed * (1.0f / _info.update_rate);

    // if setpoint is close to ground, fix it at 0
    _land_sp[Z] = _land_sp[Z] < 0.001f ? 0.0f : _land_sp[Z];
}

void SafeController::_idle(const FullState &curr_state, bool init) {
    if(init){
        _idle_sp[X] = curr_state.x;
        _idle_sp[Y] = curr_state.y;
        _idle_sp[Z] = 0.0f;

        return;
    }
}

void SafeController::_emergency(const FullState &curr_state, bool init) {
    // In PosSet mode, when setting Z position setpoint as 0, onboard firmware would set vehicles thrust as zero and
    // reinit onboard position and attitude controllers (only for PID controller).
    if(init){
        _emergency_sp[X] = curr_state.x;
        _emergency_sp[Y] = curr_state.y;
        _emergency_sp[Z] = 0.0f;

        return;
    }
}
