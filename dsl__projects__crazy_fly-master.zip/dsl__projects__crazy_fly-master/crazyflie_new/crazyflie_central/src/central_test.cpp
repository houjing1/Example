/*
 * central_test.cpp
 *
 *  Created on : Feb 10, 2018
 *       Author: Xintong Du
 */

#include <iostream>
#include <string>

#include "ros/ros.h"
#include "crazyflie_control/controller_base.h"
#include "crazyflie_control/controller_example.h"
#include "crazyflie_control/controller_hub.h"
#include "crazyflie_central/safepilot.h"

int main(int argc, char **argv) {
    ros::init(argc, argv, "central_test");
    ros::NodeHandle n;

    int freq = 100;
    int drone_num = 100;
    int drone_num_act = 10;
    int cf_IDs[drone_num_act]{2, 12, 22, 32, 42, 52, 62, 72, 82, 92};
    int cf_IDs2[drone_num_act]{5, 15, 25, 35, 45, 55, 65, 75, 85, 95};
    FullState states_pool[drone_num]{};
    PosSetCmd cmds_pool[drone_num]{};

    for (int i = 0; i < drone_num; i++) {
        states_pool[i].x = i;
        states_pool[i].y = i + 1;
        states_pool[i].z = i + 2;
    }

    std::array<FullState *, 10> states{0};
    std::array<PosSetCmd *, 10> cmds{0};

    for (int i = 0; i < drone_num_act; i++) {
        states[i] = &states_pool[cf_IDs[i]];
        cmds[i] = &cmds_pool[cf_IDs[i]];
    }


//    auto controller_hub = new ControllerHub(&n);
//    ControllerInfo info{"circle_example", 10, cf_IDs, freq};
//    std::cout << info.drone_num << '\n';
//    controller_hub->add_controller<CircleController, PosSetCmd, FullState>(&info, cmds_pool, states_pool);
//    controller_hub->report_status();
//    controller_hub->start_controller("circle_example");
//    info.drone_ID = cf_IDs2;
//    info.name = "simple_example";
//    controller_hub->add_controller<SimpleCustomController, PosSetCmd, FullState>(&info, cmds_pool, states_pool);
//    controller_hub->report_status();
//    controller_hub->start_controller("simple_example");
//    controller_hub->report_status();
//
//    sleep(3);
//    controller_hub->stop_controller("circle_example");
//    controller_hub->stop_controller("simple_example");
//
//    for (int i=0; i < 100 ; i++){
//        for (int j=0; j<4; j++)
//            std::cout << i << "cmds"<< j<<':' << cmds_pool[i].data[j] << '\n';
//    }
//
////    Safepilot<PosSetCmd, FullState> safepilot(100, &n, "PosSet", "FullState");
////    safepilot.run();
//    ros::spin();
//    delete controller_hub;
    return 0;

}

