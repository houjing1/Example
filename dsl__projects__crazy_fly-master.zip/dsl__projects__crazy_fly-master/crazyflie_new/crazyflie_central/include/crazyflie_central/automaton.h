/*
 * automaton.h
 *
 *  Created On : Mar 23, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_AUTOMATON_H
#define PROJECT_AUTOMATON_H

#include <string>
#include <iostream>

#include "crazyflie_central/status_group_struct.h"

#define EVENT_NUM 13

struct Events{
    Events():
            curr_state_valid(false),
            curr_cmd_valid(false),
            reached_takeoff_pos(false),
            touched_ground(false),
            takeoff_requested(false),
            hover_requested(false),
            land_requested(false),
            emergency_requested(false),
            custom_control_requested(false),
            assigned_task(false),
            connected(false),
            onboard_test_passed(false) {};
    union {
        bool flags[EVENT_NUM];
        struct{
            /* states and cmds */
            bool curr_state_valid;                      // state estimate is valid when it's recent
            bool curr_cmd_valid;                        // cmd is valid when it's recent and not dangerous
            bool reached_takeoff_pos;                // true when the vehicle reached the target height
            bool touched_ground;                        // true when the height of vehicle is close to 0

            /* user requests
             *      true when user pressed the corresponding button
             *      cleared out once the request is addressed
             */
            bool takeoff_requested;                     // true when user pressed takeoff button
            bool hover_requested;                       // true when user pressed hover button
            bool land_requested;                        // true when user pressed land button
            bool emergency_requested;                   // true when user pressed emergency button
            bool custom_control_requested;              // true when user started the custom controller

            /* assigned task */
            bool assigned_task;                         // true when allocated a task (e.g. someone want to test their custom controller)

            /* hardware */
            bool connected;                             // true when CrazyflieServer can find the vehicle at its radio address
            // and communicate with it
            bool onboard_test_passed;                   // true when the vehicle passed the onboard test
        };
    };

};

enum EventEnum {CurrStateValid, CurrCmdValid, ReachedTakeoffPOS, TouchedGround,
                 TakeoffRequested, HoverRequested, LandRequested, EmergencyRequested, CustomControlRequested,
                 AssignedTask,
                 Connected, OnboardTestPassed};

static std::string EventName[EVENT_NUM]{"CurrStateValid", "CurrCmdValid", "ReachedTakeoffPOS", "TouchedGround",
                                        "TakeoffRequested", "HoverRequested", "LandRequested", "EmergencyRequested", "CustomControlRequested",
                                        "AssignedTask",
                                        "Connected", "OnboardTestPassed"};

class Automaton{
public:
    Automaton(int ID, Events& events, VehicleStatus& status):
            _ID(ID),
            _events(events),
            _curr_status(status) {};

    /* make transition based on _events and _curr_status
     * always assume safer transition happened first (e.g. emergency happen before land when vehicle is in Hover mode)
     */
    void run();

private:
    int _ID;                        // drone_ID of the vehicle
    Events& _events;                // current events flag
    VehicleStatus& _curr_status;    // current status

};

#endif //PROJECT_AUTOMATON_H
