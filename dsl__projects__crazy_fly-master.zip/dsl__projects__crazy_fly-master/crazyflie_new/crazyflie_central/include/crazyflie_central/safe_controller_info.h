/*
 * safe_controller_info.h
 *
 *  Created On : Mar 27, 2018
 *      Author : Xintong Du
 */

#ifndef PROJECT_SAFE_CONTROLLER_INFO_H
#define PROJECT_SAFE_CONTROLLER_INFO_H


struct SafeControllerInfo{
    SafeControllerInfo(int id):
        ID(id),
        update_rate(100.0f),
        takeoff_speed(0.2f),
        landing_speed(0.2f) {};

    int ID;                                 // ID of the drone (start from 0)
    float update_rate;
    float takeoff_endpoint[3];              // takeoff target position (m)
    float takeoff_speed;                    // takeoff speed (m/s)

    float landing_speed;                    // landing speed (m/s)
};

#endif //PROJECT_SAFE_CONTROLLER_INFO_H
