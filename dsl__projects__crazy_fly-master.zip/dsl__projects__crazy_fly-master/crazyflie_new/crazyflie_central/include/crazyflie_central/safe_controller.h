/*
 * safe_controller.h
 *
 *  Created On : Feb 12, 2018
 *      Author : Xintong Du
 */

#ifndef PROJECT_SAFE_CONTROLLER_H
#define PROJECT_SAFE_CONTROLLER_H

#define THRUST_SCALE 1000.0f
#define THRUST_BASE 36000.0f
#define THRUST_MIN 20000.0f

#include <cmath>
#include <vector>

#include "ros/ros.h"
#include "crazyflie_central/pid.hpp"
#include "crazyflie_control/controller_base.h"


float get (ros::NodeHandle n, std::string name) {
    /*
     * read values from rosparam server and return its value
     */
    float param_value;
    n.getParam(name, param_value);
    return param_value;
}

template <typename cmdType, typename stateType>
class SafeControllerBase{
public:
    SafeControllerBase(int drone_num, std::vector<stateType>* states_pool);

    virtual ~SafeControllerBase() {};
    /* Get control inputs for specific vehicles
     *
     * args:
     *          states: current states of all vehicle
     *          object_IDs: IDs of vehicles queried for safe control cmds
     *          cmds: cmds for queried vehicles, in the same order as object_IDs.
     *
     * NOTE:
     *          Assume vehicle ID as index
     *
     * */
    virtual void control(std::vector<int> object_IDs,
                         std::vector<cmdType>* cmds) = 0;
    void update_flags(std::vector<int> object_IDs);
    void resetAllPIDs (int index);
    float calc_transient_height(float curr_height,
                                float target_height);

    std::vector<stateType>* curr_states;
    std::vector<cmdType>* curr_cmds;
    int num_drones;
    int update_rate; //Rate to compute takeoff and landing feedback trajectory commands

    /*
     * Static variables of class creates only one instance of variable
     * i.e: just a set of PID controllers for each vehicle, to be used by all SafeControllers
     */
    static std::vector<PID> pidX;
    static std::vector<PID> pidY;
    static std::vector<PID> pidZ;
    static std::vector<PID> pidVX;
    static std::vector<PID> pidVY;
    static std::vector<PID> pidVZ;

    std::vector<float> init_flag; // Flag to (re)initialize land or hover coordinates
    ros::NodeHandle nh;

    static std::vector<float> _init_x;
    static std::vector<float> _init_y;
};

/*
 * Templated static members of a class need to be provided a definition
 * This ends up creating different static members for each parameterization of the template
 * i.e: different PID vectors for PosSet mode and AltHold mode
 */

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidX;

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidY;

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidZ;

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidVX;

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidVY;

template <typename cmdType, typename stateType>
std::vector<PID> SafeControllerBase<cmdType, stateType>::pidVZ;

template <typename cmdType, typename stateType>
std::vector<float> SafeControllerBase<cmdType, stateType>::_init_x;

template <typename cmdType, typename stateType>
std::vector<float> SafeControllerBase<cmdType, stateType>::_init_y;

template <typename cmdType, typename stateType>
SafeControllerBase<cmdType, stateType>::SafeControllerBase(int drone_num, std::vector<stateType> *states_pool):
        update_rate(100),
        num_drones(drone_num),
        curr_states(states_pool){

    for(int i = 0 ; i < drone_num; i++)
        init_flag.push_back(false); // allocate memory for all drones

    //Initialize the PIDs for all drones, grabbing the config from pid.yaml
    if (pidX.size()== 0) {
        PID pidx(get(nh, "PIDs/X/kp"),
                 get(nh, "PIDs/X/kd"),
                 get(nh, "PIDs/X/ki"),
                 get(nh, "PIDs/X/minOutput"),
                 get(nh, "PIDs/X/maxOutput"),
                 get(nh, "PIDs/X/iLimit"));

        PID pidy(get(nh, "PIDs/Y/kp"),
                 get(nh, "PIDs/Y/kd"),
                 get(nh, "PIDs/Y/ki"),
                 get(nh, "PIDs/Y/minOutput"),
                 get(nh, "PIDs/Y/maxOutput"),
                 get(nh, "PIDs/Y/iLimit"));

        PID pidz(get(nh, "PIDs/Z/kp"),
                 get(nh, "PIDs/Z/kd"),
                 get(nh, "PIDs/Z/ki"),
                 get(nh, "PIDs/Z/minOutput"),
                 get(nh, "PIDs/Z/maxOutput"),
                 get(nh, "PIDs/Z/iLimit"));

        PID pidvx(get(nh, "PIDs/VX/kp"),
                  get(nh, "PIDs/VX/kd"),
                  get(nh, "PIDs/VX/ki"),
                  get(nh, "PIDs/VX/minOutput"),
                  get(nh, "PIDs/VX/maxOutput"),
                  get(nh, "PIDs/VX/iLimit"));

        PID pidvy(get(nh, "PIDs/VY/kp"),
                  get(nh, "PIDs/VY/kd"),
                  get(nh, "PIDs/VY/ki"),
                  get(nh, "PIDs/VY/minOutput"),
                  get(nh, "PIDs/VY/maxOutput"),
                  get(nh, "PIDs/VY/iLimit"));

        PID pidvz(get(nh, "PIDs/VZ/kp"),
                  get(nh, "PIDs/VZ/kd"),
                  get(nh, "PIDs/VZ/ki"),
                  get(nh, "PIDs/VZ/minOutput"),
                  get(nh, "PIDs/VZ/maxOutput"),
                  get(nh, "PIDs/VZ/iLimit"));

        for (int i = 0; i < num_drones; i++) {
            pidX.push_back(pidx);
            pidY.push_back(pidy);
            pidZ.push_back(pidz);
            pidVX.push_back(pidvx);
            pidVY.push_back(pidvy);
            pidVZ.push_back(pidvz);
        }
    }
    /*
* Routine to read and store initial XY positions of drones from yaml file
* Later they will be used as the takeoff coordinates
*/

    XmlRpc::XmlRpcValue init_pos;
    nh.getParam("vehicles/init_pos", init_pos);

    for (int i = 0; i < drone_num; ++i){
        if (i < init_pos.size()){
            _init_x.push_back((float)static_cast<double>(init_pos[i][0]));
            _init_y.push_back((float)static_cast<double>(init_pos[i][1]));
        }
        else{
            ROS_WARN_STREAM("[Pilot Handbook]: Did not specify init pos for Drone" << i+1);
            _init_x.push_back(0.0);
            _init_y.push_back(0.0);
        }
    }
}

/*
 * Definition of children classes from SafeController Base: SafeControllers
 */

template <typename cmdType, typename stateType>
class SafeTakeoff : public SafeControllerBase<cmdType, stateType>{
public:
    SafeTakeoff(int drone_num, std::vector<stateType>* states_pool) :
            SafeControllerBase<cmdType, stateType>(drone_num, states_pool),
            _takeoff_speed(0.4),
            _takeoff_acc(1.0),
            _takeoff_height(1.5),
            _transient_height(drone_num, 0),
            _transient_velocity(drone_num,0) {};
    ~SafeTakeoff() {};

    void control(std::vector<int> object_IDs,
                 std::vector<cmdType>* cmds);

private:

    float _takeoff_speed;
    float _takeoff_acc;
    float _takeoff_height; //fixed takeoff height, currently the same for each drone
    std::vector<float> _transient_height; //variable for altitude command at current time step
    std::vector<float> _transient_velocity;
};

template <typename cmdType, typename stateType>
class SafeHover : public SafeControllerBase<cmdType, stateType>{
public:
    SafeHover(int drone_num, std::vector<stateType>* states_pool) :
            SafeControllerBase<cmdType, stateType>(drone_num, states_pool)
    {
        //initialize vectors containing hover commands
        for(int i = 0 ; i < drone_num; i++){
            _hover_x.push_back(0.0);
            _hover_y.push_back(0.0);
            _hover_z.push_back(0.0);
        }
    };
    ~SafeHover() {};

    void control(std::vector<int> object_IDs,
                 std::vector<cmdType>* cmds);

private:
    std::vector<float> _hover_x;
    std::vector<float> _hover_y;
    std::vector<float> _hover_z;
};

template <typename cmdType, typename stateType>
class SafeLand : public SafeControllerBase<cmdType, stateType>{
public:
    SafeLand(int drone_num, std::vector<stateType>* states_pool) :
            SafeControllerBase<cmdType, stateType>(drone_num, states_pool),
            _landing_speed(0.3),
            _landing_acc(1.0),
            _transient_height(drone_num, 0),
            _transient_velocity(drone_num, 0),
            _land_x(drone_num, 0),
            _land_y(drone_num, 0),
            _land_z(drone_num, 0) {};
    ~SafeLand() {};

    void control(std::vector<int> object_IDs,
                 std::vector<cmdType>* cmds);

private:
    float _landing_speed;
    float _landing_acc;
    std::vector<float> _land_x;
    std::vector<float> _land_y;
    std::vector<float> _land_z;
    std::vector<float> _transient_height; //variable for altitude command at current time step
    std::vector<float> _transient_velocity;
};

template <typename cmdType, typename stateType>
class SafeIdle : public SafeControllerBase<cmdType, stateType>{
public:
    SafeIdle(int drone_num, std::vector<stateType>* states_pool) :
            SafeControllerBase<cmdType, stateType>(drone_num, states_pool),
            _idle_x(drone_num, 0),
            _idle_y(drone_num, 0) {};
    ~SafeIdle() {};

    void control(std::vector<int> object_IDs,
                 std::vector<cmdType>* cmds);
private:
    std::vector<float> _idle_x;
    std::vector<float> _idle_y;
};

/*
 * Functions from Base Class
 */

template <typename cmdType, typename stateType>
float SafeControllerBase<cmdType, stateType>::calc_transient_height(float curr_height, float target_height){
    /*
     * Feedback controller to determine next altitude command based on current and desired height
     */

    float kp = 0.25; // proportional gain
    float error = target_height - curr_height; //compute altitude error
    return (kp*error/update_rate); //return a value to be assigned to transient_height
};

template <typename cmdType, typename stateType>
void SafeControllerBase<cmdType, stateType>::update_flags(std::vector<int> object_IDs){
    /*
     * Logic to manage asynchronous entry and reentry to Safe controllers
     *
     * Case 1: Drone i not initialized for controller X, ID is present in object_IDs
     *         -> Set to True its flag, perform init task, e.g, set land or hover coordinates
     *
     * Case 2: Drone i already initialized for controller X, ID is still present in object_IDs
     *          -> Leave the flag as True, do not perform init task
     *
     * Case 3: Drone i was initialized for controller X, but ID has disappeared from object_IDs
     *          -> Set flag now to False (upon reentry to Controller X, lands on Case 1)
     *
     * NOTE: Each controller is responsible for setting the init_flag[i] to True once the
     *       initialization procedure has been completed for Drone i.
     */

    std::vector<int>::iterator it;
    std::vector<bool> current_init ((unsigned long)num_drones,false);

    // Set the values to one on the position of the ID's currently being controlled
    for(it=object_IDs.begin(); it!=object_IDs.end(); it++)
        current_init[*it] = true;

    //Update the values on the init_flag
    for (int i = 0; i < current_init.size(); ++i)
        init_flag[i] = init_flag[i] && current_init[i];
};

template <typename cmdType, typename stateType>
void SafeControllerBase <cmdType, stateType>::resetAllPIDs(int index) {
    /*
     * Reset all the PIDs for the i-th drone
     */

    pidX[index].reset();
    pidY[index].reset();
    pidZ[index].reset();
    pidVX[index].reset();
    pidVY[index].reset();
    pidVZ[index].reset();
}

/*
 * TAKEOFF CONTROLLERS
 */

template<>
void SafeTakeoff<PosSetCmd, FullState>::control(std::vector<int> object_IDs, std::vector<PosSetCmd>* cmds){
    PosSetCmd takeoff_cmd{}; // empty command to be filled
    float current_height;
    takeoff_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    // Iterate through all drones that require take off
    for(it=object_IDs.begin(); it!=object_IDs.end(); it++){

        current_height = curr_states->at(*it).z; //get altitude of i-th drone

        if (!init_flag[*it]){ //(re)entry first iteration -> reset all PIDs
            init_flag[*it] = true;
            // TODO: Should take velocity into account
            _transient_height[*it] = current_height;
        }

        float dist = std::pow(std::pow(_transient_height[*it] - _takeoff_height, 2), 0.5);
        if (dist >= 0.05f){
            _transient_height[*it] += _takeoff_speed / update_rate;
        }
        else
            _transient_height[*it] = _takeoff_height;

        takeoff_cmd.x = _init_x.at(*it);
        takeoff_cmd.y = _init_y.at(*it);
        takeoff_cmd.z = _transient_height[*it];
        cmds->push_back(takeoff_cmd);
    }
};

template<>
void SafeTakeoff<AltHoldCmd, FullState>::control(std::vector<int> object_IDs, std::vector<AltHoldCmd>* cmds){
    AltHoldCmd takeoff_cmd{}; // empty command to be filled
    float vx_desired;
    float vy_desired;
    float vz_desired;
    float y_acc_des;
    float x_acc_des;
    float yaw_measured = 0.0; //currently not measured form onboard IMU
    float thrust_desired;
    float thrust_raw;
    takeoff_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++){
        if (!init_flag[*it]){ //(re)entry first iteration -> reset all PIDs
            resetAllPIDs(*it);
            init_flag[*it] = true;
            std::cout << "Resetting PID and initializing Takeoff for Drone #" << (*it) << '\n';
        }

        //Update setpoints
        if (_transient_velocity[*it] > _takeoff_speed)
            _transient_velocity[*it] = _takeoff_speed;
        else _transient_velocity[*it] += _takeoff_acc / update_rate;

        _transient_height[*it] += _transient_velocity[*it] / update_rate;

        if (_transient_height[*it] >= _takeoff_height-0.05)
            _transient_height[*it] = _takeoff_height;

        //Compute controls based on PID
        vx_desired = pidX[*it].update(curr_states->at(*it).x,_init_x[*it]);
        vy_desired = pidY[*it].update(curr_states->at(*it).y,_init_y[*it]);
        vz_desired = pidZ[*it].update(curr_states->at(*it).z,_transient_height[*it]);

        x_acc_des  = pidVX[*it].update(curr_states->at(*it).vx,vx_desired);
        y_acc_des  = pidVY[*it].update(curr_states->at(*it).vy,vy_desired);
        thrust_raw = pidVZ[*it].update(curr_states->at(*it).vz,vz_desired);
        thrust_desired = thrust_raw*THRUST_SCALE + THRUST_BASE;

        //Rotate roll and pitch commands by the yaw angle
        takeoff_cmd.roll = -(y_acc_des*cos(yaw_measured)) + (x_acc_des*cos(yaw_measured)) ;
        takeoff_cmd.pitch = (x_acc_des*cos(yaw_measured)) + (y_acc_des*sin(yaw_measured));
        takeoff_cmd.thrust = vz_desired;

        //Update the cmds
        cmds->push_back(takeoff_cmd);
    }
};

/*
 * LANDING CONTROLLERS
 */

template<>
void SafeLand<PosSetCmd, FullState>::control(std::vector<int> object_IDs, std::vector<PosSetCmd>* cmds){
    PosSetCmd land_cmd{};
    float current_height; // altitude of i-th drone
    land_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++) {
        current_height = curr_states->at(*it).z;

        if (!init_flag.at(*it)){ //(re)entry first iteration -> lock landing coordinates
            _land_x[*it] = curr_states->at(*it).x;
            _land_y[*it] = curr_states->at(*it).y;
            // TODO: Should take velocity into account
            _transient_height[*it] = current_height;
            init_flag[*it] = true;
            std::cout << "Setting Landing coordinates for Drone #" << (*it) << '\n';
        }

        if (std::abs(_transient_height[*it]) > 0.05)
            _transient_height[*it] -= _landing_speed / update_rate;

        else {
            _transient_height[*it] = 0.0;
        }

        land_cmd.x = _land_x[*it];
        land_cmd.y = _land_y[*it];
        land_cmd.z = _transient_height[*it];
        cmds->push_back(land_cmd);
    }
};

template<>
void SafeLand<AltHoldCmd, FullState>::control(std::vector<int> object_IDs, std::vector<AltHoldCmd>* cmds){
    AltHoldCmd land_cmd{};
    float vx_desired;
    float vy_desired;
    float vz_desired;
    float y_acc_des;
    float x_acc_des;
    float yaw_measured = 0.0; //currently not measured form onboard IMU
    float thrust_desired;
    float thrust_raw;
    land_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;
    for(it=object_IDs.begin(); it!=object_IDs.end(); it++) {
        if (!init_flag[*it]){ //(re)entry first iteration -> lock landing coordinates
            _land_x[*it] = curr_states->at(*it).x;
            _land_y[*it] = curr_states->at(*it).y;
            init_flag[*it] = true;
            std::cout << "Setting Landing coordinates for Drone #" << (*it) << '\n';
        }

        //Update setpoints
        if (_transient_velocity[*it] < -_landing_speed)
            _transient_velocity[*it] = -_landing_speed;
        else _transient_velocity[*it] -= _landing_acc / update_rate;

        _transient_height[*it] += _transient_velocity[*it] / update_rate;

        //Compute controls based on PID
        vx_desired = pidX[*it].update(curr_states->at(*it).x,_land_x[*it]);
        vy_desired = pidY[*it].update(curr_states->at(*it).y,_land_y[*it]);
        vz_desired = pidZ[*it].update(curr_states->at(*it).z,_transient_height[*it]);

        x_acc_des  = pidVX[*it].update(curr_states->at(*it).vx,vx_desired);
        y_acc_des  = pidVY[*it].update(curr_states->at(*it).vy,vy_desired);
        thrust_raw = pidVZ[*it].update(curr_states->at(*it).vz,vz_desired);
        thrust_desired = thrust_raw*THRUST_SCALE + THRUST_BASE;

        //Rotate roll and pitch commands by the yaw angle
        land_cmd.roll = -(y_acc_des*cos(yaw_measured)) + (x_acc_des*cos(yaw_measured));
        land_cmd.pitch = (x_acc_des*cos(yaw_measured)) + (y_acc_des*sin(yaw_measured));
        land_cmd.thrust = vz_desired;

        //Update the cmds
        cmds->push_back(land_cmd);
    }
};

/*
 * HOVER CONTROLLERS
 */

template<>
void SafeHover<PosSetCmd, FullState>::control(std::vector<int> object_IDs, std::vector<PosSetCmd>* cmds){
    PosSetCmd hover_cmd{};
    hover_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++) {
        if (!init_flag[*it]){ //(re)entry first iteration -> lock hover coordinates
            _hover_x[*it] = curr_states->at(*it).x;
            _hover_y[*it] = curr_states->at(*it).y;
            // TODO: Should take velocity into account
            _hover_z[*it] = curr_states->at(*it).z;
            init_flag[*it] = true;
//            std::cout << "Setting Hover coordinates for Drone #" << (*it) << '\n';
        }

        hover_cmd.x = _hover_x[*it];
        hover_cmd.y = _hover_y[*it];
        hover_cmd.z = _hover_z[*it];
        cmds->push_back(hover_cmd);
    }
};

template<>
void SafeHover<AltHoldCmd, FullState>::control(std::vector<int> object_IDs, std::vector<AltHoldCmd>* cmds){
    AltHoldCmd hover_cmd{};
    float vx_desired;
    float vy_desired;
    float vz_desired;
    float y_acc_des;
    float x_acc_des;
    float yaw_measured = 0.0; //currently not measured form onboard IMU
    float thrust_desired;
    float thrust_raw;
    hover_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++) {
        if (!init_flag[*it]){ //(re)entry first iteration -> lock hover coordinates
            _hover_x[*it] = curr_states->at(*it).x;
            _hover_y[*it] = curr_states->at(*it).y;
            _hover_z[*it] = curr_states->at(*it).z;
            init_flag[*it] = true;
//            std::cout << "Setting Hover coordinates for Drone #" << (*it) << '\n';
        }

        //Compute controls based on PID
        vx_desired = pidX[*it].update(curr_states->at(*it).x,_hover_x[*it]);
        vy_desired = pidY[*it].update(curr_states->at(*it).y,_hover_y[*it]);
        vz_desired = pidZ[*it].update(curr_states->at(*it).z,_hover_z[*it]);

        x_acc_des  = pidVX[*it].update(curr_states->at(*it).vx,vx_desired);
        y_acc_des  = pidVY[*it].update(curr_states->at(*it).vy,vy_desired);
        thrust_raw = pidVZ[*it].update(curr_states->at(*it).vz,vz_desired);
        thrust_desired = thrust_raw*THRUST_SCALE + THRUST_BASE;

        //Rotate roll and pitch commands by the yaw angle
        hover_cmd.roll = -(y_acc_des*cos(yaw_measured)) + (x_acc_des*cos(yaw_measured));
        hover_cmd.pitch = (x_acc_des*cos(yaw_measured)) + (y_acc_des*sin(yaw_measured));
        hover_cmd.thrust = vz_desired;

        //Update the cmds
        cmds->push_back(hover_cmd);
    }
};

/*
 * IDLE CONTROLLERS
 */

template<>
void SafeIdle<PosSetCmd, FullState>::control(std::vector<int> object_IDs, std::vector<PosSetCmd>* cmds){
    PosSetCmd idle_cmd{};
    idle_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++){
        if (!init_flag[*it]){ //(re)entry first iteration -> lock idle coordinates
            _idle_x[*it] = curr_states->at(*it).x;
            _idle_y[*it] = curr_states->at(*it).y;
            init_flag[*it] = true;
//            std::cout << "Setting Hover coordinates for Drone #" << (*it) << '\n';
        }

        idle_cmd.x = _idle_x[*it];
        idle_cmd.y = _idle_y[*it];
        idle_cmd.z = 0.0;
        cmds->push_back(idle_cmd);
    }
};

template<>
void SafeIdle<AltHoldCmd, FullState>::control(std::vector<int> object_IDs, std::vector<AltHoldCmd>* cmds){
    AltHoldCmd idle_cmd{};
    idle_cmd.time_stamp = ros::Time::now(); // time stamp
    std::vector<int>::iterator it;

    for(it=object_IDs.begin(); it!=object_IDs.end(); it++){

        idle_cmd.pitch = 0.0;
        idle_cmd.roll = 0.0;
        idle_cmd.yaw = 0.0;
        idle_cmd.thrust = 0.0;
        cmds->push_back(idle_cmd);
    }
};

#endif //PROJECT_SAFE_CONTROLLER_H
