/*
 * safepilot.h
 *
 *  Created on : Feb 10, 2018
 *       Author: Xintong Du
 */

#ifndef PROJECT_SAFEPILOT_H
#define PROJECT_SAFEPILOT_H

#include <cmath>

#include "ros/callback_queue.h"
#include "ros/ros.h"
#include "crazyflie_comm/crazyflie_server.h"
#include "crazyflie_control/controller_example.h"
#include "crazyflie_control/controller_hub.h"
#include "crazyflie_central/FSM.h"
#include "crazyflie_central/pilot_handbook_dec.h"
#include "crazyflie_central/pilot_handbook.h"
#include "crazyflie_central/safe_controller.h"

#include "crazyflie_estimator/SwarmStates.h"
#include "crazyflie_central/AddController.h"
#include "crazyflie_central/Cmd.h"
#include "crazyflie_central/CustomControl.h"
#include "crazyflie_central/RequestSafeConduct.h"
#include "crazyflie_central/SwarmCmds.h"
#include "crazyflie_central/VehicleStatus.h"
#include "crazyflie_central/VehicleStatusEnum.h"

#define ESTIMATES_TIMEOUT 0.5   // state estimates time out (s)
#define COMMANDS_TIMEOUT 1.0    // commands time out (s)
#define TAKEOFF_POS_TOLERANCE 0.06  // tolerance on take off height (m)
#define LAND_HEIGHT_TOLERANCE 0.04     // tolerance on

class Safepilot{
public:
    Safepilot(int drone_num, ros::NodeHandle* nh);

    ~Safepilot();

    /** main loop of Safepilot
     *
     * -# Get commands for drones at Custom Control mode from _curr_custom_cmds_XXX
     * -# Perform safety check:
     *     -# is state estimates valid?
     *     -# is drone close to takeoff point?
     *     -# did drone touch the ground?
     *     -# is cmd(regardless of custom cmds or safe cmds) valid?
     * -# Ask FSM to update
     * -# Fetch safe cmds for drones in Idle, Takeoff, Hover, Land
     * -# Publish cmds as ROS topic and ask CrazyflieServer to send data onboard
     * */
    void run();

private:
    /* ROS related member */
    ros::NodeHandle* _nh;                   /**< node handle with fast queue */
    ros::NodeHandle* _nh_slow;              /**< node handle with slow queue */
    ros::CallbackQueue _slow_queue;         /**< slow queue is used to address user requests (low priority) */
    ros::CallbackQueue _fast_queue;         /**< fast queue is used to receive estimates (high priority) */
    ros::AsyncSpinner _spinner;             /**< spinner for fast queue to allow high priority callbacks to be addressed in parallel */

    /* Publisher */
    ros::Publisher _pub_cmds;               /** publish cmds of all drones regardless of its cmd group */

    /* Subscriber */
    ros::Subscriber _sub_FullState;         /** subscribe estimates of FullState */

    /* Subscription Callback Functions */
    void _cb_FullState(const crazyflie_estimator::SwarmStates msg);

    /* Services */
    ros::ServiceServer _srv_add_controller; /**< add custom controller to Controller Hub */
    ros::ServiceServer _srv_safe_conduct;   /**< request Hover, Takeoff, Land, Emergency safe controller to take over */
    ros::ServiceServer _srv_custom_control; /**< request to start stop and pause custom controller */
    ros::ServiceServer _srv_perf_monitor;   /**< request to check the current status of all perf count */

    /* Service Callback Functions */

    /** Add Custom Controller to Controller Hub, and
     *  Get safe controllers ready to assist the Custom Controller, and
     *  Get drone ready to fly
     *
     * iff
     *      - Controller Info (e.g. specified in controller_param_example.yaml) is valid
     *      - Command and State group required by this controller is supported by Safepilot
     *      - Requested Custom Controller exists
     *
     * @param req crazyflie_central::AddController controller_name, controller's name
     * @param res success, true if controller is added to the Controller Hub
     * */
    bool _add_custom_controller(crazyflie_central::AddController::Request &req,
                                crazyflie_central::AddController::Response &res);

    /** Set user request event flag for a group of vehicle
     *  Whether request is taken or not depends on vehicles' current status
     *
     *      args:
     *          req arg: action_ID, as defined in EventEnum in automaton.h
     *                   drone_ID, ID of drones
     *          req arg: success, true if even flag has been set
     */
    bool _cb_safe_conduct(crazyflie_central::RequestSafeConduct::Request &req,
                       crazyflie_central::RequestSafeConduct::Response &res);

    /** Address custom controler requests, start, stop, and pause custom controllers
     *  And set relevant event flags
     *
     *      args:
     *          req arg: controller_name, name of the controller
     *                   target_status_ID, as defined in ControllerStatus in controller_info.h
     *          res arg: srv_res, 0 if request is successfully addressed
     */
    bool _cb_custom_control(crazyflie_central::CustomControl::Request &req,
                            crazyflie_central::CustomControl::Response &res);

    /** Ask PerfMonitor to print all registered perf_count
     */
    bool _cb_perf_monitor(std_srvs::EmptyRequest &req, std_srvs::EmptyResponse &res);

    /** Timer */
    ros::Timer _slow_queue_timer;                                /**< timer for slow queue */

    /* Timer Cb */
    void _cb_slow_queue_timer(const ros::TimerEvent& event);

    /** Featured member */
    int _drone_num;                                               /**< Total number of drones */
    bool _simulation;                                             /**< indicator for simulation mode */

    std::vector<PosSetCmd> _curr_custom_cmds_PosSet;              /**< cmds updated by custom controllers */
    std::vector<AltHoldCmd> _curr_custom_cmds_AltHold;            /**< cmds updated by custom controlles */

    std::vector<crazyflie_central::Cmd> _next_cmds;               /**< next cmds to be sent */
    std::vector<FullState> _curr_states_FullState;                /**< current states (FullState), read from ROS topic */
    std::vector<bool> _curr_states_feasibility;                   /**< feasibility of current estimates*/
    std::vector<std::vector<float>> _takeoff_endpoint;

    FSM _fsm;                                                     /**< Finite State Machine: manage all vehicle's status */
    PilotHandbookDec _pilot_handbook;                             /**< Pilot Handbook: has safe controllers */
    CrazyflieServer _comm_server;                                 /**< Communication server */

    ControllerHub _controller_hub;                                /**< Custom Controller Hub: manage all custom controllers */
    PerfCounterBase* _perf_vicon;                                 /**< Performance monitor: track the interval between two consequtive topics */
    PerfCounterBase* _perf_run;                                   /**< Performance monitor: track the interval between two consequtive topics */

    struct SafepilotInfo{
        SafepilotInfo() :
                controllers(){};
        std::vector<std::string> controllers;
    } _pilot_info;

    /** Perform Safety Check and set event flag in automaton accordingly
     *  For each vehicle, check
     *      - if estimate is valid
     *      - if it reached take off height, touched the ground
     *      - if cmd is valid
     *
     * For now,
     *      estimate is valid if it's reasonably recent
     *      cmd is valid if it's reasonably recent
     *      TODO: we could add more criteria for a valid cmd. It could apply to all vehicles or specifically to a Custom Controller
     *
     * */
    void _auto_safety_check();

    /** Copy custom cmds of all command group safely from _curr_custom_cmds_XXX to _next_cmds
     *
     * NOTE:
     *          Two mutex used:
     *          g_cmds_low_prio_mutex is to prioritize Safepilot's reading over custom controllers' writing
     *          g_cmds_mutex pretects the shared data, _curr_custom_cmds
     *
     *          Idea on using mutex to give thread different level of priority is taken from here
     *          https://en.wikipedia.org/wiki/Readers%E2%80%93writers_problem
     *
     */
    void _read_custom_cmds();

    /** Collect cmds for activated drones (i.e. drones are not in sleep or init)
     * Publish the data as ROS topic
     * Ask CrazyflieServer to send data onboard if not in simulation mode
     *
     *
     */
    void _send_cmds();

    /** Helper function to load paramerter from ROS environment */
    void _get_params();

    /** Check if user inputs ID valid. ID starts from 0.
     *
     * NOTE:
     *      Within the code, we follow the convention that ID starts from 0.
     *      Any ID came as user input (e.g. drone_ID specified in controller_param_example.yaml), we assume it starts from 1.
     */
    bool _check_drone_ID_valid(std::vector<int> query_ID);

    /** Initialize cmds states vector for a particular command state group
     *
     */
    void _init_curr_cmds_states(CmdStatePair pair);

    /** Read controller info from ROS parameters and check if all required fields are set
     *
     *      args:
     *              controller_name: name of the controller
     *              param: write destination
     *
     *      return:
     *              true if all params are set
     *              false if there are some missing parameters
     */
    bool _get_controller_param(std::string controller_name, XmlRpc::XmlRpcValue* param);
};


#endif //PROJECT_SAFEPILOT_H
