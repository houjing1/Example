//#pragma once
//
//#include "ros/ros.h"
//
//#define DEFAULT_PID_ILIMIT 5000.0f
//#define DEFAULT_PID_OUTPUT_LIMIT 0.0f
//
//struct PIDParam{
//    float kp;
//    float kd;
//    float ki;
//    float minOutput;
//    float maxOutput;
//    float iLimit;
//};
//
//class PID
//{
//public:
//    PID(PIDParam param)
//        : m_kp(param.kp)
//        , m_kd(param.kd)
//        , m_ki(param.ki)
//        , m_minOutput(param.minOutput)
//        , m_maxOutput(param.maxOutput)
//        , m_integratorMin(-param.iLimit)
//        , m_integratorMax(param.iLimit)
//        , m_integral(0)
//        , m_previousError(0)
//        , m_previousTime(0)
//    {
//    }
//
//    void reset()
//    {
//        m_integral = 0;
//        m_previousError = 0;
//        m_previousTime = ros::Time::now();
//    }
//
//    void setIntegral(float integral)
//    {
//        m_integral = integral;
//    }
//
//    float ki() const
//    {
//        return m_ki;
//    }
//
//    void setOutputLimit (float limit)
//    {
//        m_minOutput = -limit;
//        m_maxOutput = limit;
//    }
//
//    float update(float value, float targetValue)
//    {
//        ros::Time time = ros::Time::now();
//        float dt = time.toSec() - m_previousTime.toSec();
//
//        if(dt < 1e-3f)
//            dt = 1e-3f;
//        else if(dt > 0.1f)
//            dt = 0.1f;
//
//        float error = targetValue - value;
//        m_integral += error * dt;
//        m_integral = std::max(std::min(m_integral, m_integratorMax), m_integratorMin);
//        float p = m_kp * error;
//        float d = m_kd * (error - m_previousError) / dt;
//        float i = m_ki * m_integral;
//        float output = p + d + i;
//        m_previousError = error;
//        m_previousTime = time;
//        return std::max(std::min(output, m_maxOutput), m_minOutput);
//    }
//
//private:
//    float m_kp;
//    float m_kd;
//    float m_ki;
//    float m_minOutput;
//    float m_maxOutput;
//    float m_integratorMin;
//    float m_integratorMax;
//    float m_integral;
//    float m_previousError;
//    ros::Time m_previousTime;
//};
