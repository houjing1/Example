//
// Created by tracy on 27/03/18.
//

#ifndef PROJECT_PILOT_HANDBOOK_DEC_H
#define PROJECT_PILOT_HANDBOOK_DEC_H

#include <vector>
#include <map>

#include "ros/ros.h"
#include "crazyflie_central/FSM.h"
#include "crazyflie_central/safe_controller_info.h"
#include "crazyflie_central/safe_controller_dec.h"
#include "crazyflie_control/controller_info.h"
#include "crazyflie_control/states_cmds_types.h"
#include "crazyflie_central/Cmd.h"
#include "crazyflie_utility/container_stream.h"

class PilotHandbookDec{
public:
    PilotHandbookDec(ros::NodeHandle& nh):
            _nh(nh) {};

    ~PilotHandbookDec(){
        for(std::map<int, SafeController*>::iterator it=_controllers.begin() ; it!=_controllers.end(); ++it)
            delete it->second;
    };

    /* Get safe commands for all vehicles in profile
     *
     *      1) get from FSM the current command group for queried drones
     *      2) ask _controllers to write into cmds_pool
     *
     *      args:
     *          status_pool: records of all vehicles' status in FSM
     *          states_pool: records of all vehicles' states in safepilot
     *          cmds_pool: records of all vehicles' cmds in safepilot
     *
     */
    void getCommands(const std::vector<VehicleStatus>& status_pool, const std::vector<FullState>& states_pool, std::vector<crazyflie_central::Cmd>& cmds_pool);

    /* Add a group of vehicles into profile
     *
     *
     *      args:
     *          info: safe controller information for each vehicles
     *
     *
     *      NOTE:
     *          we assume info has been proof read and hence are valid
     *          we ignore drones that have been added to pilot handbook
     */
    void addVehicles(const std::vector<SafeControllerInfo>& info);

    /* Remove vehicles that no longer needs safe commands (typically, the ones that are in Sleep/Init)
     *
     */
    void removeVehicles(const std::vector<int> drone_ID);



private:
    ros::NodeHandle& _nh;                                // node handle to load parameters and/or publish handbook current status
    std::map<int, SafeController*> _controllers;         // a map from ID to controllers

};
#endif //PROJECT_PILOT_HANDBOOK_DEC_H
