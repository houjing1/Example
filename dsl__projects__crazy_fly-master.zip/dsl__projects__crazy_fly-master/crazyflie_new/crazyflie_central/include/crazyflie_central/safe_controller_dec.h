/*
 * safe_controller_dec.h
 *
 *  Created On : Mar 27, 2018
 *      Author : Xintong Du
 */

#ifndef PROJECT_SAFE_CONTROLLER_DEC_H
#define PROJECT_SAFE_CONTROLLER_DEC_H

#include "crazyflie_central/automaton.h"
#include "crazyflie_central/safe_controller_info.h"
#include "crazyflie_control/states_cmds_types.h"

#define X 0
#define Y 1
#define Z 2
/* Decentralized Safe Controllers for each Vehicle
 *
 * Safe Controllers will only send PosSetCmd. It relies on vehicles to be able to swicth cmd type in flight.
 *
 */

class SafeController{
public:
    SafeController(const SafeControllerInfo& info) :
            _info(info),
            _takeoff_sp{0},
            _land_sp{0},
            _hover_sp{0},
            _idle_sp{0},
            _emergency_sp{0},
            _last_status{Init} {};
    /* Get the next safe commands based on the current status, state.
     *
     *      args:
     *          curr_status: current status. Only Takeoff Land Hover and Idle will get the next cmd. If it's in Custom-
     *                       Control mode, then only update _last_status
     *          curr_state:  current state estimates. Assume to be FullState since only needs pisition estimates.
     *                 cmd:  cmd for the next time step
     */
    void getCommand(VehicleStatus curr_status, const FullState& curr_state, PosSetCmd& cmd);

private:
    SafeControllerInfo _info;

    /* Position setpoints */
    float _takeoff_sp[3];
    float _land_sp[3];
    float _hover_sp[3];
    float _idle_sp[3];
    float _emergency_sp[3];

    /* Helper Variable*/
    float _takeoff_dir[3];

    VehicleStatus _last_status;

    /* Planners */

    /** Safe controller for take off
     *
     * Update _takeoff_sp by moving it up at _info.takeoff_speed
     * Fix _takeoff_sp at _info.takeoff_height when vehicle is close
     *
     *      args:
     *          curr_state: current states
     *          init: initialize _takeoff_sp with curr_state if true
     */
    void _takeoff(const FullState& curr_state, bool init);

    /** Safe controller for land
     *
     * Update _land_sp by moving it down at _info.landing_speed
     * Fix _land_sp[Z] at 0 if clost to ground
     *
     *      args:
     *          curr_state: current states
     *          init: Initialize _land_sp with curr_state if true
     *
     */
    void _land(const FullState& curr_state, bool init);

    /** Safe controller for hover
     *
     * Fix _land_sp at one point to make the vehicle hover
     *
     *      args:
     *          curr_state: current states
     *          init: Initialize _hover_sp with curr_state if true
     *
     */
    void _hover(const FullState& curr_state, bool init);

    /** Safe controller for idle
     *
     * Fix _land_sp at one point and set _land_sp[Z] as 0 to lock the thrust
     *
     *      args:
     *          curr_state: current states
     *          init: Initialize _land_sp with curr_state if true
     *
     */
    void _idle(const FullState& curr_state, bool init);

    /** Safe controller for emergency
     *
     */
    void _emergency(const FullState& curr_state, bool init);

};

#endif //PROJECT_SAFE_CONTROLLER_DEC_H
