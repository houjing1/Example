/*
 * FSM.h
 *
 *  Created On : Feb 13, 2018
 *      Author : Xintong Du
 */
#ifndef PROJECT_FSM_H
#define PROJECT_FSM_H

#include <map>
#include <vector>

#include "ros/ros.h"
#include "crazyflie_central/automaton.h"
#include "crazyflie_central/status_group_struct.h"

#include "crazyflie_central/VehicleStatus.h"

typedef std::pair<CommandGroup, StateGroup> CmdStatePair;
static CmdStatePair NOT_ASSIGNED(NA,NAs);

typedef std::map<CmdStatePair, std::vector<int>> GroupMap;
typedef std::map<VehicleStatus, std::vector<int>> StatusMap;

class FSM{
public:
    FSM(int drone_num, ros::NodeHandle* nh);
    ~FSM() {};
    std::vector<Events> events_record;                 /* Events of all vehicles. Flagged by safepilot */

    /* set event flag for a group of drones
     *
     *      args:
     *          drone_IDs: ID of drones to set the flag
     *          event: associated event
     *          flag: the flags of event (happened if true, false otherwise)
     */
    void setFlag(EventEnum event, std::vector<int> drone_IDs, std::vector<bool> flags);

    /* request to assign a new group to drones
     *      args: a map from group name to drone_IDs
     */
    void setGroup(GroupMap target_group);
    /* Return the current status
     * TODO: consider to do it in a thread-safe way
     *
     */
    const std::vector<VehicleStatus>& getStatus();

    /* Get the activated vehicles (i.e. those not at Sleep and Init mode who need commands)
     *
     */
    void getActivated(std::vector<int>& drone_ID);

    /* Query the state of all vehicles
     *
     * args:
     *          status: map from vehicle status to vehicle IDs
     * */
    void query(StatusMap* const status);

    /* Query the status of specific vehicles
     *
     * args:
     *          query_IDs: IDs of vehicles to be queried
     *          status: status of queried vehicles in the order as query_IDs
     * return:
     *          0: if all vehicles are found
     *          -1: if any ID is invalid.
     *
     * NOTE:
     *          It should guard against invalid IDs. Please ROS_INFO relevant info.
     * */
    int query(const std::vector<int> query_IDs, std::vector<VehicleStatus>* const status);

    /* Query the group of specific vehicles
     *
     * args:
     *          query_IDs: IDs of vehicles to be queried
     *          group: appended by assigned group of queried vehicles in the order as query_IDs
     * return:
     *          0: if all vehicles are found
     *          -1: if any ID is invalid.
     *
     * NOTE:
     *          It should guard against invalid IDs. Please ROS_INFO relevant info.
     *          Arg group might not be empty. It's up to calling function how to use it.
     * */
    int query(const std::vector<int> query_IDs, std::vector<CmdStatePair>* const group);

    /* Query for vehicles in specific status
     *
     * args:
     *          status: VehicleStatus to be queried
     *          drone_IDs: Id of vehicles' in that status
     *
     * NOTE:
     *          Arg drone_IDs might not be empty. It's up to calling function how to use it.
     * */
    void query(VehicleStatus status, std::vector<int>* const drone_IDs);

    /* Query for vehicles in specific group
     *
     * args:
     *          group: CmdStatePair to be queried
     *          drone_IDs: Id of vehicles' in that group
     *
     * NOTE:
     *          Arg drone_IDs might not be empty. It's up to calling function how to use it.
     * */
    void query(CmdStatePair group_name, std::vector<int>* const drone_IDs);

    /* Query the status of vehicles in a specific group
     *
     * args:
     *          group_name: CmdStatePair to be queried
     *          status: Id of vehicles' in that group at different status
     *
     * NOTE:
     *          Old contents in status will be cleared.
     * */
    void query(CmdStatePair group_name, StatusMap* const status);

    void run();

    void broadcast();

private:
    int _drone_num;
    ros::NodeHandle* _nh;

    std::vector<VehicleStatus> _status_record;         /* Status of all vehicles. Assume index as vehicle IDs*/
    std::vector<CmdStatePair> _group_record;           /* Cmd State Group of all vehicles. Assume index as vehicle IDs*/
    std::vector<Automaton> _automata;                  /* Automaton for each vehicles */

    ros::Publisher _pub_vehicle_status;

};


#endif //PROJECT_FSM_H