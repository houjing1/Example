/*
 * automaton.h
 *
 *  Created On : Mar 30, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_STATUS_GROUP_STRUCT_H
#define PROJECT_STATUS_GROUP_STRUCT_H

#define CMD_GROUP_SIZE 3
#define STATE_GROUP_SIZE 2

/* Vehicle Status:
 *
 * Emergency: Vehicle is impossible to control (e.g. Vicon Loss)
 * Init: Starting status of a vehicle.
 * Sleep: Vehicle has been connected, passed the onboard sensor test. It does not receive any commands.
 * Idle: Vehicle has been allocated to a task (e.g. Circle demo) and starts taking command from Safepilot
 * Takeoff: Vehicle is flying to it's take off position
 * Hover: Vehicle hovers at current position
 * CustomControl: Vehicle follows commands from Custom Controller (e.g. Circle)
 * Landing: Vehicle is landing at it's current x-y position.
 */
enum VehicleStatus {Emergency, Init, Sleep, Idle, Takeoff, Hover, CustomControl, Landing};
static std::string VehicleStatusName[8]{"Emergency", "Init", "Sleep", "Idle", "Takeoff", "Hover", "CustomControl", "Landing"};

enum CommandGroup {NA, PosSet, AltHold};
static std::string CommandGroupName[3]{"NA", "PosSet", "AltHold"};

enum StateGroup {NAs, FullTranslation};
static std::string StateGroupName[2]{"NA", "FullState"};

#endif //PROJECT_STATUS_GROUP_STRUCT_H
