/*
 * pilot_handbook.h
 *
 *  Created On : Feb 12, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_PILOT_HANDBOOK_H
#define PROJECT_PILOT_HANDBOOK_H

#include <map>

#include "crazyflie_central/FSM.h"
#include "crazyflie_central/safe_controller.h"

class PilotHandbookBase{
public:
    PilotHandbookBase(){};
    virtual ~PilotHandbookBase(){};
    virtual void query(FSM* const fsm)=0;
};

template <typename cmdType, typename stateType>
class PilotHandbook : public PilotHandbookBase{
public:
    PilotHandbook(int drone_num,
                  std::vector<cmdType>* cmds_pool,
                  std::vector<stateType>* states_pool,
                  CmdStatePair name
                  );
    ~PilotHandbook();
    /* Query safe cmds for a group of vehicles
     *
     * args:
     *          curr_status: a map from vehicle status to vehicles' IDs
     *          next_cmds: cmds for all vehicles. Only write cmds for vehicles that are listed in curr_status
     *                     and not in custom control mode.
     *
     *
     * NOTE:
     *          we use vehicle ID to index next_cmds.
     *
     */
    void query(StatusMap curr_status, std::vector<cmdType>* const next_cmds);
    void query(FSM* const fsm);


private:
    int _drone_num;
    CmdStatePair _name;
    std::map<VehicleStatus, SafeControllerBase<cmdType, stateType>*> _handbook;
    std::vector<cmdType>* _next_cmds;
    StatusMap _curr_status;

    /* Safely copy contents from src to dest.
     * Guard against overwrite (i.e. writing to non zero values which could mean
     *                               (i) some vehicles have multiple status
     *                               (ii)custom controller write to wrong place)
     *
     *
     * args:
     *          object_IDs: physically, the vehicle IDs. We use it to index dest
     *          src: source vector to copy from
     *          dest: destination vector to copy to
     *
     */
    void _safe_write(const std::vector<int> object_IDs, const std::vector<cmdType> src, std::vector<cmdType>* const dest);

};


template<typename cmdType, typename stateType>
PilotHandbook<cmdType, stateType>::PilotHandbook(int drone_num,
                                                 std::vector<cmdType>* cmds_pool,
                                                 std::vector<stateType>* states_pool,
                                                 CmdStatePair name) :
        PilotHandbookBase(),
        _drone_num(drone_num),
        _name(name),
        _handbook() {
    _next_cmds = cmds_pool;

    std::vector<int> empty_ids;
    for (int vs=Emergency; vs!=Landing+1; vs++){
        _curr_status[static_cast<VehicleStatus>(vs)] = empty_ids;
    }

    _handbook[Takeoff] = new SafeTakeoff<cmdType, stateType>(drone_num, states_pool);
    _handbook[Landing] = new SafeLand<cmdType, stateType>(drone_num, states_pool);
    _handbook[Hover] = new SafeHover<cmdType, stateType>(drone_num, states_pool);
    _handbook[Idle] = new SafeIdle<cmdType, stateType>(drone_num, states_pool);
};

template <typename cmdType, typename stateType>
PilotHandbook<cmdType, stateType>::~PilotHandbook(){
    typename std::map<VehicleStatus, SafeControllerBase<cmdType, stateType>*>::iterator it;

    for(it=_handbook.begin(); it!=_handbook.end(); ++it)
        delete it->second;
};

template<typename cmdType, typename stateType>
void PilotHandbook<cmdType, stateType>::query(StatusMap curr_status, std::vector<cmdType>* const next_cmds){

    _handbook.at(Takeoff)->update_flags(curr_status.at(Takeoff));
    if(curr_status.at(Takeoff).size() != 0){
        std::vector<cmdType> cmds{};
        _handbook.at(Takeoff)->control(curr_status.at(Takeoff), &cmds);
        _safe_write(curr_status.at(Takeoff), cmds, next_cmds);
    }

    _handbook.at(Landing)->update_flags(curr_status.at(Landing));
    if(curr_status.at(Landing).size() != 0){
        std::vector<cmdType> cmds{};
        _handbook.at(Landing)->control(curr_status.at(Landing), &cmds);
        _safe_write(curr_status.at(Landing), cmds, next_cmds);
    }

    _handbook.at(Hover)->update_flags(curr_status.at(Hover));
    if(curr_status.at(Hover).size() != 0){
        std::vector<cmdType> cmds{};
        _handbook.at(Hover)->control(curr_status.at(Hover), &cmds);
        _safe_write(curr_status.at(Hover), cmds, next_cmds);
    }

    _handbook.at(Idle)->update_flags(curr_status.at(Idle));
    if(curr_status.at(Idle).size() != 0){
        std::vector<cmdType> cmds{};
        _handbook.at(Idle)->control(curr_status.at(Idle), &cmds);
        _safe_write(curr_status.at(Idle), cmds, next_cmds);
    }
};

template <typename cmdType, typename stateType>
void PilotHandbook<cmdType, stateType>::_safe_write(const std::vector<int> object_IDs,
                                                    const std::vector<cmdType> src,
                                                    std::vector<cmdType>* const dest) {
    //TODO: find a better way to identify potential cmds conflicts. (Also, is it necessary?)
    if(object_IDs.size() != src.size()){
        ROS_INFO_STREAM("Invalid safe cmds. Ignored");
        return;
    }
    for(int i=0; i<object_IDs.size(); ++i){
        int index = object_IDs.at(i);
        dest->at(index) = src.at(i);
    }

};

template <typename cmdType, typename stateType>
void PilotHandbook<cmdType, stateType>::query(FSM* const fsm) {

    fsm->query(_name, &_curr_status);
    query(_curr_status, _next_cmds);

};

#endif //PROJECT_PILOT_HANDBOOK_H