/*
 * logger.h
 *
 *  Created On : Apr 05, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#ifndef PROJECT_LOGGER_H
#define PROJECT_LOGGER_H

#include <algorithm>
#include <string>
#include <vector>

#include "ros/ros.h"
#include "rosbag/bag.h"

#include "crazyflie_logger/AddLogger.h"
#include "crazyflie_logger/LoggerRequest.h"
#include "crazyflie_logger/DebugArray.h"
#include "crazyflie_central/Cmd.h"
#include "crazyflie_central/SwarmCmds.h"
#include "crazyflie_central/VehicleStatus.h"
#include "crazyflie_control/ControllerHubStatus.h"
#include "crazyflie_estimator/SwarmStates.h"

class LoggerHub;
static LoggerHub* logger_hub=nullptr;


struct LogInfo{
    std::string output_dir;
    std::string controller_name;
    std::vector<int> drone_IDs;
    std::vector<std::string> frame_IDs;

    std::vector<int> drone_IDs_reordered;
};

class Logger{
public:
    Logger(const LogInfo& info, const ros::NodeHandle& nh) :
            _info(info),
            _nh(nh) {};

    void writeBag();

    LogInfo _info;


    template <typename msgType>
    void recordData(const msgType& msg);

    const ros::NodeHandle& _nh;

    std::vector<crazyflie_central::SwarmCmds> _cmds;
    std::vector<crazyflie_estimator::SwarmStates> _states;
    std::vector<crazyflie_central::VehicleStatus> _status;
    std::vector<crazyflie_control::ControllerHubStatus> _controller_status;
    std::vector<crazyflie_logger::DebugArray> _debug_array;

    std::vector<ros::Time> _cmds_timestamp;
    std::vector<ros::Time> _states_timestamp;
    std::vector<ros::Time> _status_timestamp;
    std::vector<ros::Time> _controller_status_timestamp;
    std::vector<ros::Time> _debug_array_timestamp;

    void _organizeData();

    template <typename T>
    void _reorderVector(std::vector<T>& vec, std::vector<int> new_order);

};

class LoggerHub{
public:

    LoggerHub(ros::NodeHandle& nh):
            _nh(nh) {
        _sub_FullState = _nh.subscribe("full_state", 30, &LoggerHub::_cb_FullState, this);
        _sub_SwarmCmd = _nh.subscribe("SwarmCmds", 30, &LoggerHub::_cb_SwarmCmds, this);
        _sub_Status = _nh.subscribe("vehicle_status", 10, &LoggerHub::_cb_Status, this);
        _sub_ControllerStatus = _nh.subscribe("controller_hub_status", 10, &LoggerHub::_cb_ControllerStatus, this);
        _sub_DebugArray = _nh.subscribe("debug_array", 30, &LoggerHub::_cb_DebugArray, this);
        _srv_AddLogger = _nh.advertiseService("logger/add", &LoggerHub::_cb_AddLogger, this);
        _srv_LoggerRequest = _nh.advertiseService("logger/action", &LoggerHub::_cb_LoggerRequest, this);
    };

    bool addLogger(const LogInfo& info);

    void run();

    bool startLogger(const std::string& controller_name);

    bool stopLogger(const std::string& controller_name);
private:
    ros::NodeHandle& _nh;
    std::vector<Logger> _loggers;
    std::vector<bool> _logging;

    ros::Subscriber _sub_FullState;
    ros::Subscriber _sub_SwarmCmd;
    ros::Subscriber _sub_Status;
    ros::Subscriber _sub_ControllerStatus;
    ros::Subscriber _sub_DebugArray;

    ros::ServiceServer _srv_AddLogger;
    ros::ServiceServer _srv_LoggerRequest;

    bool _cb_AddLogger(crazyflie_logger::AddLogger::Request& req, crazyflie_logger::AddLogger::Response& res);
    bool _cb_LoggerRequest(crazyflie_logger::LoggerRequest::Request& req, crazyflie_logger::LoggerRequest::Response& res);

    void _cb_FullState(const crazyflie_estimator::SwarmStates msg);
    void _cb_SwarmCmds(const crazyflie_central::SwarmCmds msg);
    void _cb_Status(const crazyflie_central::VehicleStatus msg);
    void _cb_ControllerStatus(const crazyflie_control::ControllerHubStatus msg);
    void _cb_DebugArray(const crazyflie_logger::DebugArray msg);
};

template<>
void Logger::recordData<crazyflie_central::SwarmCmds>(const crazyflie_central::SwarmCmds& msg){
    std::vector<std::string>::iterator it=_info.frame_IDs.begin();
    std::vector<crazyflie_central::Cmd>::const_iterator it_cmd;
    crazyflie_central::SwarmCmds cmds_filtered;
    for(it; it!=_info.frame_IDs.end(); ++it){
        it_cmd = msg.cmds.begin();
        for(it_cmd; it_cmd!=msg.cmds.end(); ++it_cmd){
            if(it_cmd->header.frame_id == *it)
                cmds_filtered.cmds.push_back(*it_cmd);
        }
    }

    cmds_filtered.names = msg.names;

    _cmds.push_back(cmds_filtered);
    _cmds_timestamp.push_back(ros::Time::now());
}

template<>
void Logger::recordData<crazyflie_estimator::SwarmStates>(const crazyflie_estimator::SwarmStates& msg){
    std::vector<int>::iterator it=_info.drone_IDs.begin();
    crazyflie_estimator::SwarmStates states_filtered;

    for(it; it!=_info.drone_IDs.end(); ++it)
        states_filtered.fullstate.push_back(msg.fullstate[*it]);

    states_filtered.header = msg.header;

    _states.push_back(states_filtered);
    _states_timestamp.push_back(ros::Time::now());
}

template<>
void Logger::recordData<crazyflie_central::VehicleStatus>(const crazyflie_central::VehicleStatus& msg) {
    std::vector<int>::iterator it=_info.drone_IDs.begin();
    crazyflie_central::VehicleStatus status_filtered;

    for(it; it!=_info.drone_IDs.end(); ++it){
        status_filtered.status.push_back(msg.status[*it]);
        status_filtered.group.push_back(msg.group[*it]);
    }

    status_filtered.header = msg.header;

    _status.push_back(status_filtered);
    _status_timestamp.push_back(ros::Time::now());
}

template<>
void Logger::recordData<crazyflie_control::ControllerHubStatus>(const crazyflie_control::ControllerHubStatus& msg) {
    crazyflie_control::ControllerHubStatus status_filtered;
    int controller_num = msg.controllers_name.size();

    for(int i=0; i<controller_num; ++i)
        if(msg.controllers_name[i] == _info.controller_name){
            status_filtered.header = msg.header;
            status_filtered.controllers_info.push_back(msg.controllers_info[i]);
            status_filtered.controllers_status.push_back(msg.controllers_status[i]);
            status_filtered.controllers_name.push_back(msg.controllers_name[i]);
        }

    _controller_status.push_back(status_filtered);
    _controller_status_timestamp.push_back(ros::Time::now());
}

template<>
void Logger::recordData<crazyflie_logger::DebugArray>(const crazyflie_logger::DebugArray& msg) {
    if(msg.controller_name != _info.controller_name)
        return;

    _debug_array.push_back(msg);
    _debug_array_timestamp.push_back(ros::Time::now());
}

template <typename T>
void Logger::_reorderVector(std::vector<T>& vec, std::vector<int> new_order) {

    for(int i=0; i< new_order.size(); ++i){
        for(int j=i; j<new_order.size(); ++j)
            if(new_order[j] == i){
                if(i == j)
                    break;

                std::swap(vec[i], vec[j]);
                std::swap(new_order[i], new_order[j]);
                break;
            }
    }
}


#endif //PROJECT_LOGGER_H
