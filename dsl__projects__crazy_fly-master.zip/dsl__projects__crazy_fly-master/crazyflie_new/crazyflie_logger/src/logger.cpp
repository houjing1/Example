/*
 * logger.cpp
 *
 *  Created On : Apr 05, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include <ctime>
#include <unistd.h>

#include "crazyflie_logger/logger.h"
#include "crazyflie_utility/container_stream.h"

void Logger::writeBag(){
    // reorder and change frame_id
    _organizeData();

    time_t now = time(0);
    std::tm* local_time = localtime(&now);
    std::string local_time_str = std::to_string(local_time->tm_mon) + '_' +
                                 std::to_string(local_time->tm_mday) + '_' +
                                 std::to_string(local_time->tm_hour) + '_' +
                                 std::to_string(local_time->tm_min) + '_' +
                                 std::to_string(local_time->tm_sec);
    char mstr[100];
    std::strftime(mstr, sizeof(mstr), "%F-%H-%M-%S", local_time);
    std::string file_name = _info.controller_name + '_' + std::string(mstr);

    if(_info.output_dir.size() == 0){

        std::string param_output_dir;
        _nh.getParam("logger/output_dir", param_output_dir);

        if(param_output_dir.size() != 0)
            _info.output_dir = param_output_dir;
        else{
            char cwd[150];
            getcwd(cwd, 150);
            _info.output_dir = std::string(cwd) + std::string{'/'};
        }
    }

    std::string full_path = _info.output_dir +file_name + ".bag";
    rosbag::Bag _bag(full_path, rosbag::bagmode::Write);

    for(int i=0; i<_cmds.size(); ++i)
        _bag.write("SwarmCmds", _cmds_timestamp[i], _cmds[i]);

    for(int i=0; i<_states.size(); ++i)
        _bag.write("full_state", _states_timestamp[i], _states[i]);

    for(int i=0; i<_status.size(); ++i)
        _bag.write("vehicle_status", _status_timestamp[i], _status[i]);

    for(int i=0; i<_controller_status.size(); ++i)
        _bag.write("controller_hub_status", _controller_status_timestamp[i], _controller_status[i]);

    for(int i=0; i<_debug_array.size(); ++i)
        _bag.write("debug_array", _debug_array_timestamp[i], _debug_array[i]);
    _bag.close();

    ROS_INFO_STREAM("[Logger Hub]: Saved RosBag as " << full_path);
}

void Logger::_organizeData() {


    for(int i=0; i<_cmds.size(); ++i){
        _reorderVector<crazyflie_central::Cmd>(_cmds[i].cmds, _info.drone_IDs_reordered);
        for(int j=0; j<_info.drone_IDs.size(); ++j){
            _cmds[i].cmds[j].header.frame_id = "Drone"+std::to_string(j+1);
            _cmds[i].names[j] = "Drone" + std::to_string(j+1);
        }
    }

    for(int i=0; i<_states.size(); ++i){
        _reorderVector<crazyflie_estimator::FullState>(_states[i].fullstate, _info.drone_IDs_reordered);
    }

    for(int i=0; i<_status.size(); ++i){
        _reorderVector<std::string>(_status[i].group, _info.drone_IDs_reordered);
        _reorderVector<std::string>(_status[i].status, _info.drone_IDs_reordered);
    }
}

bool LoggerHub::addLogger(const LogInfo &info) {
    for(std::vector<Logger>::iterator it=_loggers.begin(); it!=_loggers.end(); ++it)
        if(it->_info.controller_name == info.controller_name){
            ROS_WARN_STREAM("[Logger Hub]: Failed to add logger for controller " << info.controller_name << ". It has been added before.");
            return false;
        }

    _loggers.emplace_back(info, _nh);
    _logging.emplace_back(false);
    ROS_INFO_STREAM("[Logger Hub]: Successfully add logger for controller "<< info.controller_name<<'.');
    return true;
}

bool LoggerHub::startLogger(const std::string &controller_name) {
    for(int i=0; i<_loggers.size(); ++i)
        if(_loggers[i]._info.controller_name == controller_name){
            if(!_logging[i]){
                _logging[i] = true;
                ROS_INFO_STREAM("[Logger Hub]: Start logging data for controller " << controller_name);
            }
            else{
                ROS_INFO_STREAM("[Logger Hub]: Logger for controller " << controller_name << " already started");
            }

            return true;
        }

    ROS_WARN_STREAM("[Logger Hub]: Logger for controller "<< controller_name << " not found");
    return false;
}

bool LoggerHub::stopLogger(const std::string &controller_name) {

    for(int i=0; i<_loggers.size(); ++i)
        if(_loggers[i]._info.controller_name == controller_name){
            if(_logging[i]){
                _logging[i] = false;
                ROS_INFO_STREAM("[Logger Hub]: Stop logging data for controller " << controller_name);

                _loggers[i].writeBag();
            }
            else{
                ROS_INFO_STREAM("[Logger Hub]: Logger for controller " << controller_name << " was not running");
            }

            return true;
        }

    ROS_WARN_STREAM("[Logger Hub]: Logger for controller "<< controller_name << " not found");
    return false;
}

void LoggerHub::run(){
    ros::Rate r(150);

    while(ros::ok()){

        ros::spinOnce();
        r.sleep();
    }
}

void LoggerHub::_cb_FullState(const crazyflie_estimator::SwarmStates msg) {

    for(int i=0; i<_loggers.size(); ++i)
        if(_logging[i])
            _loggers[i].recordData<crazyflie_estimator::SwarmStates>(msg);

}

void LoggerHub::_cb_SwarmCmds(const crazyflie_central::SwarmCmds msg) {

    for(int i=0; i<_loggers.size(); ++i)
        if(_logging[i])
            _loggers[i].recordData<crazyflie_central::SwarmCmds>(msg);

}

void LoggerHub::_cb_Status(const crazyflie_central::VehicleStatus msg) {

    for(int i=0; i<_loggers.size(); ++i)
        if(_logging[i])
            _loggers[i].recordData<crazyflie_central::VehicleStatus>(msg);

}

void LoggerHub::_cb_ControllerStatus(const crazyflie_control::ControllerHubStatus msg){

    for(int i=0; i<_loggers.size(); ++i)
        if(_logging[i])
            _loggers[i].recordData<crazyflie_control::ControllerHubStatus>(msg);
}

void LoggerHub::_cb_DebugArray(const crazyflie_logger::DebugArray msg) {
    for(int i=0; i<_loggers.size(); ++i)
        if(_logging[i])
            _loggers[i].recordData<crazyflie_logger::DebugArray>(msg);
}

bool LoggerHub::_cb_AddLogger(crazyflie_logger::AddLogger::Request &req, crazyflie_logger::AddLogger::Response &res) {
    LogInfo info;
    info.controller_name = req.controller_name;

    XmlRpc::XmlRpcValue controller_param;
    _nh.getParam("controller/" + info.controller_name, controller_param);

    std::vector<int> drone_IDs;

    for(int j=0; j<(int) controller_param["drone_num"]; j++)
        drone_IDs.push_back(int(controller_param["drone_ID"][j]));

    std::vector<std::string> frame_IDs;
    for(std::vector<int>::iterator it=drone_IDs.begin(); it!=drone_IDs.end(); ++it){
        frame_IDs.emplace_back("Drone" + std::to_string(*it));
        *it -= 1;
    }

    info.drone_IDs = drone_IDs;
    info.frame_IDs = frame_IDs;
    info.output_dir = req.output_dir;



    // TODO: set reorder in ControllerBase::Init()
    for(int i=0; i<info.drone_IDs.size(); ++i)
        info.drone_IDs_reordered.push_back(i);

//    ROS_INFO_STREAM("drone_IDs: " << Vec2Stream::toString(drone_IDs));
//    ROS_INFO_STREAM("frame_IDs: " << Vec2Stream::toString(frame_IDs));
//    ROS_INFO_STREAM("drone_IDs_reordered: " << Vec2Stream::toString(info.drone_IDs_reordered));

    res.success = addLogger(info);

    return true;
}

bool LoggerHub::_cb_LoggerRequest(crazyflie_logger::LoggerRequest::Request &req,
                                  crazyflie_logger::LoggerRequest::Response &res) {

    if(req.start)
        res.success = startLogger(req.controller_name);
    else
        res.success = stopLogger(req.controller_name);

    return true;
}


