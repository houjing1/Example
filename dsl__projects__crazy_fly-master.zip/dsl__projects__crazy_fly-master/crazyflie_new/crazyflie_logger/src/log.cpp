/*
 * log.cpp
 *
 *  Created On : Apr 05, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "ros/ros.h"
#include "crazyflie_logger/logger.h"

int main(int argc, char **argv) {
    ros::init(argc, argv, "logger hub");
    ros::NodeHandle n;

    logger_hub = new LoggerHub(n);

    logger_hub->run();

    delete logger_hub;

    return 0;

}