folder_name = "04-28-4/data";
path_to_log = "/home/tracy/Projects/Crazyflies/log/";
path_to_data = path_to_log + folder_name;
load(path_to_data + "/full_state/time.mat", '-mat');
load(path_to_data + "/full_state/fullstate.mat", '-mat');
load(path_to_data + "/full_state/bfeasible.mat", '-mat');

load(path_to_data + "/SwarmCmds/time.mat", '-mat');
load(path_to_data + "/SwarmCmds/cmds.mat", '-mat');

drone_num = length(fullstate(1,:,1,1));
for i = 1:drone_num
    names(i) = "Drone" + num2str(i);
end
