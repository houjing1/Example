folder_name = "04-28-2/A62-Onboard";
path_to_log = "/home/tracy/Projects/Crazyflies/log/";
path_to_data = path_to_log + folder_name;
%% State Estimation and Control
vicon_pos = import_viconpos(path_to_data + "/vicon_pos.csv");
vicon_vel = import_viconvel(path_to_data +"/vicon_vel.csv");
est_pos = import_estpos(path_to_data + "/estimated_states_pos.csv");
est_vel = import_estvel(path_to_data + "/estimated_states_vel.csv");
est_att = import_estatt(path_to_data + "/estimated_states_att.csv");
ctrl_pos = import_ctrlpos(path_to_data + "/control_inputs_pos.csv");
ctrl_vel = import_ctrlvel(path_to_data + "/control_inputs_vel.csv");
ctrl_att = import_ctrlatt(path_to_data + "/control_inputs_att.csv");

%% Sensors
sens_acc = import_sensacc(path_to_data + "/sensor_acc.csv");
sens_bar = import_sensbar(path_to_data + "/sensor_baro.csv");
sens_gyr = import_sensgyr(path_to_data + "/sensor_gyro.csv");
% sens_mag = import_sensmag(path_to_data + "/sensor_mag.csv");
%%
vicon_pos.time = vicon_pos.tick/1000;
vicon_vel.time = vicon_vel.tick/1000;
est_pos.time = est_pos.tick/1000;
est_vel.time = est_vel.tick/1000;
est_att.time = est_att.tick/1000;
ctrl_pos.time = ctrl_pos.tick/1000;
ctrl_vel.time = ctrl_vel.tick/1000;
ctrl_att.time = ctrl_att.tick/1000;

sens_acc.time = sens_acc.tick/1000;
sens_bar.time = sens_bar.tick/1000;
sens_gyr.time = sens_gyr.tick/1000;
% sens_mag.time = sens_mag.tick/1000;