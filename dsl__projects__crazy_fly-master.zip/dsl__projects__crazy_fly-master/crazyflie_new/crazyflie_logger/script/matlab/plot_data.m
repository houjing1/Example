%% Pos Tracking

f_post_trck = figure();
ax1 = subplot(3,1,1);
plot(est_pos.time, est_pos.x);
hold on;
plot(ctrl_pos.time, ctrl_pos.x);
legend("est-x", "setpoint-x");
ylabel("x(m)");
xlabel("time(s)");
grid on;
hold off;

ax2 = subplot(3,1,2);
plot(est_pos.time, est_pos.y);
hold on;
plot(ctrl_pos.time, ctrl_pos.y);
legend("est-y", "setpoint-y");
ylabel("y(m)");
xlabel("time(s)");
grid on;
hold off;

ax3 = subplot(3,1,3);
plot(est_pos.time, est_pos.z);
hold on;
plot(ctrl_pos.time, ctrl_pos.z);
legend("est-z", "setpoint-z");
ylabel("z(m)");
xlabel("time(s)");
grid on;
hold off;
linkaxes([ax1, ax2, ax3], 'x');

%% Vel Tracking
f_vel_trck = figure();
ax1 = subplot(3,1,1);
plot(est_vel.time, est_vel.x);
hold on;
plot(ctrl_vel.time, ctrl_vel.x);
legend("est-vx", "setpoint-vx");
ylabel("vx(m/s)");
xlabel("time(s)");
grid on;
hold off;

ax2 = subplot(3,1,2);
plot(est_vel.time, est_vel.y);
hold on;
plot(ctrl_vel.time, ctrl_vel.y);
legend("est-vy", "setpoint-vy");
ylabel("vy(m/s)");
xlabel("time(s)");
grid on;
hold off;

ax3 = subplot(3,1,3);
plot(est_vel.time, est_vel.z);
hold on;
plot(ctrl_vel.time, ctrl_vel.z);
legend("est-vz", "setpoint-vz");
ylabel("vz(m/s)");
xlabel("time(s)");
grid on;
hold off;
linkaxes([ax1, ax2, ax3], 'x');
%% Att Tracking
f_att_trck = figure();
ax1 = subplot(3,1,1);
plot(est_att.time, est_att.roll);
hold on;
plot(ctrl_att.time, ctrl_att.roll);
legend("est-roll", "setpoint-roll");
ylabel("\phi (deg)");
xlabel("time(s)");
grid on;
hold off;

ax2 = subplot(3,1,2);
plot(est_att.time, est_att.pitch);
hold on;
plot(ctrl_att.time, ctrl_att.pitch);
legend("est-pitch", "setpoint-pitch");
ylabel("\theta (deg)");
xlabel("time(s)");
grid on;
hold off;

ax3 = subplot(3,1,3);
plot(est_att.time, est_att.yaw);
hold on;
plot(ctrl_att.time, ctrl_att.yaw);
legend("est-yaw", "setpoint-yaw");
ylabel("psi (deg)");
xlabel("time(s)");
grid on;
hold off;
linkaxes([ax1, ax2, ax3], 'x');

%% Pos Est
f_pos_est = figure();
ax1 = subplot(3,1,1);
plot(vicon_pos.time, vicon_pos.x);
hold on;
plot(est_pos.time, est_pos.x);
legend("vicon-x", "est-x");
ylabel("x(m)");
xlabel("time(s)");
grid on;
hold off;

ax2 = subplot(3,1,2);
plot(vicon_pos.time, vicon_pos.y);
hold on;
plot(est_pos.time, est_pos.y);
legend("vicon-y", "est-y");
ylabel("y(m)");
xlabel("time(s)");
grid on;
hold off;

ax3 = subplot(3,1,3);
plot(vicon_pos.time, vicon_pos.z);
hold on;
plot(est_pos.time, est_pos.z);
legend("vicon-z", "est-z");
ylabel("z(m)");
xlabel("time(s)");
grid on;
hold off;
linkaxes([ax1, ax2, ax3], 'x');
%% Vel Est

f_vel_est = figure();
ax1 = subplot(3,1,1);
plot(vicon_vel.time, vicon_vel.x);
hold on;
plot(est_vel.time(1:length(est_vel.time)-1), est_vel.x(1:length(est_vel.time)-1));
legend("vicon-vx", "est-x");
ylabel("vx(m/s)");
xlabel("time(s)");
grid on;
hold off;

ax2 = subplot(3,1,2);
plot(vicon_vel.time, vicon_vel.y);
hold on;
plot(est_vel.time, est_vel.y);
legend("vicon-vy", "est-y");
ylabel("vy(m/s)");
xlabel("time(s)");
grid on;
hold off;

ax3 = subplot(3,1,3);
plot(vicon_vel.time, vicon_vel.z);
hold on;
plot(est_vel.time, est_vel.z);
legend("vicon-vz", "est-z");
ylabel("vz(m/s)");
xlabel("time(s)");
grid on;
hold off;
linkaxes([ax1, ax2, ax3], 'x');
%% Att Est
f_att_est = figure();
ax1 = subplot(3,1,1);
plot(est_att.time, est_att.roll);
legend("roll");
ylabel("\phi (deg)");
xlabel("time(s)");
grid on;

ax2 = subplot(3,1,2);
plot(est_att.time, est_att.pitch);
legend("pitch");
ylabel("\theta (deg)");
xlabel("time(s)");
grid on;

ax3 = subplot(3,1,3);
plot(est_att.time, est_att.yaw);
legend("yaw");
ylabel("\psi (deg)");
xlabel("time(s)");
grid on;

linkaxes([ax1, ax2, ax3], 'x');
%% Sensor Acc
figure();
ax1 = subplot(3,1,1);
plot(sens_acc.time, sens_acc.x * 9.8);
legend("acc-x");
ylabel("ax(m/s/s)");
xlabel("time(s)");
grid on;

ax2 = subplot(3,1,2);
plot(sens_acc.time, sens_acc.y * 9.8);
legend("acc-y");
ylabel("ay(m/s/s)");
xlabel("time(s)");
grid on;

ax3 = subplot(3,1,3);
plot(sens_acc.time, sens_acc.z * 9.8);
legend("acc-z");
ylabel("az(m/s/s)");
xlabel("time(s)");
grid on;

linkaxes([ax1, ax2, ax3], 'x');

%% Sensor Gyro
figure();
ax1 = subplot(3,1,1);
plot(sens_gyr.time, sens_gyr.x);
legend("gyro-x");
ylabel("\omega_x(deg/s)");
xlabel("time(s)");
grid on;

ax2 = subplot(3,1,2);
plot(sens_gyr.time, sens_gyr.y);
legend("gyro-y");
ylabel("\omega_y(deg/s)");
xlabel("time(s)");
grid on;

ax3 = subplot(3,1,3);
plot(sens_gyr.time, sens_gyr.z);
legend("gryo-z");
ylabel("\omega_z(deg/s)");
xlabel("time(s)");
grid on;

linkaxes([ax1, ax2, ax3], 'x');