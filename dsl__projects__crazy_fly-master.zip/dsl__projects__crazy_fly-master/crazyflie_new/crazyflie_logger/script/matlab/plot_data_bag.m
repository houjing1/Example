%% Select drone num, state dim, cmds dim
drones = [1,2,3,4,5,6,7,8];
for i = 1:length(drones)
    drone_legend(i) = names(drones(i));
end
state_dim_name = ["x", "y", "z"];
state_dim = 3;
cmds_dim = 3;
%% states, cmds
figure();
ax1 = subplot(3,1,1);
for i = 1:length(drones)
    plot(time_fullstate, fullstate(:, drones(i), 1, state_dim));
    hold on;
end
legend(drone_legend);
xlabel("time (s)");
ylabel("Pos" + state_dim_name(state_dim));
grid on;
hold off;

ax2 = subplot(3,1,2);
for i = 1:length(drones)
    plot(time_fullstate, fullstate(:, drones(i), 2, state_dim));
    hold on;
end
legend(drone_legend);
xlabel("time (s)");
ylabel("Vel" + state_dim_name(state_dim));
grid on;
hold off;

ax3 = subplot(3,1,3);
for i = 1:length(drones)
    plot(time_fullstate, fullstate(:, drones(i), 3, state_dim));
    hold on;
end
legend(drone_legend);
xlabel("time (s)");
ylabel("Acc" + state_dim_name(state_dim));
grid on;
hold off;

linkaxes([ax1, ax2, ax3], 'x');
%%
figure();
ax4 = subplot(1,1,1);
for i = 1:length(drones)
    plot(time_cmds, cmds(:, drones(i), cmds_dim));
    hold on;
end
legend(drone_legend);
xlabel("time (s)");
ylabel("cmds " + num2str(cmds_dim));
grid on;
linkaxes([ax1,ax4], 'x');
hold off;