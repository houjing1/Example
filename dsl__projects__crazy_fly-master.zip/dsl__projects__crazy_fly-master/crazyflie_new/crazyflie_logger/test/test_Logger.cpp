/*
 * test_logger.cpp
 *
 *  Created On : Apr 05, 2018
 *      Author : Xintong Du
 *      Email  : xintong.du@mail.utoronto.ca
 */

#include "ros/ros.h"
#include "crazyflie_logger/logger.h"
#include "crazyflie_utility/container_stream.h"

int main(int argc, char **argv) {
    ros::init(argc, argv, "test_Logger");
    ros::NodeHandle nh;

    LogInfo logInfo;
    logInfo.controller_name = "Circle";
    logInfo.drone_IDs = std::vector<int>{0,1,2,3,4};
    logInfo.frame_IDs = std::vector<std::string>{"Drone1", "Drone2", "Drone3", "Drone4", "Drone5"};
    logInfo.drone_IDs_reordered = std::vector<int>{2,0,3,4,1};

    Logger logger{logInfo, nh};

    if(argc <2){
        ROS_INFO("Usage: rosrun test_logger ");
    }
    else if (!strcmp(argv[1], "reorderVector")){
        ROS_INFO_STREAM("Before reoder:\n" << Vec2Stream::toString<std::string>(logInfo.frame_IDs));
        ROS_INFO_STREAM("New order:\n" << Vec2Stream::toString<int>(logInfo.drone_IDs_reordered));
        logger._reorderVector<std::string>(logInfo.frame_IDs, logInfo.drone_IDs_reordered);
        ROS_INFO_STREAM("After ordered:\n" << Vec2Stream::toString<std::string>(logInfo.frame_IDs));
    }
    else if(!strcmp(argv[1], "writeBag")){

        crazyflie_central::SwarmCmds cmds;
        cmds.names = logInfo.frame_IDs;

        crazyflie_central::VehicleStatus status;
        status.header.stamp = ros::Time::now();

        crazyflie_estimator::SwarmStates states;
        states.header.stamp = ros::Time::now();

        for(int i=0; i<logInfo.frame_IDs.size(); ++i){
            crazyflie_central::Cmd cmd_temp;
            cmd_temp.header.frame_id = logInfo.frame_IDs[i];
            cmd_temp.header.stamp = ros::Time::now();
            cmd_temp.type = "PosSet";
            std::vector<float> values_temp{i*0.1f, i*0.2f, i*0.3f, i*0.4f};
            cmd_temp.values.push_back(i*0.1f);
            cmd_temp.values.push_back(i*0.2f);
            cmd_temp.values.push_back(i*0.3f);
            cmd_temp.values.push_back(i*0.4f);
            cmds.cmds.push_back(cmd_temp);

            crazyflie_estimator::FullState state_temp;
            state_temp.pos = boost::array<double, 3> {i*1.1f, i*1.2f, i*1.3f};
            states.fullstate.push_back(state_temp);

            status.status.push_back("Idle");
            status.group.push_back("AltHoldFullState");

        }

        logger.recordData<crazyflie_central::SwarmCmds>(cmds);
        logger.recordData<crazyflie_estimator::SwarmStates>(states);
        logger.recordData<crazyflie_central::VehicleStatus>(status);
        ROS_INFO("writing");
        logger.writeBag();

    }

    return 0;

}