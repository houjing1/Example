#!/usr/bin/env python
import roslib
import rospy
from crazyflie_demo.srv import CirLine as CirLinesrv
from dsl__utilities__msg.msg import StateData # for publishing way points


def cb(req):
    num_drones = rospy.get_param("~num_drones", 6)
    endPosition = rospy.get_param("~endPosition", [])
    for i in range(num_drones):
        model = 'Drone'+str(i+1)
        pubEndpoints = rospy.Publisher(model + '/path_coordinates',StateData, queue_size=1)
        cmd = StateData()
        cmd.header.stamp = rospy.get_rostime()
        cmd.x, cmd.y, cmd.z, cmd.yaw = endPosition[i]
        cmd.z = req.height
        pubEndpoints.publish(cmd)
        print("Drone{}: [{}, {}, {}]".format(i+1, cmd.x, cmd.y, cmd.z))

    return []


if __name__=='__main__':
    rospy.init_node('crazyflie_ui')
    s = rospy.Service('/send_ending_position', CirLinesrv, cb)
    rospy.spin()
