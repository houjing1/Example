#!/usr/bin/env python

from __future__ import absolute_import, division, print_function
import rospy
import math
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from geometry_msgs.msg import TransformStamped, Twist
from dsl__utilities__msg.msg import StateData, StateVector
from std_srvs.srv import Empty
from crazyflie_driver.srv import UpdateParams
from crazyflie_driver.msg import FullControl
from std_srvs.srv import Empty as Emptysrv

#speed at which the waves are propogated
speed_factor = 3.0

#rate at which the program publishes new commands
update_rate = 100.0

#the mode can either be 'pid' or 'not pid'
#####NOT TESTED FOR PID##############
mode = 'not pid'

#maximum length of the arena so we know how much data to save
arena_length = 5


#rate at which estimated state is updated
estimator_update_rate = 100

#drone physics parameters
#maximum allowable acceleration
max_acc = 5.0

#rate at which the spring oscilates
spring_constant = 4.0

#Rate at which the wave is damped until is dissapears
damping_constant = 0.5

#Difference in acceleration, velocity and position from zero at which an event ends
disregard_epsilon = 0.15

#number of frames that an event must occur to be detected
is_event_frame_limit = 0.5 * update_rate

# meters away that an event is recognized
event_threshold = 0.15

#a drone must be held a less than this speed to be detected as an event
movement_threshold = 0.2

#seconds required for takeoff
seconds_takeoff = 5.0

class physics_drone:
    def __init__(self, pos, drone):
        self.offset_pos = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]
        self.outside_influence = False
        self.drone = None
        self.initial_pos = pos[:]
        self.drone = drone

    #take one timestep for the spring simulation
    def restore_state_change(self, delta_t):
        self.acc[0], self.acc[1], self.acc[2] = \
        (-spring_constant * (self.offset_pos[0])), \
        (-spring_constant * (self.offset_pos[1])), \
        (-spring_constant * (self.offset_pos[2]))

        self.acc[0] = np.sign(self.acc[0]) * min(math.fabs(self.acc[0]), max_acc)
        self.acc[1] = np.sign(self.acc[1]) * min(math.fabs(self.acc[1]), max_acc)
        self.acc[2] = np.sign(self.acc[2]) * min(math.fabs(self.acc[2]), max_acc)

        self.vel[0], self.vel[1], self.vel[2] = \
        self.vel[0] + self.acc[0] * delta_t, \
        self.vel[1] + self.acc[1] * delta_t, \
        self.vel[2] + self.acc[2] * delta_t
        self.offset_pos[0], self.offset_pos[1], self.offset_pos[2] = \
        self.offset_pos[0] + self.vel[0] * delta_t + 0.5 * self.acc[0] * delta_t ** 2, \
        self.offset_pos[1] + self.vel[1] * delta_t + 0.5 * self.acc[1] * delta_t ** 2, \
        self.offset_pos[2] + self.vel[2] * delta_t + 0.5 * self.acc[2] * delta_t ** 2

        if mode != "pid":
            self.vel[0] *= math.exp(-damping_constant / 2 * delta_t)
            self.vel[1] *= math.exp(-damping_constant / 2 * delta_t)
            self.vel[2] *= math.exp(-damping_constant / 2 * delta_t)
        else:
            self.vel[0] *= math.exp(-damping_constant * delta_t)
            self.vel[1] *= math.exp(-damping_constant * delta_t)
            self.vel[2] *= math.exp(-damping_constant * delta_t)

        #Here the program determines whether or not the drone's motions
        #are small enough to end the event
        if (np.linalg.norm(np.array(self.acc)) < disregard_epsilon) and (np.linalg.norm(np.array(self.vel)) < disregard_epsilon) \
        and (np.linalg.norm(np.array(self.offset_pos)) < disregard_epsilon):
            self.acc = [0,0,0]
            self.vel = [0,0,0]
            self.offset_pos = [0,0,0]

            self.drone.countdown_to_end -= 1
            if (self.drone.countdown_to_end < 0):
                self.drone.disturbances.event_drones.remove(self.drone)
                self.drone.is_event = False
                self.drone.disturbances.num_events -= 1
                print("End Event", self.drone.index)



class drone:
    def __init__(self, pos, index, disturbances):
        self.index = 0
        self.physics_engine = None
        self.offset_pos = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]
        self.physics_engine = None
        self.is_event = False
        self.initial_pos = pos[:]
        self.reference_pos = None
        self.past_states = [StateVector()]
        self.past_states[0].pos = pos[:]
        self.index = index
        self.disturbances = disturbances
        self.physics_engine = physics_drone(pos, self)
        self.is_event = False
        self.offset_frames = 0
        self.countdown_to_end = arena_length * update_rate / speed_factor
        rospy.Subscriber("/Drone" + str(index + 1) + "/estimated_state", StateVector, self.save_external_state)

    #saves the true external state of the drones
    def save_external_state(self, state):
        self.past_states.append(state)

        if len(self.past_states) > arena_length * estimator_update_rate / speed_factor:
            self.past_states.remove(self.past_states[0])
            #removes the oldest state if past states already has enough past information

    #calculates delay between an event and the drone moving
    def get_delay(self, lead_pos):
        return self.get_distance(lead_pos.initial_pos, self.initial_pos) / speed_factor

    def get_distance(self, drone1, drone2):
        sum = 0
        for i in range(len(drone1)):
            sum += (drone1[i] - drone2[i])**2

        return sum**0.5


    def update_state(self):
        self.check_for_event()

        self.offset_pos = np.zeros((3,))
        self.vel = np.zeros((3,))
        self.acc = np.zeros((3,))

        time = rospy.Time.now()

        for i in range(len(self.disturbances.event_drones)):

            if self.get_delay(self.disturbances.event_drones[i]) < (time.secs + time.nsecs * 10 **(-9))\
                - self.disturbances.event_drones[i].past_states[0].header.stamp.secs - self.disturbances.event_drones[i].past_states[0].header.stamp.nsecs * 10 ** (-9):
                #print("-----------------")
                #print(len(self.disturbances.events))
                #print("For drone " + str(self.index+1))
                #print("At time " + str((time.secs + time.nsecs * 10**(-9)) - self.get_delay(self.disturbances.events[i][0])))
                if not (self in [self.disturbances.event_drones[i]]):
                    state = self.disturbances.get_closest_state(i, (time.secs + time.nsecs * 10**(-9)) -  self.get_delay(self.disturbances.event_drones[i]))
                    #print ("state of the event is:", np.array(state.pos[:]))
                    #print ("initial state of the event is:", np.array(self.disturbances.event_drones[i].initial_pos[:]))
                    damp = 1.0#math.exp(-1/transfer_factor * self.get_distance(self.initial_pos, self.disturbances.events[i][0]))
                    self.offset_pos += (np.array(state.pos[:]) - np.array(self.disturbances.event_drones[i].initial_pos[:]))
                    self.vel += np.array(state.vel[:])
                    self.acc += np.array(state.acc[:])

            #print("For drone " + str(self.index+1))
            #print("------------------------")
        #print ("offset ", self.offset_pos, "\n", self.vel, "\n", self.acc)
        if self.is_event:
            self.physics_engine.restore_state_change(1/float(update_rate))
            #print(1/float(update_rate))
            self.offset_pos = np.array(self.physics_engine.offset_pos[:]) + np.array(self.offset_pos[:])
            self.vel = np.array(self.physics_engine.vel[:]) + np.array(self.vel[:])
            #print(self.offset_pos)
            #print(self.vel)
            self.acc = np.array(self.physics_engine.acc[:]) + np.array(self.acc[:])
            #self.physics_engine.offset_pos = np.array(self.past_states[-1].pos) - np.array(self.initial_pos)

    def is_stationary(self):
        if (np.linalg.norm(np.array(self.past_states[-1].vel[:])) < movement_threshold):
            return True
        else:
            return False

    def check_for_event(self):
        #print(np.linalg.norm(np.array(self.external_pos) - np.array(self.initial_pos) - np.array(self.offset_pos)))

        if np.linalg.norm(np.array(self.past_states[-1].pos[:]) - np.array(self.offset_pos) - np.array(self.reference_pos)) > event_threshold \
            and self.is_stationary():
            self.offset_frames+=1
            if self.offset_frames > is_event_frame_limit:
                if (self.is_event != True) and (len(self.disturbances.event_drones) == 0):
                    self.is_event = True
                    self.disturbances.add_event(self.initial_pos[:], self)
                    self.countdown_to_end = arena_length * update_rate / speed_factor

                    self.physics_engine.initial_pos = np.array(self.initial_pos[:])
                    self.physics_engine.vel = np.zeros((3,))
                    self.physics_engine.offset_pos = np.array(self.past_states[-1].pos[:]) - np.array(self.initial_pos)
                elif self.is_event == True:
                    self.physics_engine.initial_pos = np.array(self.initial_pos[:])
                    self.physics_engine.vel = np.zeros((3,))
                    self.physics_engine.offset_pos = np.array(self.past_states[-1].pos[:]) - np.array(self.initial_pos)
                #print(self.physics_engine.offset_pos
        else:
            self.offset_frames = 0


class disturbances:
    num_events = 0
    pubs = []
    drones = []
    prev_state = -1
    start_surface = False

    def __init__(self, num_drones):
        self.event_drones = []
        print("Fluid demo is initialized!")
        self.num_events = 0
        self.number_crazyflies = rospy.get_param("~num_drones")
        self.length = float(rospy.get_param("arena_length", 1))
        self.dimensions = rospy.get_param("dimensions", 1)
        for i in range(num_drones):
            self.drones.append(drone([rospy.get_param("x" + str(i+1)), rospy.get_param("y" + str(i+1)), 1.0], i, self))
            rospy.wait_for_service("/Drone"+ str(i+1) + "/update_params")
            if mode == 'pid':
                rospy.set_param("/Drone"+ str(i+1) + "/flightmode/posSet", 1)
                func = rospy.ServiceProxy("/Drone"+ str(i+1) + "/update_params", UpdateParams)
                func(["flightmode/posSet"])
        rospy.Service('surface_begin', Emptysrv, self.surface_begin_cb)
        self.run()

    def get_closest_state(self, index, time):
        i = 0
        #print(lead)
        #print(time)
        #print(index)

        while((i < len(self.event_drones[index].past_states) - 1 and (time - self.event_drones[index].past_states[i].header.stamp.secs \
        - self.event_drones[index].past_states[i].header.stamp.nsecs * 10 ** (-9) > 0.5/update_rate))):
            #print(i)
            i += 1
        try:
            return self.event_drones[index].past_states[i]
        except:
            return self.event_drones[index].past_states[i-1]

    def add_event(self, pos, drone):
        print("Adding event", drone.index)
        self.num_events += 1
        time = rospy.Time.now()
        self.event_drones.append(drone)
        # print(self.event_drones)

    def update_drones(self):
        for i in range(self.number_crazyflies):
            self.drones[i].update_state()

    def reset_ekf(self):
        for i in range(self.number_crazyflies):
            func = rospy.ServiceProxy("/Drone"+ str(i+1) + "/update_params", UpdateParams)
            rospy.set_param("/Drone" + str(i+1) + "kalman/resetEstimation", 1)
            func(["kalman/resetEstimation"])

            rospy.sleep(0.1)
            rospy.set_param("/Drone" + str(i+1) + "kalman/resetEstimation", 0)
            func(["kalman/resetEstimation"])
            print("Reset the kalman filter")

    def surface_begin_cb(self, req):
        if not self.start_surface:
            self.start_surface = True
        return ()

    def run(self):
        while not self.start_surface:
            pass 
        
        axis = rospy.get_param("axis")
        for i in range(self.number_crazyflies):
            #rospy.wait_for_service("/Drone"+ str(i+1) + "/override")
            #func = rospy.ServiceProxy("/Drone"+ str(i+1) + "/override", Empty)
            #func()
            if mode != 'pid':
                self.pubs.append(rospy.Publisher("/Drone" + str(i+1) + "/pre_full_control", FullControl, queue_size=30))
            else:
                self.pubs.append(rospy.Publisher("/Drone" + str(i+1) + "/pre_cmd_vel", Twist, queue_size=30))

        #self.reset_ekf()

        self.initial_takeoff()
        self.hover(4)
        self.update_init_pos()
        print ("Fluid Demo has been activated!")
        rate = rospy.Rate(update_rate)

        while not rospy.is_shutdown():
            self.update_drones()
            for i in range(self.number_crazyflies):
                if mode != 'pid':
                    state = FullControl()
                    state.header.frame_id = str(i+1)
                    state.enable = True
                    state.xmode = 0b111
                    state.ymode = 0b111
                    state.zmode = 0b111
                    state.x[0] = self.drones[i].initial_pos[0] + self.drones[i].offset_pos[0]
                    state.y[0] = self.drones[i].initial_pos[1] + self.drones[i].offset_pos[1]
                    state.z[0] = self.drones[i].initial_pos[2] + self.drones[i].offset_pos[2]
                    state.x[1] = self.drones[i].vel[0]
                    state.y[1] = self.drones[i].vel[1]
                    state.z[1] = self.drones[i].vel[2]
                    state.x[2] = self.drones[i].acc[0]
                    state.y[2] = self.drones[i].acc[1]
                    state.z[2] = self.drones[i].acc[2]

                    if state.z[0] <= 0:
                        state.z[0] = 0.001
                        state.z[1] = 0
                        state.z[2] = 0

                    state.yaw[0] = 0
                    state.yaw[1] = 0

                    self.pubs[i].publish(state)
                else:
                    t = Twist()
                    t.linear.x = (self.drones[i].initial_pos[0] + self.drones[i].offset_pos[0])
                    t.linear.y = (self.drones[i].initial_pos[1] + self.drones[i].offset_pos[1])
                    t.linear.z = (self.drones[i].initial_pos[2] + self.drones[i].offset_pos[2]) * 1000
                    #print(t)
                    self.pubs[i].publish(t)

            rate.sleep()

    def initial_takeoff(self):
        count = 0.0
        rate = rospy.Rate(update_rate)

        while count < seconds_takeoff * update_rate:
            for i in range(self.number_crazyflies):
                state = FullControl()
                state.header.frame_id = str(i+1)
                state.enable = True
                state.xmode = 0b111
                state.ymode = 0b111
                state.zmode = 0b111
                state.x[0] = self.drones[i].initial_pos[0]
                state.y[0] = self.drones[i].initial_pos[1]
                state.z[0] = self.drones[i].initial_pos[2] * count / float(seconds_takeoff * update_rate)
                state.x[1] = 0
                state.y[1] = 0
                state.z[1] = 0
                state.x[2] = 0
                state.y[2] = 0
                state.z[2] = 0

                state.yaw[0] = 0
                state.yaw[1] = 0

                self.pubs[i].publish(state)

            rate.sleep()
            count += 1

    def hover(self, sec):

        count = 0.0
        rate = rospy.Rate(update_rate)

        while count < sec * update_rate:
            for i in range(self.number_crazyflies):
                state = FullControl()
                state.header.frame_id = str(i+1)
                state.enable = True
                state.xmode = 0b111
                state.ymode = 0b111
                state.zmode = 0b111
                state.x[0] = self.drones[i].initial_pos[0]
                state.y[0] = self.drones[i].initial_pos[1]
                state.z[0] = self.drones[i].initial_pos[2]
                state.x[1] = 0
                state.y[1] = 0
                state.z[1] = 0
                state.x[2] = 0
                state.y[2] = 0
                state.z[2] = 0

                state.yaw[0] = 0
                state.yaw[1] = 0

                self.pubs[i].publish(state)

            rate.sleep()
            count += 1

    def update_init_pos(self):
        for i in range(self.number_crazyflies):
            sum = np.zeros((3,))
            # Average positions over the last seconds
            for j in range(int(estimator_update_rate)): 
                sum += self.drones[i].past_states[-j].pos
            self.drones[i].reference_pos = list(sum / int(estimator_update_rate))
            # print ("Drone", i, self.drones[i].reference_pos)

if __name__=="__main__":
    rospy.init_node("crazyflie_ribbon")
    num = rospy.get_param("~num_drones")
    disturb = disturbances(num)
    rospy.spin()
