#!/usr/bin/env python

from __future__ import absolute_import, division, print_function
import rospy
import math
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from geometry_msgs.msg import TransformStamped, TwistStamped
from dsl__utilities__msg.msg import StateData, StateVector
from std_srvs.srv import Empty
from crazyflie_driver.srv import UpdateParams
from crazyflie_driver.msg import FullControl
from std_srvs.srv import Empty as Emptysrv
from crazyflie_demo.srv import CirLine as CirLinesrv


#Speed factor is a constant that determines how fast the wave propogates
speed_factor = 3

#update_rate determines how fast you want the program to publish new commands
update_rate = 100

#mode determines which controller you want to use, PID or nonlinear for the crazyflies
#use either "pid" or "not pid"
mode = 'pid'

#Maximum allowable acceleration of the drone
max_acc = 5

#determines how quickly the drone will oscilate
spring_constant = 20

#This makes the wand seem 1 meter closer than it is, resulting in
#A more responsive demo
#DO NOT MAKE LARGER THAN THE CLOSEST CRAZYFLIE
lead_adjustment = 1


#Smoothing constants to allow for a nice trajectory.
#The z direction should be smoothed more so the drone is less likely to flip
low_pass_constant = 0.1

low_pass_constant_z = low_pass_constant * 2.5

class drone:
    def __init__(self, pos, index, disturbances):
        #pos is the initial position of the drone on the ground
        #disturbances is the disturbance object
        self.offset_position = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]
        self.physics_engine = None
        self.initial_position = pos[:]
        self.index = index
        self.disturbances = disturbances

    #Returns number of seconds each drone is delayed relative to the wand
    def get_delay(self, lead_pos):
        return self.get_distance(lead_pos, self.initial_position) / speed_factor

    def get_distance(self, drone1, drone2):
        sum = 0
        for i in range(len(drone1)):
            sum += (drone1[i] - drone2[i])**2

        return sum**0.5 - lead_adjustment

    #updates the state of each drone relative to the wand
    def update_state(self):
        self.offset_position = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]

        time = rospy.Time.now()
        for i in range(len(self.disturbances.events)):
            if self.get_delay(self.disturbances.events[i][0]) < (time.secs + time.nsecs * 10**(-9)) - self.disturbances.events[i][1][0]:
                #this returns the state of the wand that the drone will try
                #to mimic
                state = self.disturbances.get_closest_state(i, (time.secs + time.nsecs * 10**(-9)) - self.get_delay(self.disturbances.events[i][0]))
                for x in range(3):
                    #Change damp if you want there to be a damping factor with distance
                    damp = 1
                    self.offset_position[x] += state[0][x] * damp
                    self.vel[x] += state[1][x] * damp
                    self.acc[x] += state[2][x] * damp

class disturbances:
    events = []
    num_events = 0
    pubs = []
    drones = []
    prev_state = -1
    prev_time = 0

    start_running = False

    def __init__(self, num_drones):
        self.num_events = 0
        self.number_crazyflies = rospy.get_param("~num_drones", 6)
        self.length = float(rospy.get_param("arena_length", 2))
        self.dimensions = rospy.get_param("dimensions", 1)
        self.prev_time = rospy.Time.now()
        self.prev_cmd = [None] * self.number_crazyflies
        self.wand_curr_pos = [0,0,0]

        #The demo is called by the ribbon_demo_begin service
        self.wand_tracking_enable = False
        rospy.Service('ribbon_demo_begin', Emptysrv, self.run)

    #this function returns the state of the event at index "index" that is
    #closest to time "time"
    def get_closest_state(self, index, time):
        i = 0

        while((i < len(self.events[index][1]) - 1) and (time - self.events[index][1][i] > 0.5/update_rate)):
            i += 1
        try:
            return self.events[index][2][i]
        except:
            return self.events[index][2][i-1]

    def add_event(self, pos):
        self.num_events += 1
        time = rospy.Time.now()
        self.events.append([pos[:], [(time.secs + time.nsecs * 10**(-9))], [[[0,0,0], [0,0,0], [0,0,0]]]])

    #called whenever the rbbon position changes
    def update_events(self, state):
        if self.wand_tracking_enable:
            state.pos = (state.pos[0], state.pos[1], state.pos[2] - 0.05)

            #state = self.low_pass(state)

            for e in range(len(self.events)):
                time = rospy.Time.now()
                self.events[e][1].append(time.secs + time.nsecs * 10**(-9))
                self.events[e][2].append([np.array(state.pos[:]) - np.array(self.events[e][0]), \
                np.array(state.vel[:]), \
                np.array(state.acc[:])])
                if (len(self.events[e][2]) > update_rate / speed_factor * self.length * 8):
                    self.events[e][1].remove(self.events[e][1][1])
                    self.events[e][2].remove(self.events[e][2][0])
        else:
            self.wand_curr_pos = [state.pos[0], state.pos[1], state.pos[2] - 0.05]


    def update_drones(self):
        for i in range(self.number_crazyflies):
            self.drones[i].update_state()

    #main function
    def run(self, req):
        endPosition = rospy.get_param("~endPosition", [])
        height = self.wand_curr_pos[2]
        #height = 1
        for j in range(100):
            for i in range(self.number_crazyflies):
                model = 'Drone'+str(i+1)
                pubEndpoints = rospy.Publisher(model + '/path_coordinates',StateData, queue_size=1)
                cmd = StateData()
                cmd.header.stamp = rospy.get_rostime()
                cmd.x, cmd.y, cmd.z, cmd.yaw = endPosition[i]
                cmd.z = height
                pubEndpoints.publish(cmd)
                print("Drone{}: [{}, {}, {}]".format(i+1, cmd.x, cmd.y, cmd.z))

        rate = rospy.Rate(0.8)
        rate.sleep()
        for i in range(self.number_crazyflies):
            #Each drone position should be saved in x1, y1...xn, yn in params
            self.drones.append(drone([rospy.get_param("x" + str(i+1)), rospy.get_param("y" + str(i+1)), height], i, self))

        self.add_event(self.wand_curr_pos)
        self.wand_tracking_enable = True

        self.start_running = True
        print("running")

        return ()

    def main(self):
        for i in range(self.number_crazyflies):
            if mode != 'pid':
                print ("initializing... full_control")
                self.pubs.append(rospy.Publisher("/Drone" + str(i+1) + "/full_control", FullControl, queue_size=10))
            else:
                self.pubs.append(rospy.Publisher("/Drone" + str(i+1) + '/path_coordinates',StateData, queue_size=10))

        rate = rospy.Rate(update_rate)
        while not rospy.is_shutdown():
            if self.start_running:
                self.update_drones()
                for i in range(self.number_crazyflies):
                    if mode != 'pid':
                        #reads and publishes state for nonlinear controller
                        state = FullControl()
                        state.x = [self.drones[i].initial_position[0] + self.drones[i].offset_position[0], \
                        self.drones[i].vel[0], self.drones[i].acc[0]]
                        state.y = [self.drones[i].initial_position[1] + self.drones[i].offset_position[1], \
                        self.drones[i].vel[1], self.drones[i].acc[1]]
                        state.z = [self.drones[i].initial_position[2] + self.drones[i].offset_position[2], \
                        self.drones[i].vel[2], self.drones[i].acc[2]]
                        state.yaw = [0, 0]

                        state = self.low_pass(state, i)

                        state.enable = True
                        state.header.frame_id = str(i+1)
                        state.xmode = 0b111
                        state.ymode = 0b111
                        state.zmode = 0b111
                        state.x = [state.x[0], 0.0, 0.0]
                        state.y = [state.y[0], 0.0, 0.0]
                        if state.z[0] < 0.001:
                            state.z = [0.001, 0.0, 0.0]

                        state.z = [state.z[0], 0.0, 0.0]

                        self.pubs[i].publish(state)
                    else:
                        #reads and publises state for pid controller
                        # t = TwistStamped()
                        # t.header.frame_id = str(i+1)
                        # t.twist.linear.x = (self.drones[i].initial_position[0] + self.drones[i].offset_position[0])
                        # t.twist.linear.y = (self.drones[i].initial_position[1] + self.drones[i].offset_position[1])
                        # t.twist.linear.z = (self.drones[i].initial_position[2] + self.drones[i].offset_position[2]) * 1000
                        # self.pubs[i].publish(t)
                        t = StateData()
                        t.x = (self.drones[i].initial_position[0] + self.drones[i].offset_position[0])
                        t.y = (self.drones[i].initial_position[1] + self.drones[i].offset_position[1])
                        t.z = (self.drones[i].initial_position[2] + self.drones[i].offset_position[2])
                        t.yaw = 0
                        self.pubs[i].publish(t)

            rate.sleep()

    #low pass filter used to smooth out the commands
    def low_pass(self, cmd, i):

        if type(cmd) == FullControl:

            state = FullControl()

            if self.prev_cmd[i] == None:
                self.prev_cmd[i] = cmd
                self.prev_time = rospy.Time.now()
                return cmd

            cur_time = rospy.Time.now()

            h = 1/update_rate
            a = h / (low_pass_constant + h)
            az = h / (low_pass_constant_z + h)
            x = np.array(cmd.x[:])
            y = np.array(cmd.y[:])
            z = np.array(cmd.z[:])

            state.x = list((1-a) * np.array(self.prev_cmd[i].x[:]) + a * x)
            state.y = list((1-a) * np.array(self.prev_cmd[i].y[:]) + a * y)
            state.z = list((1-az) * np.array(self.prev_cmd[i].z[:]) + az * z)
            self.prev_cmd[i] = state

        else:
            state = TwistStamped()

            if self.prev_state == -1:
                prev_cmd[i] = state
                return cmd
            else:
                h = 1/update_rate
                a = h / (low_pass_constant + h)
                state.twist.linear.x = (1-a) * prev_cmd[i].linear.x + a * cmd.linear.x
                state.twist.linear.y = (1-a) * prev_cmd[i].linear.y + a * cmd.linear.y
                state.twist.linear.z = (1-a) * prev_cmd[i].linear.z + a * cmd.linear.z

        return state

if __name__=="__main__":
    rospy.init_node("crazyflie_ribbon")
    num = rospy.get_param("~num_drones", 6)
    disturb = disturbances(num)
    #disturb.add_event([rospy.get_param("wand_pos_x", 2.7), rospy.get_param("wand_pos_y",0), rospy.get_param("wand_pos_z",0)])
    rospy.Subscriber("/Wand/estimated_state", StateVector, disturb.update_events)
    disturb.main()
    rospy.spin()
