import math
import time
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np

#motion_direction = ['x','y','z']
motion_direction = ['z']
length = 4
speed_factor = 2
transfer_factor = 20
number_crazyflies = 16
dimensions = 2
amplitude = 2 / dimensions / (len(motion_direction))
update_rate = 100
period_constant = 2.9
periodx = length / speed_factor / (2 * amplitude) * period_constant
periody = length / speed_factor / (2 * amplitude) * period_constant
periodz = length / speed_factor / (2 * amplitude) * period_constant
time_frame = 40
mode = 'not example'

#drone physics parameters
setpoints = [(5, (0,0,1)),(10, (0,0,-0.5))]
starting_events = [[0,0,0.5], [0,0,0]]
max_acc = 5
spring_constant = 20
acc_constant = 5
damping_constant = 0.08 * spring_constant
disregard_epsilon = 0.05
shortening_term = 5

class drone:

    initial_position = [0,0,0]
    offset_position = [0,0,0]
    vel = [0,0,0]
    acc = [0,0,0]

    def __init__(self, pos, disturbances):
        #print(pos)
        self.initial_position = pos[:]
        self.disturbances = disturbances
        #print(self.position)

    def get_delay(self, lead_pos):
        return self.get_distance(lead_pos, self.initial_position) / speed_factor

    def get_distance(self, drone1, drone2):
        sum = 0
        for i in range(len(drone1)):
            sum += (drone1[i] - drone2[i])**2

        return sum**0.5

    def update_state(self):
        self.offset_position = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]

        for i in range(len(self.disturbances.events)):
            if self.get_delay(self.disturbances.events[i][0]) < time.time() - self.disturbances.events[i][1][0]:
                state = self.disturbances.get_closest_state(i, time.time() - self.get_delay(self.disturbances.events[i][0]))
                #print(state)
                for x in range(3):
                    damp = math.exp(-1/transfer_factor * self.get_distance(self.initial_position, self.disturbances.events[i][0]))
                    #print(damp)
                    self.offset_position[x] += state[0][x] * damp
                    self.vel[x] += state[1][x] * damp
                    self.acc[x] += state[2][x] * damp

                #print(self.offset_position)

class disturbances:
    events_physics = []
    events = []
    num_events = 0

    def __init__(self):
        self.num_events = 0

    def get_closest_state(self, index, time):
        i = 0
        #print(lead)
        #print(time)
        #print(index)
        while((i < len(self.events[index][1]) - 1) and (time - self.events[index][1][i] > 1.7/update_rate)):
            #print(i)
            i += 1
        #print(i)
        #print(lead[2][i])
        return self.events[index][2][i]

    def add_event(self, pos):
        self.events_physics.append(physics_drone(pos[:]))
        self.num_events += 1
        self.events.append([pos[:], [time.time()], [self.event_state(0, self.num_events - 1)]])

    def activate_event(self, index, position):
        if (mode != "example"):
            self.events_physics[index].create_event(position)

    def event_state(self, time, index):
        #inner brackets contain the changes in dimension, outter are the changes in derivative
        state = [[0,0,0],[0,0,0],[0,0,0]]

        if mode == 'example':
            if 'x' in motion_direction:
                state[0][0], state[1][0], state[2][0] = (amplitude * math.sin(2 * math.pi / periodx * time), \
                amplitude * 2 * math.pi * math.cos(2 * math.pi / periodx * time) / periodx, \
                -amplitude * 4 * math.pi**2 * math.sin(2 * math.pi / periodx * time) / (periodx**2))
            if 'y' in motion_direction:
                state[0][1], state[1][1], state[2][1] = (amplitude * math.sin(2 * math.pi / periody * time), \
                amplitude * 2 * math.pi * math.cos(2 * math.pi / periody * time) / periody, \
                -amplitude * 4 * math.pi**2 * math.sin(2 * math.pi / periody * time) / (periody**2))
            if 'z' in motion_direction:
                state[0][2], state[1][2], state[2][2] = (amplitude * math.sin(2 * math.pi / periodz * time), \
                amplitude * 2 * math.pi * math.cos(2 * math.pi / periodz * time) / periodz, \
                -amplitude * 4 * math.pi**2 * math.sin(2 * math.pi / periodz * time) / (periodz**2))
        else:
            self.events_physics[index].restore_state_change(time)
            state = [self.events_physics[index].offset_pos[0] - self.events_physics[index].saved_pos[0] + self.events_physics[index].initial_pos[0], self.events_physics[index].offset_pos[1] - self.events_physics[index].saved_pos[1] + self.events_physics[index].initial_pos[1], self.events_physics[index].offset_pos[2] - self.events_physics[index].saved_pos[2] + self.events_physics[index].initial_pos[2]], \
                    self.events_physics[index].vel[:], \
                    self.events_physics[index].acc[:]

        return state

    def update_events(self, delta_t):
        if (mode == 'example'):
            for e in range(len(self.events)):
                self.events[e][1].append(time.time())
                #this is where we would read from vicon instead
                self.events[e][2].append(self.event_state(time.time() - self.events[e][1][0], 0))
                if (len(self.events) > update_rate / speed_factor * length * 2):
                    self.events[e][1].remove(self.events[e][1][0])
                    self.events[e][2].remove(self.events[e][2][0])
        else:
            for e in range(len(self.events)):
                self.events[e][1].append(time.time())
                #this is where we would read from vicon instead
                self.events[e][2].append(self.event_state(delta_t, e))
                if (len(self.events) > update_rate / speed_factor * length * 2):
                    self.events[e][1].remove(self.events[e][1][0])
                    self.events[e][2].remove(self.events[e][2][0])



class physics_drone:
    saved_pos = [0,0,0]
    initial_pos = [0,0,0]
    offset_pos = [0,0,0]
    vel = [0,0,0]
    acc = [0,0,0]
    outside_influence = False

    def __init__(self, pos):
        self.plan = setpoints
        self.initial_pos = pos[:]
        self.saved_pos = pos[:]

    def restore_state_change(self, delta_t):
        self.acc[0], self.acc[1], self.acc[2] = \
        self.acc[0]  + acc_constant * delta_t * (-spring_constant * self.offset_pos[0] - self.acc[0]), \
        self.acc[1]  + acc_constant * delta_t * (-spring_constant * self.offset_pos[1] - self.acc[1]), \
        self.acc[2]  + acc_constant * delta_t * (-spring_constant * self.offset_pos[2] - self.acc[2])

        self.acc[0] = np.sign(self.acc[0]) * min(math.fabs(self.acc[0]), max_acc)
        self.acc[1] = np.sign(self.acc[1]) * min(math.fabs(self.acc[1]), max_acc)
        self.acc[2] = np.sign(self.acc[2]) * min(math.fabs(self.acc[2]), max_acc)

        self.vel[0], self.vel[1], self.vel[2] = \
        self.vel[0] + self.acc[0] * delta_t, \
        self.vel[1] + self.acc[1] * delta_t, \
        self.vel[2] + self.acc[2] * delta_t
        self.offset_pos[0], self.offset_pos[1], self.offset_pos[2] = \
        self.offset_pos[0] + self.vel[0] * delta_t + 0.5 * self.acc[0] * delta_t ** 2, \
        self.offset_pos[1] + self.vel[1] * delta_t + 0.5 * self.acc[1] * delta_t ** 2, \
        self.offset_pos[2] + self.vel[2] * delta_t + 0.5 * self.acc[2] * delta_t ** 2

        sum_vp = (self.norm(self.vel) + self.norm(self.offset_pos)) * shortening_term

        self.vel[0] *= math.exp(-damping_constant * delta_t) * math.tanh(sum_vp)
        self.vel[1] *= math.exp(-damping_constant * delta_t) * math.tanh(sum_vp)
        self.vel[2] *= math.exp(-damping_constant * delta_t) * math.tanh(sum_vp)

        if (self.norm(self.acc) < disregard_epsilon) and (self.norm(self.vel) < disregard_epsilon) and (self.norm(self.offset_pos) < disregard_epsilon):
            self.acc = [0,0,0]
            self.vel = [0,0,0]
            self.offset_pos = [0,0,0]

    def create_event(self, pos):
        curr_vec = [0,0,0]
        curr_vec[0], curr_vec[1], curr_vec[2] = \
        self.offset_pos[0] + self.initial_pos[0], \
        self.offset_pos[1] + self.initial_pos[1], \
        self.offset_pos[2] + self.initial_pos[2]

        self.initial_pos = pos[:]
        self.offset_pos[0], self.offset_pos[1], self.offset_pos[2] = \
        curr_vec[0] - self.initial_pos[0], \
        curr_vec[1] - self.initial_pos[1], \
        curr_vec[2] - self.initial_pos[2], \

    def end_event(self):
        #waypoint mapping goes here
        self.initial_pos = self.saved_pos[:]
        self.offset_pos = [0,0,0]
        self.vel = [0,0,0]
        self.acc = [0,0,0]
        '''
        curr_vec = [0,0,0]
        curr_vec[0], curr_vec[1], curr_vec[2] = \
        self.offset_pos[0] + self.initial_pos[0], \
        self.offset_pos[1] + self.initial_pos[1], \
        self.offset_pos[2] + self.initial_pos[2]
        self.initial_pos = self.saved_pos[:]
        self.offset_pos[0], self.offset_pos[1], self.offset_pos[2] = \
        curr_vec[0] - self.initial_pos[0], \
        curr_vec[1] - self.initial_pos[1], \
        curr_vec[2] - self.initial_pos[2], \
        '''

    def norm(self, v1):
        sum = 0
        for i in range(len(v1)):
            sum += v1[i] ** 2

        sum = sum ** 0.5
        return sum

if __name__=="__main__":
    disturb = disturbances()
    drones = []
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    side_number = dimensions

    #drone setup
    if (dimensions == 1):
        for i in range(number_crazyflies):
            pos = [i*length/(number_crazyflies - 1) - length/2,0,0]
            drones.append(drone(pos, disturb))
    elif (dimensions == 2):
        side_number = round(number_crazyflies**0.5)
        for x in range(side_number):
            for y in range(side_number):
                pos = [x*length/(side_number - 1) - length/2,y*length/(side_number - 1) - length/2,0]
                drones.append(drone(pos, disturb))
    else:
        side_number = round(number_crazyflies**(1/3))
        for x in range(side_number):
            for y in range(side_number):
                for z in range(side_number):
                    pos = [x*length/(side_number - 1) - length/2, y*length/(side_number - 1) - length/2, z*length/(side_number - 1) - length/2]
                    drones.append(drone(pos, disturb))

    #begin simulation
    start_time = time.time()
    prev_time = start_time
    if mode == 'example':
        disturb.add_event([length/2 ,length/2,0])
        #disturb.add_event([0,0,0])
        #disturb.add_event([length/2,0,0])
        #disturb.add_event([length/2 ,length/2,0])
    else:
        event_loc = [0,0,0]
        disturb.add_event(event_loc)
        if ('x' in motion_direction):
            event_loc[0] = amplitude
        if ('y' in motion_direction):
            event_loc[1] = amplitude
        if ('z' in motion_direction):
            event_loc[2] = amplitude
        disturb.activate_event(disturb.num_events - 1, event_loc)
    #disturb.add_event([-length/2 ,length/2,0])
    #disturb.add_event([length/2, length/2, length/2])

    while time.time() - start_time < time_frame:

        #first update the drones and the events to the current state
        if (mode == 'example'):
            disturb.update_events(time.time() - prev_time)
        else:
            disturb.update_events(time.time() - prev_time)
        prev_time = time.time()
        for i in range(number_crazyflies):
            drones[i].update_state()

        #then display the drones on the graph
        x = []
        y = []
        z = []

        for i in range(number_crazyflies):
            x.append(drones[i].initial_position[0] + drones[i].offset_position[0])
            y.append(drones[i].initial_position[1] + drones[i].offset_position[1])
            z.append(drones[i].initial_position[2] + drones[i].offset_position[2])

        #print(x)
        #print(y)
        #print(z)
        ax.clear()
        ax.scatter(x,y,z)
        ax.set_xlim3d(-length/2, length/2)
        ax.set_ylim3d(-length/2, length/2)
        ax.set_zlim3d(-length/2, length/2)
        plt.pause(1/update_rate)
        plt.show(block=False)
        #print("Iteration")

     
